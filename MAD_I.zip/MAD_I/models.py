from app import app
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.dialects.mysql import ENUM

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True, nullable=False)
    passhash = db.Column(db.String(256), nullable=False)
    name = db.Column(db.String(64), nullable=True)
    user_type = db.Column(db.String(32), nullable=False)  # 'Admin', 'Sponsor', 'Influencer'
    is_admin = db.Column(db.Boolean, nullable = False, default = False)
    is_flagged = db.Column(db.Boolean, nullable = False, default = False)
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, onupdate=func.now())
    

class Sponsor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    company_name = db.Column(db.String(64), nullable=True)
    email = db.Column(db.String(64), unique=True, nullable=False)
    #category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable = False)
    industry = db.Column(db.String(64), nullable=True)
    budget = db.Column(db.Float, nullable=True)
    
    user = db.relationship('User', backref='sponsor', uselist=False)
    # Sponsor can create multiple campaigns
    campaigns = db.relationship('Campaign', backref='sponsor', lazy=True)

class Influencer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(64), nullable=True)
    email = db.Column(db.String(64), unique=True, nullable=False)
    # category = db.Column(db.String(64), nullable=True)
    niche = db.Column(db.String(64), nullable=True)
    #category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable = False)
    reach = db.Column(db.Integer, nullable=True) # follower count
    youtube = db.Column(db.String(32), nullable=True)
    twitter = db.Column(db.String(32), nullable=True)
    instagram = db.Column(db.String(32), nullable=True) 

    # Engagement Rate=( Total Engagements(likes, share, saves, views) / Total Followers)×100

    user = db.relationship('User', backref='influencer', uselist=False)
    # Influencer can have multiple ad requests
    ad_requests = db.relationship('AdRequest', backref='influencer', lazy=True)



class Campaign(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.String(256), nullable=True)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    budget = db.Column(db.Float, nullable=False)
    visibility = db.Column(db.String(32), nullable=False)  # 'public' or 'private'
    goals = db.Column(db.String(256), nullable=True)

    sponsor_id = db.Column(db.Integer, db.ForeignKey('sponsor.id'), nullable=False)
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, onupdate=func.now())
    is_flagged = db.Column(db.Boolean, nullable = False, default = False)

    # Campaign can have multiple ad requests
    ad_requests = db.relationship('AdRequest', backref='campaign', lazy=True)

class AdRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaign.id'), nullable=False)
    influencer_id = db.Column(db.Integer, db.ForeignKey('influencer.id'), nullable=False)
    
    messages = db.Column(db.String(256), nullable=True)
    requirements = db.Column(db.String(256), nullable=True)
    payment_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(32), nullable=False)  # 'Pending', 'Accepted', 'Rejected'
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, onupdate=func.now())

# sponsor_id = db.Column(db.Integer, db.ForeignKey('sponsor.id'), nullable=False)
# Create tables and add default admin user if not exists
with app.app_context():
    db.create_all()

    # Check if admin user exists, if not create one
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        password_hash = generate_password_hash('admin')
        admin = User(username='admin', passhash=password_hash, name='Admin', user_type='Admin', is_admin = True)
        db.session.add(admin)
        db.session.commit()

