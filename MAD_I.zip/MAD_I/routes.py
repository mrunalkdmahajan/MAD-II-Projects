from flask import render_template, request, redirect, url_for, flash, session
from app import app
from models import db, User, Sponsor, Influencer, Campaign, AdRequest
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime
from flask_migrate import Migrate
# from utils import update_campaign_status, calculate_progress_percentage

def auth_required(func):
    @wraps(func)
    def inner(*args, **kwargs):
        if 'user_id' in session:
            return func(*args, **kwargs)
        else:
            flash('Please Login to continue.')
            flash('You cannot access this page without login.')
            return redirect(url_for('login'))
        
    return inner

def admin_required(func):
    @wraps(func)
    def inner(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please Login to continue.')
            flash('You cannot access this page without login.')
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user.is_admin:
            flash('You are not authorizeeed to access this page.')
            return redirect(url_for('index'))
        return func(*args, **kwargs)
        
    return inner

@app.route('/index')
def index():
    user = User.query.get(session['user_id'])
    now = datetime.now().date() 
    if user:
        user_type = user.user_type
    else:
        user_type = None

    if user.is_admin:
        return render_template('admin/admin.html', user = user, user_type = user_type)
    if user.user_type == 'Influencer':
        influencer = Influencer.query.filter_by(user_id=user.id).first()
        if not influencer:
            flash('Influencer details not found.')
            return redirect(url_for('login'))

        ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id).all()
        return render_template('influencer/profile_influencer.html', influencer=influencer, ad_requests=ad_requests, user=user, user_type = user_type, now = now)
    
    if user.user_type == 'Sponsor':
        sponsor = Sponsor.query.filter_by(user_id=user.id).first()
        if not sponsor:
            flash('Sponsor details not found.')
            return redirect(url_for('login'))
      
        return render_template('sponsor/profile_sponsor.html', user = user, sponsor = sponsor, user_type = user_type, now = now)

@app.route('/logout')
@auth_required
def logout():
    session.pop('user_id')
    flash('PLease login to continue.')
    return redirect(url_for('login'))

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/', methods = ['POST'])
def login_post():
    username = request.form.get('username')
    password = request.form.get('password')

    if not username or not password:
        flash('Please fill out all the necessary fields.')
        return redirect(url_for('login'))
    
    user = User.query.filter_by(username = username).first()

    if not user:
        flash('Username does not exist.')
        return redirect(url_for('login'))
    
    if not check_password_hash(user.passhash, password):
        flash('Incorrect Password. Please enter the correct password.')
        return redirect(url_for('login'))
    
    session['user_id'] = user.id
    flash('Login Successful')
    return redirect(url_for('index'))



@app.route('/register_influencer')
def register_influencer():
    return render_template('influencer/register_influencer.html')

@app.route('/register_influencer', methods = ['POST'])
def register_influence_post():
    username = request.form.get('username')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    name = request.form.get('name')
    email = request.form.get('email')
    niche = request.form.get('niche')
    reach = request.form.get('reach')
    youtube = request.form.get('youtube')
    twitter = request.form.get('twitter')
    instagram = request.form.get('instagram')

    if not username or not password or not confirm_password or not email or not niche or not reach:
        flash('Please fill out all the necessary fields.')
        return redirect(url_for('register_influencer'))
    
    if password != confirm_password:
        flash('Password does not match.')
        return redirect(url_for('register_influencer'))
    
    user = User.query.filter_by(username = username).first()
    
    if user:
        flash('Username already exists.')
        return redirect(url_for('register_influencer'))

    password_hash = generate_password_hash(password)

    new_user = User(username=username, passhash=password_hash, name=name, user_type='Influencer')
    db.session.add(new_user)
    db.session.commit()

    # Now that the user is created, we can get their user_id
    user_id = new_user.id

    new_influencer = Influencer(user_id=user_id, name=name, email=email, niche=niche, reach=reach, youtube = youtube, twitter = twitter, instagram = instagram)
    db.session.add(new_influencer)
    db.session.commit()
    flash('Influencer created successfully.')
    return redirect(url_for('login'))


@app.route('/register_sponsor')
def register_sponsor():
    return render_template('sponsor/register_sponsor.html')

@app.route('/register_sponsor', methods = ['POST'])
def register_post():
    username = request.form.get('username')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    company_name = request.form.get('company_name')
    email = request.form.get('email')
    industry = request.form.get('industry')

    if not username or not password or not confirm_password:
        flash('Please fill out all the necessary fields.')
        return redirect(url_for('register_sponsor'))
    
    if password != confirm_password:
        flash('Password does not match.')
        return redirect(url_for('register_sponsor'))
    
    user = User.query.filter_by(username = username).first()
    
    if user:
        flash('Username already exists.')
        return redirect(url_for('register_sponsor'))

    password_hash = generate_password_hash(password)

    new_user = User(username=username, passhash=password_hash, user_type='Sponsor')
    db.session.add(new_user)
    db.session.commit()

    # Now that the user is created, we can get their user_id
    user_id = new_user.id

    new_sponsor = Sponsor(user_id=user_id,  company_name = company_name, email=email, industry = industry)
    db.session.add(new_sponsor)
    db.session.commit()
    flash('Sponsor created successfully.')
    return redirect(url_for('login'))

#  ----admin pages
@app.route('/admin')
@admin_required
def admin():
    user = User.query.get(session['user_id'])
    print(user) 
    flagged_campaigns = Campaign.query.filter_by(is_flagged=True).all()
    campaigns = Campaign.query.all()
    #flagged_campaigns = Flagged_Campaign.query.all()
    return render_template('admin/admin.html', campaigns=campaigns, flagged_campaigns=flagged_campaigns, user=user, user_type=user.user_type)

@app.route('/admin/<int:id>/campaign/<int:campaign_id>/view')
@auth_required
def admin_view_campaign(id, campaign_id):
    user = User.query.get(session['user_id'])
    #campaign = Campaign.query.filter_by(campaign_id=id).first()
    campaign = Campaign.query.get_or_404(campaign_id)
    return render_template('admin/admin_view_campaign.html', campaign=campaign, id=session['user_id'], user_type=user.user_type)

@app.route('/admin/<int:id>/influencer/<int:influencer_id>/view')
@auth_required
def admin_view_influencer(id, influencer_id):
    user = User.query.get(session['user_id'])
    influencer = Influencer.query.get_or_404(influencer_id)
    return render_template('admin/admin_view_influencer.html', influencer=influencer, id=session['user_id'], user_type=user.user_type)

@app.route('/admin/<int:id>/find_campaign/<int:campaign_id>/view')
@auth_required
def admin_view_campaigns(id, campaign_id):
    user = User.query.get(session['user_id'])
    #campaign = Campaign.query.filter_by(campaign_id=id).first()
    campaign = Campaign.query.get_or_404(campaign_id)
    return render_template('admin/admin_view_campaigns.html', campaign=campaign, id=session['user_id'], user_type=user.user_type)

@app.route('/admin/<int:id>/find_influencer/<int:influencer_id>/view')
@auth_required
def admin_view_influencers(id, influencer_id):
    user = User.query.get(session['user_id'])
    influencer = Influencer.query.get_or_404(influencer_id)
    return render_template('admin/admin_view_influencers.html', influencer=influencer, id=session['user_id'], user_type=user.user_type)


@app.route('/admin/<int:id>/find_all', methods=['GET'])
@auth_required  # Ensure authentication is required to access this route
def find_all(id):
    user = User.query.get(session['user_id'])

    if not user:
        flash('User not found.')
        return redirect(url_for('login'))

    cname = request.args.get('cname', '')
    iname = request.args.get('iname', '')
    niche = request.args.get('niche', '')
    
    # Query influencers with filters applied
    influencers_query = db.session.query(Influencer)
    campaigns_query = db.session.query(Campaign)

    if cname:
        campaigns_query = campaigns_query.filter(Campaign.name.ilike(f"%{cname}%"))
    if iname:
        influencers_query = influencers_query.filter(Influencer.name.ilike(f"%{iname}%"))
    if niche:
        influencers_query = influencers_query.filter(Influencer.niche.ilike(f"%{niche}%"))

    influencers = influencers_query.all()
    campaigns = campaigns_query.all()

    # Query public campaigns
    #campaigns = Campaign.query.all()
  
    return render_template('admin/find_all.html', influencers=influencers, campaigns = campaigns, cname=cname, iname=iname, niche=niche, user_type=user.user_type)

@app.route('/admin/<int:id>/flagged/<int:campaign_id>')
@auth_required
def flagged_items(id):
    flagged_campaigns = Campaign.query.filter_by(is_flagged=True).all()
    flagged_users = User.query.filter_by(is_flagged=True).all()
    return render_template('admin/admin.html', flagged_campaigns=flagged_campaigns, flagged_users=flagged_users)

@app.route('/admin/flag_campaign/<int:campaign_id>', methods=['POST'])
@admin_required
def flag_campaign(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)
    campaign.is_flagged = True
    db.session.commit()
    flash('Campaign has been flagged.')
    return redirect(url_for('admin', id=session['user_id']))



@app.route('/admin/campaign/<int:campaign_id>/unflag', methods=['POST'])
@auth_required
def unflag_campaign(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)
    campaign.is_flagged = False
    db.session.commit()
    flash('Campaign unflagged successfully')
    return redirect(url_for('admin', id=session['user_id']))

@app.route('/admin/user/<int:user_id>/flag')
@auth_required
def flag_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_flagged = True
    db.session.commit()
    flash('User flagged successfully')
    return redirect(url_for('flagged_items'))

@app.route('/admin/user/<int:user_id>/unflag')
@auth_required
def unflag_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_flagged = False
    db.session.commit()
    flash('User unflagged successfully')
    return redirect(url_for('flagged_items'))


@app.route('/admin/stats_admin')
def stats_admin():
    return render_template('login.html')

@app.route('/admin/<int:id>/profile')
@auth_required
def profile_admin(id):
    user = User.query.get(session['user_id'])
    now = datetime.now().date()
    if not user:
        flash('Admin not found.')
        return redirect(url_for('login'))
 
    # Fetch ad requests for the influencer

    return render_template('admin/profile_admin.html', user = user, user_type=user.user_type, now = now)

@app.route('/admin/<int:admin_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_admin(admin_id):
    user = User.query.get(admin_id)
    if not user:
        flash('User not found.')
        return redirect(url_for('profile_admin', id=admin_id))
    if request.method == 'POST':
        user.name = request.form['name']        
        db.session.commit()
        flash('Profile updated successfully!')
        return redirect(url_for('profile_admin', id=admin_id))
    return render_template('admin/edit_profile.html', user=user)


#   ----influencer pages

@app.route('/influencer/<int:id>/profile')
@auth_required
def profile_influencer(id):
    print(f"Received id: {id}")
    influencer = Influencer.query.filter_by(id = id).first()
    if not influencer:
        flash('Influencer not found.')
        return redirect(url_for('login'))
        
    user = User.query.get(session['user_id'])
    if not user:
        flash('User not found.')
        return redirect(url_for('login'))
        
    ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id).all()
    now = datetime.now().date()
 
    return render_template('influencer/profile_influencer.html', influencer=influencer, ad_requests=ad_requests, user=user, user_type=user.user_type, now=now)

@app.route('/influencer/<int:influencer_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_influencer(influencer_id):
    influencer = Influencer.query.filter_by(id = influencer_id).first()
    if not influencer:
        flash('Influencer not found.')
        return redirect(url_for('profile_influencer', id=influencer_id))
    if request.method == 'POST':
        influencer.name = request.form['name']
        influencer.email = request.form['email']
        influencer.niche = request.form['niche']
        influencer.reach = request.form['reach']
        influencer.youtube = request.form.get('youtube')
        influencer.twitter = request.form.get('twitter')
        influencer.instagram = request.form.get('instagram')
        db.session.commit()
        flash('Profile updated successfully!')
        return redirect(url_for('profile_influencer', id=influencer.user_id))
    return render_template('influencer/edit_profile.html', influencer=influencer)

@app.route('/campaign/<int:id>/view')
@auth_required
def influencer_p_view_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    return render_template('influencer/influencer_p_view_campaign.html', campaign=campaign, id=session['user_id'])

@app.route('/ad_request/<int:id>/view')
@auth_required
def influencer_p_view_request(id):
    ad_request = AdRequest.query.get_or_404(id)
    return render_template('influencer/influencer_view_request.html', ad_request=ad_request, id=session['user_id'])

@app.route('/influencer/ad_request/<int:ad_request_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_ad_request_influencer(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)

    if request.method == 'POST':
        ad_request.requirements = request.form.get('requirements')
        ad_request.payment_amount = request.form.get('payment_amount')
        ad_request.status = 'Edited'  # Reset status to 'Pending' for sponsor review
        db.session.commit()
        flash('Ad request updated and resent successfully.')
        return redirect(url_for('influencer_p_view_request', id=ad_request.id))

    return render_template('influencer/edit_ad_request_influencer.html', ad_request=ad_request)


@app.route('/ad_request/<int:ad_request_id>/accept', methods=['GET'])
@auth_required
def accept_request(ad_request_id):
    ad_request = AdRequest.query.get(ad_request_id)
    if not ad_request:
        flash('No request found.')
        return redirect(url_for('profile_influencer', id=session['user_id']))
    ad_request.status = 'Accepted'
    db.session.commit()
    flash('Ad request accepted successfully.')
    return redirect(url_for('profile_influencer', id=session['user_id']))


@app.route('/ad_request/<int:ad_request_id>/reject', methods=['GET'])
@auth_required
def reject_request(ad_request_id):
    ad_request = AdRequest.query.get(ad_request_id)
    if not ad_request:
        flash('No request found.')
        return redirect(url_for('profile_influencer', id=session['user_id']))
    ad_request.status = 'Rejected'
    db.session.commit()
    flash('Ad request rejected.')
    return redirect(url_for('profile_influencer', id=session['user_id']))

@app.route('/influencer/<int:id>/find_campaign', methods=['GET'])
@auth_required  # Ensure authentication is required to access this route
def find_campaign(id):
    influencer = Influencer.query.filter_by(user_id=id).first()
    user = User.query.get(session['user_id'])

    if not influencer or not user:
        flash('Influencer not found.')
        return redirect(url_for('login'))

    name = request.args.get('name', '')
    budget = request.args.get('budget', type=float)
    start_date = request.args.get('start_date')

    # Query campaigns with filters applied
    campaigns_query = db.session.query(Campaign)

    if name:
        campaigns_query = campaigns_query.filter(Campaign.name.ilike(f"%{name}%"))
    if budget is not None:
        campaigns_query = campaigns_query.filter(Campaign.budget <= budget)
    if start_date:
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            campaigns_query = campaigns_query.filter(Campaign.start_date >= start_date)
        except ValueError:
            flash('Invalid date format. Please use YYYY-MM-DD.')
            start_date = None

    campaigns = campaigns_query.all()

    return render_template('influencer/find_campaign.html',influencer = influencer, campaigns=campaigns, name=name, budget=budget, start_date=start_date, user_type=user.user_type)

@app.route('/campaign/<int:id>/view')
@auth_required
def influencer_view_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    return render_template('influencer/view_campaign.html', campaign=campaign, id=session['user_id'])

@app.route('/influencer/<int:influencer_id>/campaign/<int:campaign_id>/request', methods=['GET', 'POST'])
@auth_required
def request_from_campaign(influencer_id, campaign_id):
    print(f"Influencer ID: {influencer_id}")
    print(f"Campaign ID: {campaign_id}")

    influencer = Influencer.query.get_or_404(influencer_id)
    if not influencer:
        flash('Influencer not found.')
        return redirect(url_for('profile_influencer', id=influencer_id))
    
    campaign = Campaign.query.get_or_404(campaign_id)
    sponsor = campaign.sponsor  # Fetch the sponsor directly from the campaign

    if request.method == 'POST':
        messages = request.form.get('messages')
        requirements = request.form.get('requirements')
        payment_amount = request.form.get('payment_amount')

        try:
            payment_amount = float(payment_amount)
        except ValueError:
            flash('Invalid payment amount.')
            return redirect(url_for('request_from_campaign', influencer_id=influencer_id, campaign_id=campaign_id))

        ad_request = AdRequest(
            campaign_id=campaign.id,
            influencer_id=influencer.id,
            messages=messages,
            requirements=requirements,
            payment_amount=payment_amount,
            status='Pending'
        )
        db.session.add(ad_request)
        db.session.commit()
        flash('Ad request successfully created.')
        print(f"s")
        return redirect(url_for('profile_influencer', id=influencer_id))

    return render_template('influencer/ad_request.html', influencer=influencer, campaign=campaign)

@app.route('/stats_influencer')
def stats_influencer():
    return render_template('empty.html')

#  -----sponsor pages

@app.route('/profile/sponsor/<int:id>', methods=['GET'])
@auth_required
def profile_sponsor(id):
    user = User.query.get(id)
    if not user:
        flash('User not found.')
        return redirect(url_for('login'))

    sponsor = Sponsor.query.filter_by(user_id=user.id).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('login'))

    now = datetime.now().date()
    campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()

    if not user:
        flash('User not found.')
        return redirect(url_for('login'))

    # Fetch active campaigns for the sponsor
    active_campaigns = Campaign.query.filter(Campaign.sponsor_id == sponsor.id, Campaign.end_date >= now).all()
    
    # Fetch completed campaigns for the sponsor
    completed_campaigns = Campaign.query.filter(Campaign.sponsor_id == sponsor.id, Campaign.end_date < now).all()

    # Fetch ad requests for the sponsor's campaigns
    ad_requests = AdRequest.query.join(Campaign).filter(Campaign.sponsor_id == sponsor.id).all()
    
    return render_template(
        'sponsor/profile_sponsor.html', 
        sponsor=sponsor, 
        active_campaigns=active_campaigns, 
        completed_campaigns=completed_campaigns, 
        ad_requests=ad_requests,
        user=user,
        user_type=user.user_type, 
        now=now
    )

# @app.route('/campaign/<int:id>/view')
# @auth_required
# def view_p_campaign(id):
#     campaign = Campaign.query.get_or_404(id)
#     return render_template('sponsor/view_p_campaign.html', campaign=campaign, id=session['user_id'])

@app.route('/sponsor/<int:sponsor_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_sponsor(sponsor_id):
    sponsor = Sponsor.query.filter_by(id = sponsor_id).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('profile_sponsor', id=sponsor_id))
    if request.method == 'POST':
        sponsor.company_name = request.form['company_name']
        sponsor.email = request.form['email']
        sponsor.industry = request.form['industry']
        sponsor.budget = request.form['budget']
        db.session.commit()
        flash('Profile updated successfully!')
        return redirect(url_for('profile_sponsor', id=sponsor.user_id))
    return render_template('sponsor/edit_profile.html', sponsor=sponsor)

@app.route('/ad_request/<int:ad_request_id>/accept', methods=['POST'])
@auth_required
def s_accept_request(ad_request_id):
    ad_request = AdRequest.query.get(ad_request_id)
    if not ad_request:
        flash('No request found.')
        return redirect(url_for('profile_sponsor', id=session['user_id']))
    ad_request.status = 'Accepted'
    db.session.commit()
    flash('Ad request accepted successfully.')
    return redirect(url_for('profile_sponsor', id=session['user_id']))


@app.route('/ad_request/<int:ad_request_id>/reject', methods=['POST'])
@auth_required
def s_reject_request(ad_request_id):
    ad_request = AdRequest.query.get(ad_request_id)
    if not ad_request:
        flash('No request found.')
        return redirect(url_for('profile_sponsor', id=session['user_id']))
    ad_request.status = 'Rejected'
    db.session.commit()
    flash('Ad request rejected.')
    return redirect(url_for('profile_sponsor', id=session['user_id']))

@app.route('/sponsor/ad_request/<int:ad_request_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_ad_request_sponsor(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)

    if request.method == 'POST':
        ad_request.requirements = request.form.get('requirements')
        ad_request.payment_amount = request.form.get('payment_amount')
        ad_request.status = 'Edited'  # Reset status to 'Pending' for sponsor review
        db.session.commit()
        flash('Ad request updated and resent successfully.')
        return redirect(url_for('sponsor_view_request', ad_request_id=ad_request.id))

    return render_template('sponsor/edit_ad_request_sponsor.html', ad_request=ad_request)


@app.route('/sponsor/<int:id>/campaigns')
@auth_required
def campaigns_sponsor(id):
    sponsor = Sponsor.query.filter_by(user_id=id).first()
    user = User.query.get(session['user_id'])
    print(f"Sponsors ID: {sponsor.id}")
    if not sponsor or not user:
        flash('Sponsor not found.')
        return redirect(url_for('login'))
    print(f"Sponsor ID: {sponsor.id}")
    campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()
    print(f"Campaigns found: {campaigns}")
    return render_template('sponsor/campaigns.html', sponsor=sponsor, campaigns=campaigns, user_type = user.user_type)

@app.route('/s/add_campaign/<int:id>', methods=['GET', 'POST'])
def add_campaign(id):
    sponsor = Sponsor.query.filter_by(user_id=id).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        start_date_str = request.form['start_date']
        end_date_str = request.form['end_date']
        budget = request.form['budget']
        visibility = request.form['visibility']
        goals_list = request.form.getlist('goals[]')

        # Convert date strings to date objects
        try:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
        except ValueError:
            flash('Invalid date format. Please use YYYY-MM-DD.')
            return redirect(url_for('add_campaign', id=id))

        # Join goals into a single string separated by newlines
        goals = "\n".join([goal for goal in goals_list if goal.strip() != ""])

        new_campaign = Campaign(
            name=name,
            description=description,
            start_date=start_date,
            end_date=end_date,
            budget=float(budget),
            visibility=visibility,
            goals=goals,
            sponsor_id=sponsor.id,
            created_at=datetime.now()
        )

        db.session.add(new_campaign)
        db.session.commit()
        
        flash('Campaign added successfully!')
        return redirect(url_for('campaigns_sponsor', id=id))        

    return render_template('sponsor/add_campaign.html', sponsor = sponsor)

@app.route('/sponsor/<int:id>/find_influencer', methods=['GET'])
@auth_required
def find_influencer(id):
    # Assuming id is the sponsor's id
    sponsor = Sponsor.query.filter_by(user_id=id).first()
    user = User.query.get(session['user_id'])

    if not sponsor or not user:
        flash('Sponsor not found.')
        return redirect(url_for('login'))

    cname = request.args.get('cname', '')
    iname = request.args.get('iname', '')
    niche = request.args.get('niche', '')
    reach = request.args.get('reach', type=int)

    # Query influencers with filters applied
    influencers_query = db.session.query(Influencer)

    if iname:
        influencers_query = influencers_query.filter(Influencer.name.ilike(f"%{iname}%"))
    if niche:
        influencers_query = influencers_query.filter(Influencer.niche.ilike(f"%{niche}%"))
    if reach is not None:
        influencers_query = influencers_query.filter(Influencer.reach >= reach)

    influencers = influencers_query.all()

    # Query campaigns with filters applied
    campaigns_query = db.session.query(Campaign).filter_by(visibility='public')

    if cname:
        campaigns_query = campaigns_query.filter(Campaign.name.ilike(f"%{cname}%"))

    public_campaigns = campaigns_query.all()

    return render_template('sponsor/find_influencer.html', sponsor=sponsor, influencers=influencers, public_campaigns=public_campaigns, cname=cname, iname=iname, niche=niche, reach=reach, user_type=user.user_type)

@app.route('/select_campaign/<int:influencer_id>', methods=['GET'])
@auth_required
def select_campaign(influencer_id):
    influencer = Influencer.query.get_or_404(influencer_id)
    public_campaigns = Campaign.query.filter_by(visibility='public').all()
    return render_template('sponsor/select_campaign.html', influencer=influencer, public_campaigns=public_campaigns)


@app.route('/contact_influencer', methods=['POST'])
def contact_influencer():
    influencer_id = request.form.get('influencer_id')
    influencer = db.session.query(Influencer).get(influencer_id)
    # Implement the logic to contact the influencer, such as sending an email
    return redirect(url_for('find_influencer'))

# Update the route to accept both influencer_id and campaign_id
@app.route('/sponsor/influencer/<int:influencer_id>/campaign/<int:campaign_id>/request', methods=['GET', 'POST'])
@auth_required
def request_influencer(influencer_id, campaign_id):
    influencer = Influencer.query.get_or_404(influencer_id)
    #influencer = Influencer.query.filter_by(user_id=influencer_id).first()
    campaign = Campaign.query.get_or_404(campaign_id)
    sponsor_id = campaign.sponsor.id
    

    if request.method == 'POST':
        messages = request.form.get('messages')
        requirements = request.form.get('requirements')
        payment_amount = request.form.get('payment_amount')

        # Ensure payment_amount is a valid float
        try:
            payment_amount = float(payment_amount)
        except ValueError:
            flash('Invalid payment amount.')
            return redirect(url_for('request_influencer', influencer_id=influencer_id, campaign_id=campaign_id))

        ad_request = AdRequest(
            campaign_id=campaign.id,
            influencer_id=influencer.id,
            messages=messages,
            requirements=requirements,
            payment_amount=payment_amount,
            status='Pending'
        )
        db.session.add(ad_request)
        db.session.commit()
        flash('Ad request successfully created.')
        return redirect(url_for('find_influencer', id=session['user_id']))

    return render_template('sponsor/request_influencer.html', influencer=influencer, campaign=campaign)

@app.route('/influencer/<int:id>/view')
@auth_required
def view_influencer(id):
    influencer = Influencer.query.get_or_404(id)
    return render_template('sponsor/view_influencer.html', influencer=influencer)


@app.route('/sponsor/<int:sponsor_id>/campaign/<int:id>/view')
@auth_required
def view_campaign(sponsor_id, id):
    sponsor = Sponsor.query.filter_by(user_id=sponsor_id).first()
    campaign = Campaign.query.get_or_404(id)
    return render_template('sponsor/view_campaigns.html', sponsor = sponsor, campaign=campaign, id=session['user_id'])

@app.route('/campaign/<int:id>/add')
@auth_required
def add_campaigns(id):
    campaign = Campaign.query.get_or_404(id)
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('find_influencer', id=session['user_id']))
    sponsor.campaigns.append(campaign)
    db.session.commit()
    flash('Campaign successfully added.')
    return redirect(url_for('find_influencer', id=session['user_id']))

# @app.route('/campaign/<int:id>/view', methods=['GET'])
# @auth_required
# def view_c_campaign(id):
#     print(f"Campaign ID: {id}")
#     campaign = Campaign.query.get_or_404(id)
#     return render_template('sponsor/view_c_campaign.html', campaign=campaign, id=session['user_id'])
@app.route('/campaign/campaign/<int:id>/view', methods=['GET'])
@auth_required
def view_c_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    return render_template('sponsor/view_c_campaign.html', campaign = campaign)
@app.route('/campaign/profile/<int:id>/view', methods=['GET'])
@auth_required
def view_p_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    return render_template('sponsor/view_p_campaign.html', campaign = campaign)



@app.route('/view_request/<int:ad_request_id>', methods=['GET'])
@auth_required
def sponsor_view_request(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)
    campaign = Campaign.query.get_or_404(ad_request.campaign_id)
    influencer = Influencer.query.get_or_404(ad_request.influencer_id)
    return render_template('sponsor/view_ad_requests.html', ad_request=ad_request, campaign = campaign, influencer = influencer)



@auth_required
@app.route('/sponsor/<int:id>/stats', methods=['GET'])
def stats_sponsor(id):
    user = User.query.get(id)
    if not user:
        flash('User not found.')
        return redirect(url_for('login'))

    sponsor = Sponsor.query.filter_by(user_id=user.id).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('login'))
    
    campaigns = Campaign.query.all()
    campaign_names = [campaign.name for campaign in campaigns]
    campaign_budgets = [campaign.budget for campaign in campaigns]
    return render_template('sponsor/stats.html', user=user, user_type=user.user_type, campaigns = campaigns, 
                           campaign_names = campaign_names, campaign_budgets = campaign_budgets)
