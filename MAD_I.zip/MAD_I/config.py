from dotenv import load_dotenv
# to load 3, 4, 5 from .env
import os
from app import app
# 1st-app.py
# 2nd-var-app=Flask(__name__)

#call the load_dotenv
load_dotenv()
# still not added to app so,
# all the configs you have to store 
#os.getenv- fetches things from the environment
# take each key from environment and set it in the app.config
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('SQLALCHEMY_DATABASE_URI')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = os.getenv('SQLALCHEMY_TRACK_MODIFICATIONS')
