import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Function to read the CSV file into a DataFrame
def read_csv(file_path):
    return pd.read_csv(file_path)

# Function to display the DataFrame
def display_dataframe(df):
    print("DataFrame:")
    print(df)
    print()

# Function to show example series
def show_example_series(df):
    print("\nExample Series:")
    series_example = df['2021_last_updated']  # Example series
    print(series_example)

# Function to perform operations in series
def operations_in_series(df):
    while True:
        print("\nOperations in Series:")
        print("1. Sum of two series")
        print("2. Extracting a subset of data")
        print("3. Multiply '2021_last_updated' by 2")
        print("4. Generate Random Series with same length as df")
        print("5. Exit to Main Menu")

        choice = input("Enter your choice: ")

        if choice == '1':
            series_sum = df['2021_last_updated'] + df['2020_population']
            print("Series Sum: 2021_last_updated + 2020_population")
            print(series_sum)
        elif choice == '2':
            subset = df[df['2021_last_updated'] > 200000000]
            print("\nSubset of Data:(2021_last_updated > 200,000,000)")
            print(subset)
        elif choice == '3':
            df['2021_last_updated'] = df['2021_last_updated'] * 2
            print("\nDataFrame after multiplying '2021_last_updated' by 2:")
            print(df)
        elif choice == '4':
            series_random = pd.Series(np.random.randn(len(df)))
            print("\nRandom Series with same length as df:")
            print(series_random)
        elif choice == '5':
            break
        else:
            print("Invalid choice. Please enter a valid option.")

# Function to perform mathematical operations
def mathematical_operations(df):
    while True:
        print("\nMathematical Operations:")
        print("1. Square root of '2021_last_updated' column")
        print("2. DataFrame after adding 1000000 to '2021_last_updated' column")
        print("3. Sum of 2021_last_updated")
        print("4. Exit to Main Menu")

        choice = input("Enter your choice: ")

        if choice == '1':
            sqrt_values = np.sqrt(df['2021_last_updated'])
            print("\nSquare root of '2021_last_updated' column:")
            print(sqrt_values)
        elif choice == '2':
            df['2021_last_updated'] = df['2021_last_updated'] + 1000000
            print("\nDataFrame after adding 1,000,000 to '2021_last_updated' column:")
            print(df)
        elif choice == '3':
            print("\nSum of 2021_last_updated:", df['2021_last_updated'].sum())
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please enter a valid option.")

# Function to perform statistical analysis
def statistical_analysis(df):
    print("Statistical Analysis:")
    print(df['2021_last_updated'].describe())
    print()

# Function to delete and append entries
def delete_and_append(df):
    while True:
        print("\nDelete and Append Entries Menu:")
        print("1. Delete entry by index")
        print("2. Append new entry")
        print("3. Exit to Main Menu")

        choice = input("Enter your choice: ")

        if choice == '1':
            index_to_delete = int(input("Enter the index to delete: "))
            df = df.drop(index=index_to_delete)
            print("DataFrame after deleting entry at index", index_to_delete, ":")
            print(df)
        elif choice == '2':
            country = input("Enter the country: ")
            last_updated = int(input("Enter the 2021 last updated: "))
            population = int(input("Enter the 2020 population: "))
            area = input("Enter the area: ")
            density_sq_km = input("Enter the density per sq km: ")
            growth_rate = input("Enter the growth rate: ")
            world_percent = input("Enter the world percent: ")
            new_entry = {'country': country, '2021_last_updated': last_updated, '2020_population': population,
                         'area': area, 'density_sq_km': density_sq_km, 'growth_rate': growth_rate,
                         'world_%': world_percent}
            df = pd.concat([df, pd.DataFrame([new_entry])], ignore_index=True)
            print("DataFrame after appending new entry:")
            print(df)
        elif choice == '3':
            break
        else:
            print("Invalid choice. Please enter a valid option.")


# Function to plot on DataFrames
def plot_dataframe(df):
    while True:
        print("\nChoose the type of plot:")
        print("1. Bar Graph")
        print("2. Pie Chart")
        print("3. Scatter Plot")
        print("4. Histogram")
        print("5. Exit to main menu")

        choice = input("Enter your choice: ")

        if choice == '1':
            df['2021_last_updated'].plot(kind='bar')
            plt.title('Bar Graph: 2021 Last Updated Distribution')
            plt.xlabel('Index')
            plt.ylabel('2021 Last Updated')
            plt.show()
        elif choice == '2':
            df['2021_last_updated'].plot(kind='pie', autopct='%1.1f%%')
            plt.title('Pie Chart: 2021 Last Updated Distribution')
            plt.show()
        elif choice == '3':
            df.plot(x='2021_last_updated', y='country', kind='scatter')
            plt.title('Scatter Plot: 2021 Last Updated vs Country')
            plt.xlabel('2021 Last Updated')
            plt.ylabel('Country')
            plt.show()
        elif choice == '4':
            df['2021_last_updated'].plot(kind='hist', bins=10)
            plt.title('Histogram: 2021 Last Updated Distribution')
            plt.xlabel('2021 Last Updated')
            plt.ylabel('Frequency')
            plt.show()
        elif choice == '5':
            break
        else:
            print("Invalid choice. Please enter a valid option.")

# Main function
def main():
    file_path = '2021_population.csv'  # Update with your CSV file path
    df = read_csv(file_path)

    while True:
        print("\nMenu:")
        print("1. Display DataFrame")
        print("2. Show Example Series")
        print("3. Operations in Series")
        print("4. Mathematical Operations")
        print("5. Statistical Analysis")
        print("6. Delete and Append Entries")
        print("7. Plot DataFrame")
        print("8. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            display_dataframe(df)
        elif choice == '2':
            show_example_series(df)
        elif choice == '3':
            operations_in_series(df)
        elif choice == '4':
            mathematical_operations(df)
        elif choice == '5':
            statistical_analysis(df)
        elif choice == '6':
            delete_and_append(df)
        elif choice == '7':
            plot_dataframe(df)
        elif choice == '8':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()
