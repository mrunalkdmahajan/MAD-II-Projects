from celery.schedules import crontab
from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore, UserDatastore
from application.models import db, User, Service, ServiceRequest, ProfessionalProfile, Review
from config import DevelopmentConfig
from application.resources import api
from application.sec import datastore
from application.worker import celery_init_app
from application.tasks import daily_reminder, send_monthly_activity_reports, daily_professional_reminder
# from application.tasks import check_influencer_reminder, generate_and_send_monthly_report
from application.instances import cache
import flask_excel as excel


def create_app():
    app = Flask(__name__)
    app.config.from_object(DevelopmentConfig)
    db.init_app(app)
    api.init_app(app)
    excel.init_excel(app)
    app.security = Security(app, datastore)
    cache.init_app(app)

    with app.app_context():
        import application.views

    return app


app = create_app()
celery_app = celery_init_app(app)

@celery_app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    """Schedule periodic tasks"""
    # Daily email reminder
    sender.add_periodic_task(
        crontab(hour=10, minute=5),
        daily_reminder.s('mrunal@email.com', 'Daily Test'),
    )

    # Monthly report on 1st of the month at 2:00 AM
    sender.add_periodic_task(
        crontab(hour=10, minute=5, day_of_month=27),
        send_monthly_activity_reports.s(),
    )

    sender.add_periodic_task(
        crontab(hour=10, minute=5),  # Runs daily at 8 AM
        daily_professional_reminder.s(),
    )




if __name__ == '__main__':
    # print(app.url_map) 
    app.run(debug=True)


# This is main.py
# and it is mostly complete


