# model.py - database
# instance -> database
# views.py -> api, routes
# sec.py -> security
# resources.py ->
# templates -> 


# main.py
# config.py

# README.md
# upload_initial_data -> 
# requirements.txt

