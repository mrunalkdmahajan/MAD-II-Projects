from flask_restful import Resource, Api, reqparse, fields, marshal
from flask_security import auth_required, roles_required, current_user
from flask import jsonify
from sqlalchemy import or_
from .models import Service, db
from .instances import cache

api = Api(prefix='/api')

# return {"message": "hello from api"}

# Request parser for service details
parser = reqparse.RequestParser()
parser.add_argument('name', type=str,
                    help='Name of the service is required and should be a string', required=True)
parser.add_argument('price', type=float,
                    help='Price of the service is required and should be a float', required=True)
parser.add_argument('time_required', type=int,
                    help='Time required for service (in minutes) is required and should be an integer', required=True)
parser.add_argument('description', type=str,
                    help='Description of the service is required and should be a string', required=True)


# Fields to be returned when marshalling the service data
service_fields = {
    'id': fields.Integer,
    'name': fields.String,
    'price': fields.Float,
    'time_required': fields.Integer,
    'description': fields.String
}


class ServiceResource(Resource):
    @auth_required("token")
    @roles_required("admin")
    # @cache.cached(timeout=50)
    def get(self):
        # Admins can access all services
        services = Service.query.all()
        
        if len(services) > 0:
            return marshal(services, service_fields)
        else:
            return {"message": "No Service Found"}, 404
        # return {"message": "hello from api"}

    @auth_required("token")
    @roles_required("admin")
    def post(self):
        # Parsing service details from the request
        args = parser.parse_args()
        service = Service(name=args.get("name"), price=args.get("price"),
                          time_required=args.get("time_required"), description=args.get("description"))
        
        db.session.add(service)
        db.session.commit()
        return {"message": "Service Created"}


# Registering the ServiceResource API endpoint
api.add_resource(ServiceResource, '/service')
