
from flask_sqlalchemy import SQLAlchemy
from flask_security import UserMixin, RoleMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import JSON

from sqlalchemy.sql import func
from werkzeug.security import generate_password_hash
from flask_migrate import Migrate
import uuid

db = SQLAlchemy()

# Association Table for User Roles
class RolesUsers(db.Model):
    __tablename__ = 'roles_users'
    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column('user_id', db.Integer(), db.ForeignKey('user.id'))
    role_id = db.Column('role_id', db.Integer(), db.ForeignKey('role.id'))

# User Table
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, unique=False)
    email = db.Column(db.String, unique=True)
    password = db.Column(db.String(255))
    active = db.Column(db.Boolean(), nullable=False, default=False)
    is_blocked = db.Column(db.Boolean, nullable=False, default=False)
    is_admin = db.Column(db.Boolean, nullable=False, default=False)
    
    fs_uniquifier = db.Column(db.String(255), unique=True, nullable=False)
    roles = db.relationship('Role', secondary='roles_users',
                             backref=db.backref('users', lazy='dynamic'))

    # Relationships
    services_requested = db.relationship('ServiceRequest', backref='customer', foreign_keys='ServiceRequest.customer_id')
    services_provided = db.relationship('ServiceRequest', backref='professional', foreign_keys='ServiceRequest.professional_id')
    profile = db.relationship('ProfessionalProfile', backref='user', uselist=False)

# Role Table
class Role(db.Model, RoleMixin):
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(80), unique=True)
    description = db.Column(db.String(255))

# Service Table
class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=True)
    price = db.Column(db.Float, nullable=True)
    time_required = db.Column(db.Integer, nullable=True)  # In minutes
    description = db.Column(db.String, nullable=True)

    # Relationships
    requests = db.relationship('ServiceRequest', backref='service', lazy=True)

# Professional Profile Table
class ProfessionalProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True)
    name = db.Column(db.String, nullable=False)
    city = db.Column(db.String, nullable=False)
    state = db.Column(db.String, nullable=False)
    pin_code = db.Column(db.String(10), nullable=False)
    date_created = db.Column(db.DateTime, nullable=False, default=func.now())
    description = db.Column(db.String, nullable=True)
    service_type = db.Column(db.String, nullable=False)
    experience = db.Column(db.Integer, nullable=True)  # In years
    is_verified = db.Column(db.Boolean, nullable=False, default=False)
    
    reviews = db.relationship('Review', backref='professional', lazy=True)
    

# Service Request Table
class ServiceRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    professional_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    date_of_request = db.Column(db.DateTime, nullable=False, default=func.now())
    date_of_completion = db.Column(db.DateTime, nullable=True)
    service_status = db.Column(db.String, nullable=False)  # requested/assigned/closed
    remarks = db.Column(db.String, nullable=True)
    reviews = db.relationship('Review', backref='servicerequest', lazy=True)

# Review Table
class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    professional_id = db.Column(db.Integer, db.ForeignKey('professional_profile.id'), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    rating = db.Column(db.Float, nullable=False)  # Rating out of 5
    comments = db.Column(db.String, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=func.now())

    # Add this field to link reviews to specific service requests
    service_request_id = db.Column(db.Integer, db.ForeignKey('service_request.id'), nullable=False)
    # service_request = db.relationship('ServiceRequest', backref='reviews')
    
    # Add relationship to User for customer reviews
    # customer = db.relationship('User',lazy=True, backref='reviews_given')
    
    # Add relationship to ProfessionalProfile for professional
    # professional = db.relationship('ProfessionalProfile', lazy=True, backref='reviews_received')



