# from flask import jsonify, request
# from app import db
# from app.models import Service  # Assuming your Service model is in `app.models`

# class ServiceResources:
#     @staticmethod
#     def create_service():
#         data = request.get_json()

#         # Validate the data
#         if not data.get('name') or not data.get('price'):
#             return jsonify({'error': 'Service name and price are required'}), 400

#         try:
#             # Create a new Service instance
#             new_service = Service(
#                 name=data.get('name'),
#                 price=data.get('price'),
#                 time_required=data.get('time_required', 0),  # Default to 0 if not provided
#                 description=data.get('description', ''),    # Default to empty string
#             )

#             # Add the service to the database
#             db.session.add(new_service)
#             db.session.commit()

#             # Respond with the created service details
#             return jsonify({
#                 'message': 'Service created successfully',
#                 'service': {
#                     'id': new_service.id,
#                     'name': new_service.name,
#                     'price': new_service.price,
#                     'time_required': new_service.time_required,
#                     'description': new_service.description,
#                 }
#             }), 201

#         except Exception as e:
#             db.session.rollback()
#             return jsonify({'error': f"Failed to create service: {str(e)}"}), 500
