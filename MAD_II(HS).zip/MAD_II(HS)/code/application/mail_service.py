# from smtplib import SMTP
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText

# SMTP_HOST = "localhost"
# SMTP_PORT = 1025
# SENDER_EMAIL = '22f3001659@study.iitm.ac.in'
# SENDER_PASSWORD = ''


# def send_message(to, subject, content_body):
#     msg = MIMEMultipart()
#     msg["To"] = to
#     msg["Subject"] = subject
#     msg["From"] = SENDER_EMAIL
#     msg.attach(MIMEText(content_body, 'html'))
#     client = SMTP(host=SMTP_HOST, port=SMTP_PORT)
#     client.send_message(msg=msg)
#     client.quit()


# send_message('22f3001659@email.com', 'test', '<html>Test</html>')


from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

SMTP_HOST = "localhost"
SMTP_PORT = 1025
SENDER_EMAIL = "22f3001659@study.iitm.ac.in"
SENDER_PASSWORD = ""

def send_message(to, subject, content_body, pdf_attachment=None):
    """Send an email with optional PDF attachment."""
    msg = MIMEMultipart()
    msg["From"] = SENDER_EMAIL
    msg["To"] = to
    msg["Subject"] = subject
    msg.attach(MIMEText(content_body, "html"))

    # Attach PDF if provided
    if pdf_attachment:
        pdf_part = MIMEApplication(pdf_attachment, Name="Monthly_Report.pdf")
        pdf_part["Content-Disposition"] = 'attachment; filename="Monthly_Report.pdf"'
        msg.attach(pdf_part)

    try:
        client = SMTP(host=SMTP_HOST, port=SMTP_PORT)
        client.ehlo()

        if SENDER_PASSWORD:
            client.starttls()
            client.login(SENDER_EMAIL, SENDER_PASSWORD)

        client.send_message(msg)
        client.quit()
        print(f"Email sent successfully to {to}")

    except Exception as e:
        print(f"Error sending email to {to}: {e}")
