from celery import shared_task
# from .models import StudyResource
import flask_excel as excel
from .mail_service import send_message
from .models import User, Role, ServiceRequest
from jinja2 import Template
from datetime import datetime  # Correct import
# from weasyprint import HTML
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from io import BytesIO


# @shared_task(ignore_result=False)
# def create_resource_csv():
#     stud_res = StudyResource.query.with_entities(
#         StudyResource.topic, StudyResource.description).all()

#     csv_output = excel.make_response_from_query_sets(
#         stud_res, ["topic", "description"], "csv")
#     filename = "test.csv"

#     with open(filename, 'wb') as f:
#         f.write(csv_output.data)

#     return filename


# @shared_task(ignore_result=True)
# def daily_reminder(to, subject):
#     users = User.query.filter(User.roles.any(Role.name == 'admin')).all()
#     for user in users:
#         with open('test.html', 'r') as f:
#             template = Template(f.read())
#             send_message(user.email, subject,
#                          template.render(email=user.email))
#     return "OK"
from celery import shared_task
from .models import ServiceRequest, User, Role
import flask_excel as excel
# from .mail_service import send_message
from jinja2 import Template
from flask import send_file, jsonify
from celery.result import AsyncResult
from datetime import datetime


@shared_task(ignore_result=True)
def say_hello():
    return "Say Hello"

# --------------------- Scheduled Job: Daily Reminders ---------------------
# @shared_task(ignore_result=True)
# def send_daily_reminders():
#     pending_requests = ServiceRequest.query.filter_by(status="Pending").all()
#     for request in pending_requests:
#         professional = request.professional  # Assuming a relationship exists
#         message = f"Reminder: You have a pending service request (ID: {request.id}). Please take action."
        
#         # Send Email Reminder (Example)
#         send_message(professional.email, "Service Reminder", message)
        
#     return f"Sent reminders for {len(pending_requests)} requests."

# --------------------- Scheduled Job: Monthly Activity Report ---------------------
# @shared_task(ignore_result=True)
# def send_monthly_activity_reports():
#     customers = User.query.filter(User.roles.any(Role.name == 'customer')).all()
#     for customer in customers:
#         services = ServiceRequest.query.filter_by(customer_id=customer.id).all()
        
#         # Generate HTML Report
#         report_content = "<h3>Monthly Activity Report</h3><ul>"
#         for service in services:
#             report_content += f"<li>Service ID: {service.id}, Status: {service.status}, Date: {service.date_of_request}</li>"
#         report_content += "</ul>"
        
#         # Send Report via Email
#         send_message(customer.email, "Your Monthly Service Report", report_content)
    
#     return "Monthly reports sent."

@shared_task(ignore_result=True)
def daily_reminder(to, subject):
    # users = User.query.filter(User.roles.any(Role.name == 'admin')).all()
    # for user in users:
    #     with open('test.html', 'r') as f:
    #         template = Template(f.read())
    send_message(to, subject, "hello")
    return "OK"

from celery.schedules import crontab

# @shared_task(ignore_result=True)
# def send_monthly_activity_reports():
#     """Generate and send monthly activity reports to all customers."""
#     customers = User.query.filter(User.roles.any(Role.name == 'customer')).all()

#     for customer in customers:
#         services = ServiceRequest.query.filter_by(customer_id=customer.id).all()
        
#         # Generate HTML Report
#         report_content = f"""
#         <html>
#         <body>
#             <h3>Monthly Activity Report for {customer.username}</h3>
#             <p>Dear {customer.username}, here is your activity summary for {datetime.now().strftime('%B')}:</p>

#             <ul>
#         """
#         for service in services:
#             report_content += f"<li>Service ID: {service.id}, Status: {service.service_status}, Requested On: {service.date_of_request.strftime('%Y-%m-%d')}</li>"
        
#         report_content += """
#             </ul>
#             <p>Thank you for using our service!</p>
#         </body>
#         </html>
#         """

#         # Send Report via Email
# #         send_message('22f3001659@email.com', customer.email, report_content)

#     return "Monthly reports sent."

@shared_task(ignore_result=True)
def send_monthly_activity_reports():
    """Generate and send monthly activity reports to all customers."""
    customers = User.query.filter(User.roles.any(Role.name == "customer")).all()

    for customer in customers:
        services = ServiceRequest.query.filter_by(customer_id=customer.id).all()
        
        # Generate HTML Report
        report_content = f"""
        <html>
        <body>
            <h3>Monthly Activity Report for {customer.username}</h3>
            <p>Dear {customer.username}, here is your activity summary for {datetime.now().strftime('%B')}:</p>

            <ul>
        """
        for service in services:
            report_content += f"<li>Service ID: {service.id}, Status: {service.service_status}, Requested On: {service.date_of_request.strftime('%Y-%m-%d')}</li>"
        
        report_content += """
            </ul>
            <p>Thank you for using our service!</p>
        </body>
        </html>
        """

        # Generate PDF using ReportLab
        pdf_buffer = BytesIO()
        pdf = canvas.Canvas(pdf_buffer, pagesize=letter)
        pdf.setTitle(f"Monthly Report - {customer.username}")
        pdf.drawString(100, 750, f"Monthly Activity Report for {customer.username}")
        pdf.drawString(100, 730, f"Date: {datetime.now().strftime('%B %Y')}")
        pdf.drawString(100, 700, "Summary of your service requests:")

        y_position = 680
        for service in services:
            pdf.drawString(120, y_position, f"Service ID: {service.id}, Status: {service.service_status}, Requested On: {service.date_of_request.strftime('%Y-%m-%d')}")
            y_position -= 20
            if y_position < 50:
                pdf.showPage()  # Start new page if needed
                y_position = 750
        
        pdf.save()
        pdf_buffer.seek(0)  # Reset buffer position for reading

        # Send Email with both HTML & PDF options
        send_message(customer.email, "Monthly Activity Report", report_content, pdf_attachment=pdf_buffer.getvalue())

@shared_task(ignore_result=True)
def daily_professional_reminder():
    """Send daily reminders to service professionals for pending requests."""
    
    # Fetch all professionals
    professionals = User.query.filter(User.roles.any(Role.name == 'professional')).all()

    for professional in professionals:
        # Get pending service requests assigned to the professional
        # pending_requests = ServiceRequest.query.all()
        pending_requests = ServiceRequest.query.filter_by(
            professional_id=professional.id, service_status='pending'
        ).all()

        if pending_requests:
            # Generate the email content
            report_content = f"""
            <html>
            <body>
                <h3>Daily Service Reminder for {professional.username}</h3>
                <p>Dear {professional.username}, you have pending service requests that require action:</p>
                <ul>
            """
            for request in pending_requests:
                report_content += f"<li>Service ID: {request.id}, Requested On: {request.date_of_request.strftime('%Y-%m-%d')}</li>"

            report_content += """
                </ul>
                <p>Please visit your dashboard to accept or reject the requests.</p>
                <p>Thank you for your service!</p>
            </body>
            </html>
            """

            # Send email
            send_message('22f3001659@email.com', professional.email, report_content)

    return "Daily reminders sent to professionals."

@shared_task(ignore_result=False)
def export_closed_service_requests():
    closed_requests = ServiceRequest.query.with_entities(
        ServiceRequest.id, ServiceRequest.service_id, ServiceRequest.customer_id,
        ServiceRequest.professional_id, ServiceRequest.date_of_request,
        ServiceRequest.date_of_completion, ServiceRequest.remarks
    ).all()
    
    csv_output = excel.make_response_from_query_sets(
        closed_requests, ["id", "service_id", "customer_id", "professional_id", "date_of_request", "date_of_completion", "remarks"], "csv")
    filename = "closed_service_requests.csv"
    
    with open(filename, 'wb') as f:
        f.write(csv_output.data)
    
    return filename