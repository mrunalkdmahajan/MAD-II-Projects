from flask import abort, current_app as app, jsonify, request, render_template, send_file, send_from_directory, session
from flask_security import auth_required, roles_required
from werkzeug.security import check_password_hash
from flask_restful import marshal, fields
import flask_excel as excel
from celery.result import AsyncResult
from .tasks import say_hello
from .tasks import export_closed_service_requests
# from .tasks import export_closed_requests_task
from .models import User, db, Service, ServiceRequest, ProfessionalProfile, Review
from .sec import datastore
import uuid
from sqlalchemy import and_, extract, func
from sqlalchemy.exc import SQLAlchemyError
from .instances import cache


from flask import Flask, jsonify, request, render_template
from flask_security import auth_required, roles_required
from flask_restful import marshal, fields
from .models import db, User, Service, ServiceRequest, Review, ProfessionalProfile, RolesUsers

from flask import current_app as app, jsonify, request, render_template, send_file
from flask_security import auth_required, roles_required
from werkzeug.security import check_password_hash
from flask_restful import marshal, fields
import flask_excel as excel
from celery.result import AsyncResult
from .sec import datastore
from flask_security import current_user
from flask import jsonify, request
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta

@app.route('/', methods=['GET'])
def home():
    return render_template("index.html")

@app.get('/home')
def trial():
    return render_template("index.html")
@app.route('/api/services/<int:service_id>', methods=['GET'])
@auth_required("token")
@roles_required("admin")
def get_service(service_id):
    """Retrieve a specific service"""
    
    service = Service.query.get_or_404(service_id)
    
    return jsonify({
        "id": service.id,
        "name": service.name,
        "price": service.price,
        "time_required": service.time_required,
        "description": service.description
    }), 200


# # Admin Dashboard
# @app.get('/admin')
# @auth_required("token")
# @roles_required("admin")
# def admin_dashboard():
#     return "Welcome to the Admin Dashboard"


@app.route('/api/user/profile', methods=['GET'])
@auth_required('token')
def get_user_profile():
    # Debug prints to understand authentication state
    print(f"Current user: {current_user}")
    print(f"Is authenticated: {current_user.is_authenticated}")
    print(f"User roles: {[role.name for role in current_user.roles]}")

    if not current_user.is_authenticated:
        return jsonify({"error": "Unauthorized"}), 401

    user_data = {
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "active": current_user.active,
        "is_blocked": current_user.is_blocked
    }
    return jsonify(user_data), 200

@app.route('/api/user/profile/edit', methods=['PUT'])
@auth_required('token')
# @roles_required('admin')  # If you want to restrict edit to admins
def edit_user_profile():
    if not current_user.is_authenticated:
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json()
    
    # Validate input
    if not data:
        return jsonify({"error": "No input data provided"}), 400
    
    # Extract new username and email
    new_username = data.get('username', '').strip()
    new_email = data.get('email', '').strip()
    
    # Validate username
    if not new_username:
        return jsonify({"error": "Username cannot be empty"}), 400
    
    # Validate email
    if not new_email or '@' not in new_email:
        return jsonify({"error": "Invalid email address"}), 400
    
    # Check if username is already taken (excluding current user)
    existing_user = User.query.filter(
        (User.username == new_username) & (User.id != current_user.id)
    ).first()
    if existing_user:
        return jsonify({"error": "Username is already taken"}), 400
    
    # Check if email is already taken (excluding current user)
    existing_email = User.query.filter(
        (User.email == new_email) & (User.id != current_user.id)
    ).first()
    if existing_email:
        return jsonify({"error": "Email is already in use"}), 400
    
    # Update user profile
    try:
        current_user.username = new_username
        current_user.email = new_email
        db.session.commit()
        
        return jsonify({
            "message": "Profile updated successfully",
            "user": {
                "username": current_user.username,
                "email": current_user.email
            }
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An error occurred while updating profile"}), 500
    
@app.route('/api/professional/profile', methods=['GET'])
@auth_required('token')
def get_professional_profile():
    print(f"Current user: {current_user}")
    print(f"Is authenticated: {current_user.is_authenticated}")
    print(f"User roles: {[role.name for role in current_user.roles]}")

    if not current_user.is_authenticated:
        return jsonify({"error": "Unauthorized"}), 401

    professional_profile = ProfessionalProfile.query.filter_by(user_id=current_user.id).first()

    if not professional_profile:
        return jsonify({"error": "Professional profile not found"}), 404

    profile_data = {
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "active": current_user.active,
        "is_blocked": current_user.is_blocked,
        "name": professional_profile.name,
        "city": professional_profile.city,
        "state": professional_profile.state,
        "pin_code": professional_profile.pin_code,
        "description": professional_profile.description,
        "service_type": professional_profile.service_type,
        "experience": professional_profile.experience,
        "is_verified": professional_profile.is_verified
    }
    return jsonify(profile_data), 200

@app.route('/api/professional/profile/update', methods=['PUT'])
@auth_required('token')
def update_professional_profile():
    data = request.json

    professional_profile = ProfessionalProfile.query.filter_by(user_id=current_user.id).first()
    if not professional_profile:
        return jsonify({"error": "Professional profile not found"}), 404

    professional_profile.name = data.get("name", professional_profile.name)
    professional_profile.city = data.get("city", professional_profile.city)
    professional_profile.state = data.get("state", professional_profile.state)
    professional_profile.pin_code = data.get("pin_code", professional_profile.pin_code)
    professional_profile.description = data.get("description", professional_profile.description)
    professional_profile.service_type = data.get("service_type", professional_profile.service_type)
    professional_profile.experience = data.get("experience", professional_profile.experience)
    professional_profile.is_verified = data.get("is_verified", professional_profile.is_verified)

    db.session.commit()
    return jsonify({"message": "Profile updated successfully!"}), 200




# ---------------- Customer Routes ----------------
@app.route('/api/customer/profile', methods=['GET'])
@auth_required("token")
@roles_required("customer")
def customer_profile():
    
    user = current_user 

    return jsonify({
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "role": "customer"
    })


@app.route("/api/customer/find", methods=["GET"])
@auth_required("token")
@roles_required("customer")
# @cache.cached(timeout=50)
def customer_find():
    user = current_user  # Get the logged-in user
    
    # Ensure the user is authenticated
    if not user or not user.is_authenticated:
        return jsonify({"error": "User not authenticated"}), 401
    
    try:
        services = Service.query.all()
        service_list = [
            {
                "id": service.id,
                "name": service.name,
                "price": service.price,
                "time_required": service.time_required,
                "description": service.description
            }
            for service in services
        ]
        return jsonify(service_list), 200
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500


# ---------------- Professional Routes ----------------
@app.route('/api/professional/profile', methods=['GET'])
@auth_required("token")
@roles_required("professional")
def professional_profile():
    
    user = current_user 

    return jsonify({
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "role": "professional"
    })


@app.route('/api/professional/requests', methods=['GET'])
@auth_required("token")
@roles_required("professional")
@cache.cached(timeout=50)
def professional_requests():
    return jsonify({"message": "Professional Requests Data"})



## Admin Pages

@app.route('/api/view/profile', methods=['GET'])
@auth_required("token")
@roles_required("admin")
def view_profile():
    user = current_user  # Get logged-in admin
    
    # Check if user exists and is authenticated
    if not user or not user.is_authenticated:
        return jsonify({"error": "User not authenticated"}), 401
    
    # Check if user has admin flag (belt and suspenders approach)
    if not user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
        
    return jsonify({
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "active": user.active,
        "is_blocked": user.is_blocked,
        "is_admin": user.is_admin
    })

@app.route('/api/admin/customer/<int:customer_id>/profile', methods=['GET'])
@auth_required("token")
@roles_required('admin')
def admin_view_customer_profile(customer_id):
    customer = User.query.get_or_404(customer_id)
    print(customer_id)
    print("Hiii")
    
    # Fetch customer's profile and service request details
    profile_data = {
        "id": customer.id,
        "username": customer.username,
        "email": customer.email,
        "is_active": customer.active,
        "is_blocked": customer.is_blocked,
        
        # Service request details
        "total_service_requests": len(customer.services_requested),
        "service_requests": [
            {
                "id": sr.id,
                "service_name": sr.service.name,
                "date_of_request": sr.date_of_request.strftime('%Y-%m-%d'),
                "service_status": sr.service_status,
                "professional_name": sr.professional.username if sr.professional else "Not Assigned"
            } for sr in customer.services_requested
        ]
    }
    
    return jsonify(profile_data)



# Fetch User & Professional Profile (Admin Access Only)
@app.route('/api/professionals/<int:prof_id>', methods=['GET'])
@auth_required("token")  # Requires authentication
@roles_required('admin')
def get_admin_professional_profile(prof_id):
    # professional = ProfessionalProfile.query.get(prof_id)
    professional = ProfessionalProfile.query.filter_by(user_id=prof_id).first()
    
    if not professional:
        return jsonify({"error": "Professional not found"}), 404
    
    reviews = Review.query.filter_by(professional_id=prof_id).all()
    
    return jsonify({
        "professional": {
            "id": professional.id,
            "name": professional.name,
            "city": professional.city,
            "state": professional.state,
            "pin_code": professional.pin_code,
            "date_created": professional.date_created,
            "description": professional.description,
            "service_type": professional.service_type,
            "experience": professional.experience,
            "is_verified": professional.is_verified
        },
        "reviews": [
            {
                "id": review.id,
                "rating": review.rating,
                "comments": review.comments,
                "created_at": review.created_at
            } for review in reviews
        ]
    })


@app.route('/api/admin/profile', methods=['GET'])
@auth_required("token")
@roles_required("admin")
def admin_profile():
    try:
        # Detailed logging
        print(f"Current User: {current_user}")
        print(f"Is Authenticated: {current_user.is_authenticated}")
        print(f"User Roles: {[role.name for role in current_user.roles]}")

        if not current_user or not current_user.is_authenticated:
            return jsonify({"error": "Not authenticated"}), 401

        if not any(role.name == 'admin' for role in current_user.roles):
            return jsonify({"error": "Unauthorized access"}), 403

        return jsonify({
            "id": current_user.id,
            "username": current_user.username,
            "email": current_user.email,
            "active": current_user.active,
            "is_blocked": current_user.is_blocked,
            "is_admin": any(role.name == 'admin' for role in current_user.roles)
        }), 200

    except Exception as e:
        # Log the full exception
        print(f"Error in admin_profile: {e}", exc_info=True)
        
        # Return a structured error response
        return jsonify({
            "error": "Internal server error",
            "details": str(e)
        }), 500


@app.route('/api/admin/profile/update', methods=['PUT'])
@auth_required("token")
@roles_required("admin")
def update_admin_profile():
    user = current_user
    
    if not user or not user.is_authenticated:
        return jsonify({"error": "User not authenticated"}), 401

    data = request.json
    
    user.username = data.get("username", user.username)
    user.email = data.get("email", user.email)
    user.active = data.get("active", user.active)
    user.is_blocked = data.get("is_blocked", user.is_blocked)
    user.is_admin = data.get("is_admin", user.is_admin)

    db.session.commit()

    return jsonify({"message": "Profile updated successfully"}), 200


@app.route('/api/admin/professionals/blocked', methods=['GET'])
@auth_required("token")
@roles_required("admin")
def get_blocked_professionals():
    if not current_user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
    
    # Query users who are professionals (have a profile) and are blocked
    blocked_pros = User.query.join(ProfessionalProfile).filter(
        User.is_blocked == True
    ).all()
    
    return jsonify([{
        "id": pro.id,
        "username": pro.username,
        "email": pro.email,
        "profile": {
            "service_type": pro.profile.service_type,
            "experience": pro.profile.experience,
            "description": pro.profile.description
        } if pro.profile else None
    } for pro in blocked_pros])

@app.route('/api/admin/customers/blocked', methods=['GET'])
@auth_required("token")
@roles_required("admin")
def get_blocked_customers():
    if not current_user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
    
    # Query users who are customers (don't have a profile) and are blocked
    blocked_customers = User.query.outerjoin(ProfessionalProfile).filter(and_(User.is_blocked == True, ProfessionalProfile.id == None)
    ).all()
    
    return jsonify([{
        "id": customer.id,
        "username": customer.username,
        "email": customer.email
    } for customer in blocked_customers])

@app.route('/api/admin/professionals/pending', methods=['GET'])
@auth_required("token")
@roles_required("admin")
def get_pending_verifications():
    if not current_user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
    
    # Fetch professionals who are NOT verified
    pending_professionals = ProfessionalProfile.query.filter_by(is_verified=False).all()

    professionals_data = []
    for pro in pending_professionals:
        professionals_data.append({
            "id": pro.user.id,
            "username": pro.user.username,
            "email": pro.user.email,
            "profile": {
                "service_type": pro.service_type,
                "experience": pro.experience,
                "description": pro.description
            }
        })
    
    return jsonify(professionals_data)

@app.route('/api/admin/professionals/<int:user_id>/verify', methods=['POST'])
@auth_required("token")
@roles_required("admin")
def verify_professional(user_id):
    """Admin route to verify or reject a professional profile."""
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    professional_profile = ProfessionalProfile.query.filter_by(user_id=user.id).first()
    if not professional_profile:
        return jsonify({"error": "User does not have a professional profile"}), 400

    try:
        data = request.get_json()
        if "approved" not in data:
            return jsonify({"error": "Missing 'approved' field"}), 400

        approved = data["approved"]

        if not isinstance(approved, bool):
            return jsonify({"error": "'approved' must be a boolean (true/false)"}), 400

        professional_profile.is_verified = approved
        db.session.commit()

        message = "Professional verified successfully" if approved else "Professional verification rejected"
        return jsonify({"message": message, "is_verified": professional_profile.is_verified})

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


@app.route('/api/admin/professionals/<int:user_id>/details', methods=['GET'])
@auth_required("token")
@roles_required("admin")
def get_professional_detail(user_id):
    if not current_user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403

    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    profile = ProfessionalProfile.query.filter_by(user_id=user.id).first()

    professional_data = {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "roles": [role.name for role in user.roles],  # Fetch role names
        "profile": {
            "service_type": profile.service_type if profile else None,
            "experience": profile.experience if profile else None,
            "description": profile.description if profile else None,
            "city": profile.city if profile else None,
            "state": profile.state if profile else None,
            "pin_code": profile.pin_code if profile else None,
            "is_verified": profile.is_verified if profile else False
        }
    }

    return jsonify(professional_data)


@app.route('/api/admin/users/<int:user_id>/unblock', methods=['POST'])
@auth_required("token")
@roles_required("admin")
def unblock_user(user_id):
    if not current_user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    try:
        user.is_blocked = False
        db.session.commit()
        return jsonify({"message": "User unblocked successfully"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500



@app.route('/api/admin/users/<int:user_id>/block', methods=['POST'])
@auth_required("token")
@roles_required("admin")
def block_user(user_id):
    if not current_user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404
        
    # Prevent admin from blocking themselves
    if user.id == current_user.id:
        return jsonify({"error": "Cannot block yourself"}), 400
    
    try:
        user.is_blocked = True
        db.session.commit()
        return jsonify({"message": "User blocked successfully"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@app.route('/api/admin/professionals/all', methods=['GET'])
@auth_required("token")
@roles_required("admin")
@cache.cached(timeout=50)
def get_all_professionals():
    
    if not current_user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
    
    professionals = User.query.join(ProfessionalProfile).all()
    
    return jsonify([{
        "id": pro.id,
        "username": pro.username,
        "email": pro.email,
        "active": pro.active,
        "is_blocked": pro.is_blocked,
        "profile": {
            "service_type": pro.profile.service_type,
            "experience": pro.profile.experience,
            "description": pro.profile.description,
            "average_rating": db.session.query(db.func.avg(Review.rating))
                            .filter(Review.professional_id == pro.profile.id)
                            .scalar() or 0
        } if pro.profile else None
    } for pro in professionals])

@app.route('/api/admin/dashboard/stats', methods=['GET'])
@auth_required("token")
@roles_required("admin")
@cache.cached(timeout=50)
def get_dashboard_stats():
    if not current_user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
    
    # Basic stats
    total_users = User.query.count()
    total_professionals = User.query.join(ProfessionalProfile).count()
    total_customers = total_users - total_professionals
    blocked_users = User.query.filter_by(is_blocked=True).count()
    pending_verifications = User.query.join(ProfessionalProfile).filter_by(active=False).count()
    
    # Service request stats
    total_requests = ServiceRequest.query.count()
    pending_requests = ServiceRequest.query.filter_by(service_status='requested').count()
    completed_requests = ServiceRequest.query.filter_by(service_status='closed').count()
    
    return jsonify({
        "user_stats": {
            "total_users": total_users,
            "total_professionals": total_professionals,
            "total_customers": total_customers,
            "blocked_users": blocked_users,
            "pending_verifications": pending_verifications
        },
        "service_stats": {
            "total_requests": total_requests,
            "pending_requests": pending_requests,
            "completed_requests": completed_requests
        }
    })


## Admin pages end

import traceback

@app.route('/user-login', methods=['POST'])
def user_login():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"message": "Invalid request format"}), 400

        # Retrieve email and password
        email = data.get('email')
        password = data.get('password')
        print(f"Received email: {email}, password: {password}")

        # Validate input
        if not email or not password:
            return jsonify({"message": "Email and password are required"}), 400

        # Retrieve user from datastore
        user = datastore.find_user(email=email)
        if not user:
            return jsonify({"message": "User Not Found"}), 404

        print(f"Stored password hash: {user.password}")

        # Check password
        if check_password_hash(user.password, password):
            auth_token = user.get_auth_token()
            role = user.roles[0].name if user.roles else 'user'

            return jsonify({
                "message": "Login successful",
                "token": auth_token,
                "email": user.email,
                "role": role
            })
        else:
            return jsonify({"message": "Incorrect password"}), 401

    except Exception as e:
        print("ERROR:", traceback.format_exc())  # Prints full error traceback
        return jsonify({"message": "Internal Server Error"}), 500



@app.route('/api/register_customer', methods=['POST'])
def api_register_customer():
    data = request.json

    # Extract basic user information
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    confirm_password = data.get('confirmPassword')

    # Validate required fields
    if not all([username, email, password, confirm_password]):
        return jsonify({"error": "Please fill out all required fields."}), 400

    # Validate password match
    if password != confirm_password:
        return jsonify({"error": "Passwords do not match."}), 400

    # Check for existing user
    existing_user = User.query.filter((User.username == username) | (User.email == email)).first()
    if existing_user:
        return jsonify({"error": "Username or email already exists."}), 400

    try:
        # Create new user with customer role
        new_user = User(
            username=username,
            email=email,
            password=generate_password_hash(password),
            active=True,
            fs_uniquifier=str(uuid.uuid4())
        )
        db.session.add(new_user)
        db.session.flush()

        # Assign customer role
        customer_role = RolesUsers(user_id=new_user.id, role_id=3)  # Assuming 1 is customer role ID
        db.session.add(customer_role)

        db.session.commit()
        return jsonify({"message": "Customer registered successfully."}), 201

    except Exception as e:
        db.session.rollback()
        print(f"Registration error: {str(e)}")
        return jsonify({"error": "Failed to register customer."}), 500

# @app.route('/api/register-professional', methods=['POST'])
# def api_register_professional():
#     data = request.json

#     # Extract user information
#     username = data.get('username')
#     email = data.get('email')
#     password = data.get('password')
#     confirm_password = data.get('confirmPassword')

#     # Extract profile information
#     profile_data = data.get('profile', {})
#     prof_name = profile_data.get('name')
#     service_type = profile_data.get('service_type')
#     experience = profile_data.get('experience')
#     description = profile_data.get('description')

#     # Validate required fields
#     if not all([username, email, password, confirm_password, prof_name, service_type, experience]):
#         return jsonify({"error": "Please fill out all required fields."}), 400

#     # Validate password match
#     if password != confirm_password:
#         return jsonify({"error": "Passwords do not match."}), 400

#     # Check for existing user
#     existing_user = User.query.filter((User.username == username) | (User.email == email)).first()
#     if existing_user:
#         return jsonify({"error": "Username or email already exists."}), 400

#     try:
#         # Create new user with professional role
#         new_user = User(
#             username=username,
#             email=email,
#             password=generate_password_hash(password),
#             active=True,
#             fs_uniquifier=str(uuid.uuid4())
#         )
#         db.session.add(new_user)
#         db.session.flush()

#         # Assign professional role
#         professional_role = RolesUsers(user_id=new_user.id, role_id=2)  # Assuming 2 is professional role ID
#         db.session.add(professional_role)

#         # Create professional profile
#         new_profile = ProfessionalProfile(
#             user_id=new_user.id,
#             name=prof_name,
#             date_created=datetime.utcnow(),
#             description=description,
#             service_type=service_type,
#             experience=experience
#         )
#         db.session.add(new_profile)

#         db.session.commit()
#         return jsonify({"message": "Professional registered successfully."}), 201

#     except Exception as e:
#         db.session.rollback()
#         print(f"Registration error: {str(e)}")
#         return jsonify({"error": "Failed to register professional."}), 500

from flask import request, jsonify
from werkzeug.security import generate_password_hash
from datetime import datetime
import uuid

@app.route('/api/register-professional', methods=['POST'])
def api_register_professional():
    data = request.json

    # Extract user information
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    confirm_password = data.get('confirmPassword')

    # Extract professional profile data
    profile_data = data.get('profile', {})
    prof_name = profile_data.get('name')
    service_type = profile_data.get('service_type')
    experience = profile_data.get('experience')
    description = profile_data.get('description')
    city = profile_data.get('city')
    state = profile_data.get('state')
    pin_code = profile_data.get('pin_code')

    # Validate required fields
    if not all([username, email, password, confirm_password, prof_name, service_type, experience, city, state, pin_code]):
        return jsonify({"error": "Please fill out all required fields."}), 400

    # Validate password match
    if password != confirm_password:
        return jsonify({"error": "Passwords do not match."}), 400

    # Check for existing user (only validate email as username is not unique)
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        return jsonify({"error": "Email already exists."}), 400

    try:
        # Create new user
        new_user = User(
            username=username,
            email=email,
            password=generate_password_hash(password),
            active=True,
            fs_uniquifier=str(uuid.uuid4())
        )
        db.session.add(new_user)
        db.session.flush()  # Ensure user ID is available before creating profile and roles

        # Assign professional role (Check that role ID 2 is correct)
        professional_role = RolesUsers(user_id=new_user.id, role_id=2)  
        db.session.add(professional_role)

        # Create professional profile
        new_profile = ProfessionalProfile(
            user_id=new_user.id,
            name=prof_name,
            city=city,
            state=state,
            pin_code=pin_code,
            date_created=datetime.utcnow(),
            description=description,
            service_type=service_type,
            experience=experience
        )
        db.session.add(new_profile)

        db.session.commit()
        return jsonify({"message": "Professional registered successfully."}), 201

    except Exception as e:
        db.session.rollback()
        print(f"Registration error: {str(e)}")
        return jsonify({"error": "Failed to register professional."}), 500

@app.route('/api/users/search', methods=['GET'])
# @cache.cached(timeout=50)
def search_users():
    # Get search parameters from request
    username = request.args.get('username', '')
    profile_name = request.args.get('profile_name', '')
    user_type = request.args.get('user_type', 'all')

    # Start with a base query
    prof_query = db.session.query(User).join(User.profile).options(
        db.joinedload(User.roles),
        db.joinedload(User.profile)
    )
    
    # Apply filters for professionals
    if username:
        prof_query = prof_query.filter(User.username.ilike(f"%{username}%"))
    if profile_name:
        prof_query = prof_query.filter(ProfessionalProfile.name.ilike(f"%{profile_name}%"))

    # Get customers query
    customer_query = db.session.query(User).outerjoin(User.profile).filter(
        User.profile == None
    ).options(db.joinedload(User.roles))

    if username:
        customer_query = customer_query.filter(User.username.ilike(f"%{username}%"))

    # Execute queries based on user_type
    professionals = []
    customers = []

    if user_type in ['all', 'professional']:
        professionals = prof_query.all()
    if user_type in ['all', 'customer']:
        customers = customer_query.all()

    # Prepare response data
    result = {
        'professionals': [{
            'id': prof.id,
            'username': prof.username,
            'roles': [{'name': role.name} for role in prof.roles],
            'profile': {
                'id': prof.profile.id,
                'name': prof.profile.name,
                'service_type': prof.profile.service_type,
                'experience': prof.profile.experience,
                'description': prof.profile.description
            }
        } for prof in professionals],
        'customers': [{
            'id': customer.id,
            'username': customer.username,
            'email': customer.email,
            'roles': [{'name': role.name} for role in customer.roles],
            'services_requested': len(customer.services_requested)
        } for customer in customers]
    }

    return jsonify(result)


@app.route('/api/services/search', methods=['GET'])
@auth_required("token")
@roles_required("customer")
# @cache.cached(timeout=50)
def search_services():
    user = current_user  # Get the logged-in user
    
    # Ensure the user is authenticated
    if not user or not user.is_authenticated:
        return jsonify({"error": "User not authenticated"}), 401
    # Get search parameters from request
    professional_name = request.args.get('professional_name', '')  # Changed from service_name
    service_type = request.args.get('service_type', '')
    city = request.args.get('city', '')
    state = request.args.get('state', '')
    pin_code = request.args.get('pin_code', '')

    # Base query joining services with professionals
    query = db.session.query(
        Service, ProfessionalProfile
    ).join(
        ProfessionalProfile, ProfessionalProfile.service_type == Service.name, isouter=True
    ).filter(
        ProfessionalProfile.is_verified == True,  # Only verified professionals
        User.is_blocked == False  # Only unblocked professionals
    )

    # Apply filters
    if professional_name:  # Changed from service_name
        query = query.filter(ProfessionalProfile.name.ilike(f'%{professional_name}%'))
    
    if service_type:
        query = query.filter(ProfessionalProfile.service_type.ilike(f'%{service_type}%'))
    
    if city:
        query = query.filter(ProfessionalProfile.city.ilike(f'%{city}%'))
    
    if state:
        query = query.filter(ProfessionalProfile.state.ilike(f'%{state}%'))
    
    if pin_code:
        query = query.filter(ProfessionalProfile.pin_code == pin_code)

    # Execute query
    results = query.all()
    
    # Format results
    services = []
    for service, professional in results:
        if service and professional:
            services.append({
                'id': service.id,
                'name': service.name,
                'price': service.price,
                'time_required': service.time_required,
                'description': service.description,
                'professional': {
                    'id': professional.id,
                    'user_id': professional.user_id,
                    'name': professional.name,
                    'city': professional.city,
                    'state': professional.state,
                    'pin_code': professional.pin_code,
                    'service_type': professional.service_type,
                    'experience': professional.experience,
                    'is_verified': professional.is_verified
                }
            })
    
    return jsonify({'services': services})

# Alternative approach: Search for professionals by location first
@app.route('/api/professionals/search-by-location', methods=['GET'])
@auth_required("token")
@roles_required("customer")
@cache.cached(timeout=50)
def search_professionals_by_location():
    user = current_user  # Get the logged-in user
    
    # Ensure the user is authenticated
    if not user or not user.is_authenticated:
        return jsonify({"error": "User not authenticated"}), 401
    # Get search parameters from request
    service_type = request.args.get('service_type', '')
    city = request.args.get('city', '')
    state = request.args.get('state', '')
    pin_code = request.args.get('pin_code', '')
    
    # Build query for professionals
    query = ProfessionalProfile.query
    
    if service_type:
        query = query.filter(ProfessionalProfile.service_type.ilike(f'%{service_type}%'))
    
    if city:
        query = query.filter(ProfessionalProfile.city.ilike(f'%{city}%'))
    
    if state:
        query = query.filter(ProfessionalProfile.state.ilike(f'%{state}%'))
    
    if pin_code:
        query = query.filter(ProfessionalProfile.pin_code == pin_code)
    
    # Get results
    professionals = query.all()
    
    # Format response
    result = []
    for prof in professionals:
        # Get user details
        user = User.query.get(prof.user_id)
        
        result.append({
            'id': prof.id,
            'user_id': prof.user_id,
            'username': user.username if user else None,
            'name': prof.name,
            'city': prof.city,
            'state': prof.state,
            'pin_code': prof.pin_code,
            'service_type': prof.service_type,
            'experience': prof.experience,
            'description': prof.description,
            'is_verified': prof.is_verified
        })
    
    return jsonify({'professionals': result})

@app.route('/api/service/<int:service_id>', methods=['GET'])
@auth_required("token")
@roles_required("customer")
def get_service_details(service_id):
    token = request.headers.get("Authentication-Token") or request.headers.get("Authorization")
    if not token:
        return jsonify({"error": "Missing authentication token"}), 403
    user = current_user  # Get the logged-in user
    
    # Ensure the user is authenticated
    if not user or not user.is_authenticated:
        return jsonify({"error": "User not authenticated"}), 401

    """Get details for a specific service by ID"""
    try:
        # Query for the service and join with professional data
        service_data = db.session.query(
            Service, ProfessionalProfile
        ).join(
            ProfessionalProfile, ProfessionalProfile.service_type == Service.name
        ).filter(
            Service.id == service_id
        ).first()
        
        if not service_data:
            return jsonify({'error': 'Service not found'}), 404
            
        service, professional = service_data
        
        # Format the response
        service_details = {
            'id': service.id,
            'name': service.name,
            'price': service.price,
            'time_required': service.time_required,
            'description': service.description,
            'professional': {
                'id': professional.id,
                'user_id': professional.user_id,
                'name': professional.name,
                'city': professional.city,
                'state': professional.state,
                'pin_code': professional.pin_code,
                'service_type': professional.service_type,
                'experience': professional.experience,
                'is_verified': professional.is_verified
            }
        }
        
        return jsonify({'service': service_details}), 200
        
    except Exception as e:
        app.logger.error(f"Error fetching service details: {str(e)}")
        return jsonify({'error': 'An error occurred while fetching service details'}), 500



@app.route('/api/service-requests', methods=['POST'])
@auth_required("token")
@roles_required("customer")
def create_service_request():
    user = current_user  # Get the logged-in user
    
    # Ensure the user is authenticated
    if not user or not user.is_authenticated:
        return jsonify({"error": "User not authenticated"}), 401

    """Create a new service request with optional remarks"""
    try:
        # Get JSON data from request
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        service_id = data.get('service_id')
        remarks = data.get('remarks', '')
        
        if not service_id:
            return jsonify({'error': 'Service ID is required'}), 400
        
        # Verify current_user is available and authenticated
        if not current_user or not current_user.is_authenticated:
            return jsonify({'error': 'User not authenticated'}), 401
        
        # Get the service to find the professional
        try:
            service_data = db.session.query(
                Service, ProfessionalProfile
            ).join(
                ProfessionalProfile, ProfessionalProfile.service_type == Service.name
            ).filter(
                Service.id == service_id
            ).first()
            
            if not service_data:
                return jsonify({'error': 'Service not found'}), 404
                
            service, professional = service_data
            
        except SQLAlchemyError as db_error:
            app.logger.error(f"Database query error: {str(db_error)}")
            return jsonify({'error': 'Error retrieving service information'}), 500
        
        # Create a new service request
        try:
            new_request = ServiceRequest(
                service_id=service_id,
                customer_id=current_user.id,
                professional_id=professional.user_id,
                date_of_request=datetime.now(),
                service_status='requested',
                remarks=remarks
            )
            
            db.session.add(new_request)
            db.session.commit()
            
            return jsonify({
                'message': 'Service request created successfully',
                'request_id': new_request.id
            }), 201
            
        except SQLAlchemyError as db_error:
            db.session.rollback()
            app.logger.error(f"Database insertion error: {str(db_error)}")
            return jsonify({'error': 'Error saving service request'}), 500
            
    except Exception as e:
        app.logger.error(f"Unexpected error in create_service_request: {str(e)}")
        # Log the full traceback for debugging
        import traceback
        app.logger.error(traceback.format_exc())
        return jsonify({'error': 'An unexpected error occurred'}), 500

## Customer Pages end

@app.route('/api/service_material', methods=['GET'])
def get_service_material():
    data = {"materials": ["wood", "metal", "plastic"]}
    return jsonify(data)


# Admin Services
@app.route('/api/services', methods=['GET'])
@auth_required("token")
@roles_required("admin")
def get_services():
    user = current_user  # Get logged-in admin
    
    # Check if user exists and is authenticated
    if not user or not user.is_authenticated:
        return jsonify({"error": "User not authenticated"}), 401
    
    # Check if user has admin flag (belt and suspenders approach)
    if not user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
    
    services = Service.query.all()
    service_list = [
        {
            "id": service.id,
            "name": service.name,
            "price": service.price,
            "time_required": service.time_required,
            "description": service.description
        }
        for service in services
    ]
    return jsonify(service_list), 200

@app.route('/api/services/<int:service_id>', methods=['PUT'])
@auth_required("token")
@roles_required("admin")
def update_service(service_id):
    """Update a specific service"""
    user = current_user
    
    # Check if user exists and is authenticated
    if not user or not user.is_authenticated:
        return jsonify({"error": "User not authenticated"}), 401
    
    # Check if user has admin flag
    if not user.is_admin:
        return jsonify({"error": "Unauthorized access"}), 403
    
    # Find the service
    service = Service.query.get(service_id)
    
    # Check if service exists
    if not service:
        return jsonify({"error": "Service not found"}), 404
    
    # Get data from request
    data = request.get_json()
    
    # Validate input
    if not data:
        return jsonify({"error": "No input data provided"}), 400
    
    # Update service fields
    service.name = data.get('name', service.name)
    service.price = data.get('price', service.price)
    service.time_required = data.get('time_required', service.time_required)
    service.description = data.get('description', service.description)
    
    try:
        # Commit changes to database
        db.session.commit()
        
        return jsonify({
            "message": "Service updated successfully",
            "service": {
                "id": service.id,
                "name": service.name
            }
        }), 200
    except Exception as e:
        # Rollback in case of error
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@app.route("/api/services/<int:service_id>", methods=["DELETE"])
@auth_required('token')
def delete_service(service_id):
    service = Service.query.get(service_id)
    
    if not service:
        return jsonify({"error": "Service not found"}), 404

    try:
        db.session.delete(service)
        db.session.commit()
        return jsonify({"message": "Service deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": f"Failed to delete service: {str(e)}"}), 500

# Update service request (for editing remarks)
# @app.route('/api/c_service-requests/<int:request_id>', methods=['PUT'])
# @auth_required('token')
# @roles_required("customer")
# def update_service_request(request_id):
#     data = request.get_json()  # Ensure this line executes properly
#     if not data:
#         return jsonify({'error': 'No data received'}), 400
#     user = current_user
#     # if not is_customer(): 
#     #     abort(403, description="Only customers can access this endpoint")
    
#     # Find the service request
#     service_request = ServiceRequest.query.get(request_id)
    
#     # Check if service request exists
#     if not service_request:
#         abort(404, description="Service request not found")
    
#     # Check if the service request belongs to the current customer
#     if service_request.customer_id != current_user.id:
#         abort(403, description="You don't have permission to update this service request")
    
#     # Allow updating remarks
#     if 'remarks' in data:
#         service_request.remarks = data['remarks']

#     # Allow updating status (only to 'closed')
#     if 'status' in data and data['status'] == 'closed':
#         service_request.service_status = 'closed'  # Update status
    
#     # Check if the service request is in 'requested' status
#     if service_request.service_status not in ['requested', 'assigned']:
#         abort(400, description="Only 'requested' or 'assigned' service requests can be updated")
    
#     # Get request data
#     data = request.get_json()
    
#     # Update remarks
#     if 'remarks' in data:
#         service_request.remarks = data['remarks']
    
#     # Save changes
#     db.session.commit()
    
#     return jsonify({'message': 'Service request updated successfully'})


# @app.route('/api/c_service-requests/<int:request_id>', methods=['PUT'])
# @auth_required('token')
# @roles_required("customer")
# def update_service_request(request_id):
#     data = request.get_json()

#     if not data:
#         return jsonify({'error': 'No data received'}), 400

#     user = current_user

#     # Find the service request
#     service_request = ServiceRequest.query.get(request_id)
    
#     if not service_request:
#         abort(404, description="Service request not found")

#     # Check if request belongs to the user
#     if service_request.customer_id != user.id:
#         abort(403, description="You don't have permission to update this request")

#     # Only allow updates if status is 'requested' or 'assigned'
#     if service_request.service_status not in ['requested', 'assigned']:
#         return jsonify({'error': "Only 'requested' or 'assigned' service requests can be updated"}), 400

#     # Update remarks
#     if 'remarks' in data:
#         service_request.remarks = data['remarks']

#     # Update status (only allow 'closed')
#     if 'status' in data and data['status'] == 'closed':
#         service_request.service_status = 'closed'

#     db.session.commit()
    
#     return jsonify({'message': 'Service request updated successfully'})


@app.route('/api/c_service-requests/<int:request_id>', methods=['PUT'])
@auth_required('token')
@roles_required("customer")
def update_service_request(request_id):
    data = request.get_json()

    if not data:
        return jsonify({'error': 'No data received'}), 400

    user = current_user  # Get the authenticated user

    # Find the service request
    service_request = ServiceRequest.query.get(request_id)
    
    if not service_request:
        abort(404, description="Service request not found")

    # Check if the request belongs to the user
    if service_request.customer_id != user.id:
        abort(403, description="You don't have permission to update this request")

    # Only allow updates if status is 'requested' or 'assigned'
    if service_request.service_status not in ['requested', 'assigned', 'closed']:
        return jsonify({'error': "Only 'requested', 'assigned', or 'closed' service requests can be updated"}), 400

    # Update remarks if provided
    if 'remarks' in data:
        service_request.remarks = data['remarks']

    # Handle closing the request and creating a review
    if 'status' in data and data['status'] == 'closed':
        service_request.service_status = 'closed'

        # Ensure rating and comments are provided
        rating = data.get('rating')
        comments = data.get('comments', '')

        if rating is None:
            return jsonify({'error': 'Rating is required to complete the service request'}), 400

        try:
            rating = float(rating)
            if rating < 0 or rating > 5:
                return jsonify({'error': 'Rating must be between 0 and 5'}), 400
        except ValueError:
            return jsonify({'error': 'Invalid rating value'}), 400

        # Ensure the professional exists
        if not service_request.professional_id:
            return jsonify({'error': 'No professional assigned to this request'}), 400

        # Create the review
        new_review = Review(
            professional_id=service_request.professional_id,
            customer_id=user.id,
            service_request_id=request_id,
            rating=rating,
            comments=comments
        )

        db.session.add(new_review)

    # Commit all changes to the database
    db.session.commit()
    
    return jsonify({'message': 'Service request updated successfully, review saved'})



@app.route("/api/services", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def create_service():
    try:
        # Get and validate the request data
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400

        required_fields = ["name", "price", "time_required", "description"]
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        # Create new service
        new_service = Service(
            name=data["name"],
            price=float(data["price"]),
            time_required=int(data["time_required"]),
            description=data["description"]
        )
        
        db.session.add(new_service)
        db.session.commit()
        
        return jsonify({
            "message": "Service created successfully!",
            "service": {
                "id": new_service.id,
                "name": new_service.name,
                "price": new_service.price,
                "time_required": new_service.time_required,
                "description": new_service.description
            }
        }), 201
    
    except Exception as e:
        db.session.rollback()
        print(f"Error creating service: {str(e)}")  # Add logging
        return jsonify({"error": "An error occurred while creating the service"}), 500



from celery import current_app, shared_task
from flask import Flask, jsonify
from celery import shared_task
import flask_excel as excel

@app.get('/say-hello')
def say_hello_view():
    res = say_hello.delay()
    return jsonify({"task_id":res.id}), 202




@app.get('/export-service-requests')
def export_service_requests():
    task = export_closed_service_requests.delay()
    return jsonify({"task-id": task.id})

@app.get('/get-service-requests-csv/<task_id>')
def get_service_requests_csv(task_id):
    res = AsyncResult(task_id)
    if res.ready():
        filename = res.result
        return send_file(filename, as_attachment=True)
        # return jsonify({"message": "Task Completed"})
    else:
        return jsonify({"message": "Task Pending"}), 404

@app.route('/api/service-requests', methods=['GET'])
@auth_required("token")
@roles_required("professional")
def get_service_requests():
    try:
        # If user is admin, return all requests
        if current_user.is_admin:
            requests = ServiceRequest.query.all()
        # If user has a professional profile, return only requests matching their service type
        elif current_user.profile:
            # Get professional's service type
            professional_service_type = current_user.profile.service_type
            
            # Find services matching this professional's service type
            services = Service.query.filter_by(name=professional_service_type).all()
            service_ids = [service.id for service in services]
            
            # Get requests that:
            # 1. Match the professional's service type AND are in "requested" status
            # 2. OR are already assigned to this professional
            requests = ServiceRequest.query.filter(
                ((ServiceRequest.service_id.in_(service_ids)) & 
                 (ServiceRequest.service_status == 'requested')) |
                (ServiceRequest.professional_id == current_user.id)
            ).all()
        else:
            # Regular customers only see their requests
            requests = ServiceRequest.query.filter_by(customer_id=current_user.id).all()
        
        result = []
        for req in requests:
            # Get associated service details
            service = Service.query.get(req.service_id)
            # Get customer details
            customer = User.query.get(req.customer_id)
            # Get professional details if assigned
            professional = None
            if req.professional_id:
                professional = User.query.get(req.professional_id)
            
            result.append({
                'id': req.id,
                'service': {
                    'id': service.id,
                    'name': service.name,
                    'price': service.price
                } if service else None,
                'customer': {
                    'id': customer.id,
                    'username': customer.username,
                    'email': customer.email
                } if customer else None,
                'professional': {
                    'id': professional.id,
                    'username': professional.username if professional else None
                } if professional else None,
                'professional_id': req.professional_id,
                'date_of_request': req.date_of_request.isoformat() if req.date_of_request else None,
                'date_of_completion': req.date_of_completion.isoformat() if req.date_of_completion else None,
                'service_status': req.service_status,
                'remarks': req.remarks
            })
            
        return jsonify(result)
    
    except Exception as e:
        current_app.logger.error(f"Error fetching service requests: {str(e)}")
        return str(e), 500
    


@app.route('/api/user', methods=['GET'])
@auth_required('token')
def get_current_user():
    try:
        # Get professional profile if it exists
        profile = ProfessionalProfile.query.filter_by(user_id=current_user.id).first()
        
        user_data = {
            'id': current_user.id,
            'username': current_user.username,
            'email': current_user.email,
            'is_admin': current_user.is_admin,
            'profile': None
        }
        
        # Add profile information if it exists
        if profile:
            user_data['profile'] = {
                'id': profile.id,
                'name': profile.name,
                'service_type': profile.service_type,
                'is_verified': profile.is_verified
            }
            
        return jsonify(user_data)
    except Exception as e:
        return str(e), 500
    

@app.route('/api/service-requests/<int:request_id>/status', methods=['PUT'])
@auth_required("token")
@roles_required("professional")
def update_service_request_status(request_id):
    try:
        data = request.get_json()
        new_status = data.get('status')
        remarks = data.get('remarks', '')

        # Fetch the service request
        service_request = ServiceRequest.query.get(request_id)
        if not service_request:
            return jsonify({"error": "Service request not found"}), 404

        # Ensure the professional can only update relevant requests
        if service_request.professional_id and service_request.professional_id != current_user.id:
            return jsonify({"error": "Unauthorized access"}), 403

        # If the request is being accepted, assign the professional
        if new_status == 'assigned':
            service_request.professional_id = current_user.id

        # Update status and remarks
        service_request.service_status = new_status
        service_request.remarks = remarks
        db.session.commit()

        return jsonify({"message": "Request status updated successfully"})

    except Exception as e:
        current_app.logger.error(f"Error updating service request status: {str(e)}")
        return jsonify({"error": str(e)}), 500
    


########################################################

@app.route('/api/c_service-requests', methods=['GET'])
@auth_required("token")
@roles_required("customer")
def c_get_service_requests():
    try:
        # If user is admin, return all requests
        if current_user.is_admin:
            requests = ServiceRequest.query.all()
        # If user has a professional profile, return only requests matching their service type
        elif current_user.profile:
            # Get professional's service type
            professional_service_type = current_user.profile.service_type
            
            # Find services matching this professional's service type
            services = Service.query.filter_by(name=professional_service_type).all()
            service_ids = [service.id for service in services]
            
            # Get requests that:
            # 1. Match the professional's service type AND are in "requested" status
            # 2. OR are already assigned to this professional
            requests = ServiceRequest.query.filter(
                ((ServiceRequest.service_id.in_(service_ids)) & 
                 (ServiceRequest.service_status == 'requested')) |
                (ServiceRequest.professional_id == current_user.id)
            ).all()
        else:
            # Regular customers only see their requests
            requests = ServiceRequest.query.filter_by(customer_id=current_user.id).all()
        
        result = []
        for req in requests:
            # Get associated service details
            service = Service.query.get(req.service_id)
            # Get customer details
            customer = User.query.get(req.customer_id)
            # Get professional details if assigned
            professional = None
            if req.professional_id:
                professional = User.query.get(req.professional_id)
            
            result.append({
                'id': req.id,
                'service': {
                    'id': service.id,
                    'name': service.name,
                    'price': service.price
                } if service else None,
                'customer': {
                    'id': customer.id,
                    'username': customer.username,
                    'email': customer.email
                } if customer else None,
                'professional': {
                    'id': professional.id,
                    'username': professional.username if professional else None
                } if professional else None,
                'professional_id': req.professional_id,
                'date_of_request': req.date_of_request.isoformat() if req.date_of_request else None,
                'date_of_completion': req.date_of_completion.isoformat() if req.date_of_completion else None,
                'service_status': req.service_status,
                'remarks': req.remarks
            })
            
        return jsonify(result)
    
    except Exception as e:
        current_app.logger.error(f"Error fetching service requests: {str(e)}")
        return str(e), 500
    

    
#last
# Get reviews for a professional
@app.route('/api/professionals/<int:professional_id>/reviews', methods=['GET'])
@auth_required("token")
@roles_required('admin')
def get_professional_reviews(professional_id):
    # Get the professional profile
    # profile = ProfessionalProfile.query.filter_by(user_id=professional_id).first_or_404()
    profile = ProfessionalProfile.query.get(prof_id)    
    # Query reviews for this professional
    reviews = Review.query.filter_by(professional_id=profile.id).all()
    
    # Build detailed reviews response with customer information and service details
    result = []
    for review in reviews:
        # Get customer info
        customer = User.query.get(review.customer_id)
        
        # Get service request info
        service_request = ServiceRequest.query.get(review.service_request_id)
        service_name = "Unknown"
        if service_request and service_request.service_id:
            service = Service.query.get(service_request.service_id)
            if service:
                service_name = service.name
        
        review_data = {
            'id': review.id,
            'rating': review.rating,
            'comments': review.comments,
            'created_at': review.created_at.isoformat(),
            'customer_id': review.customer_id,
            'customer_username': customer.username if customer else "Unknown User",
            'service_request_id': review.service_request_id,
            'service_name': service_name
        }
        result.append(review_data)
    
    return jsonify(result)

# Block a user (admin only)
@app.route('/api/users/<int:userid>/block', methods=['POST'])
@auth_required()
@roles_required('admin')
def block_users(userid):
    print(f"User ID: {userid}, Request by: {current_user.id}")

    # user = User.query.get_or_404(user_id)
    professional = ProfessionalProfile.query.get_or_404(userid)
    user = User.query.get_or_404(professional.user_id)
    
    # Prevent self-blocking
    if user.id == current_user.id:
        return jsonify({'error': 'Cannot block yourself'}), 400
    
    user.is_blocked = True
    db.session.commit()
    
    return jsonify({'message': 'User blocked successfully'})

# Unblock a user (admin only)
@app.route('/api/users/<int:user_id>/unblock', methods=['POST'])
@auth_required()
@roles_required('admin')
def unblock_users(user_id):
    user = User.query.get_or_404(user_id)
    user.is_blocked = False
    db.session.commit()
    
    return jsonify({'message': 'User unblocked successfully'})





@app.route('/static/manifest.json')
def manifest():
    return send_from_directory('static', 'manifest.json')


@app.route('/api/service-requests/monthly')
def get_monthly_service_requests():
    """
    Get the count of service requests by month for the current year
    """
    current_year = datetime.now().year
    
    # Query to get monthly counts
    monthly_counts = db.session.query(
        extract('month', ServiceRequest.date_of_request).label('month'),
        func.count(ServiceRequest.id).label('count')
    ).filter(
        extract('year', ServiceRequest.date_of_request) == current_year
    ).group_by(
        extract('month', ServiceRequest.date_of_request)
    ).order_by(
        'month'
    ).all()
    
    # Convert query results to months
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    
    # Initialize data for all months
    data = [0] * 12
    
    # Fill in the actual counts
    for month, count in monthly_counts:
        # Adjust for 0-based indexing
        data[int(month) - 1] = count
    
    # Return data in Chart.js format
    return jsonify({
        'labels': months,
        'datasets': [{
            'label': 'Service Requests',
            'data': data,
            'backgroundColor': 'rgba(0, 123, 255, 0.2)',
            'borderColor': 'rgba(0, 123, 255, 1)',
            'borderWidth': 1
        }]
    })

@app.route('/api/professionals/ratings')
def get_professional_ratings():
    """
    Get the average ratings for top professionals
    """
    # Query to get professionals with their average ratings
    professional_ratings = db.session.query(
        ProfessionalProfile.name,
        func.avg(Review.rating).label('avg_rating')
    ).join(
        Review, ProfessionalProfile.id == Review.professional_id
    ).group_by(
        ProfessionalProfile.name
    ).order_by(
        func.avg(Review.rating).desc()
    ).limit(10).all()
    
    # Extract names and ratings
    names = [prof[0] for prof in professional_ratings]
    ratings = [float(prof[1]) for prof in professional_ratings]
    
    # Return data in Chart.js format
    return jsonify({
        'labels': names,
        'datasets': [{
            'label': 'Average Rating',
            'data': ratings,
            'backgroundColor': 'rgba(255, 193, 7, 0.2)',
            'borderColor': 'rgba(255, 193, 7, 1)',
            'borderWidth': 1
        }]
    })

@app.route('/api/service-types/distribution')
def get_service_type_distribution():
    """
    Get the distribution of service requests by service type
    """
    # Query to get service type counts
    service_counts = db.session.query(
        Service.name,
        func.count(ServiceRequest.id).label('count')
    ).join(
        ServiceRequest, Service.id == ServiceRequest.service_id
    ).group_by(
        Service.name
    ).all()
    
    # Extract service types and counts
    service_types = [service[0] for service in service_counts]
    counts = [service[1] for service in service_counts]
    
    # Generate colors for each service type
    colors = [
        'rgba(255, 99, 132, 0.6)',
        'rgba(54, 162, 235, 0.6)',
        'rgba(255, 206, 86, 0.6)',
        'rgba(75, 192, 192, 0.6)',
        'rgba(153, 102, 255, 0.6)',
        'rgba(255, 159, 64, 0.6)',
        'rgba(199, 199, 199, 0.6)',
        'rgba(83, 102, 255, 0.6)',
        'rgba(255, 99, 255, 0.6)',
        'rgba(0, 162, 235, 0.6)'
    ]
    
    border_colors = [color.replace('0.6', '1') for color in colors]
    
    # Ensure we have enough colors
    while len(colors) < len(service_types):
        colors.extend(colors)
        border_colors.extend(border_colors)
    
    # Return data in Chart.js format
    return jsonify({
        'labels': service_types,
        'datasets': [{
            'label': 'Service Type Distribution',
            'data': counts,
            'backgroundColor': colors[:len(service_types)],
            'borderColor': border_colors[:len(service_types)],
            'borderWidth': 1
        }]
    })

@app.route('/api/service-requests/completion-time')
def get_completion_time_by_service():
    """
    Get the average completion time for each service type
    """
    # Query to get average completion time by service type
    completion_times = db.session.query(
        Service.name,
        func.avg(
            func.extract('epoch', ServiceRequest.date_of_completion) - 
            func.extract('epoch', ServiceRequest.date_of_request)
        ).label('avg_completion_time')
    ).join(
        ServiceRequest, Service.id == ServiceRequest.service_id
    ).filter(
        ServiceRequest.date_of_completion.isnot(None)
    ).group_by(
        Service.name
    ).all()
    
    # Extract service types and completion times (convert seconds to hours)
    service_types = [service[0] for service in completion_times]
    # Convert seconds to hours and round to 1 decimal place
    times = [round(float(service[1]) / 3600, 1) if service[1] is not None else 0 
             for service in completion_times]
    
    # Return data in Chart.js format
    return jsonify({
        'labels': service_types,
        'datasets': [{
            'label': 'Average Completion Time (hours)',
            'data': times,
            'backgroundColor': 'rgba(75, 192, 192, 0.2)',
            'borderColor': 'rgba(75, 192, 192, 1)',
            'borderWidth': 1
        }]
    })
