# from main import app
# from application.sec import datastore
# from application.models import db, User, Role, Service, ServiceRequest, ProfessionalProfile, Review
# from werkzeug.security import generate_password_hash
# from datetime import datetime, timezone

# with app.app_context():
#     # Create all tables
#     db.create_all()

#     # Create roles if they don't exist
#     roles = [
#         {"name": "admin", "description": "Admin User"},
#         {"name": "professional", "description": "Professional User"},
#         {"name": "customer", "description": "Customer User"}
#     ]

#     for role_data in roles:
#         role = Role.query.filter_by(name=role_data["name"]).first()
#         if not role:
#             role = Role(**role_data)
#             db.session.add(role)

#     db.session.commit()

#     # Create users if they don't exist
#     users = [
#         {
#             "username": "admin",
#             "email": "admin@email.com",
#             "password": generate_password_hash("adminpassword"),
#             "is_blocked": False,
#             "is_admin": True,
#             "fs_uniquifier": "admin123",
#             "role": "admin"
#         },
#         {
#             "username": "prof1",
#             "email": "professional1@email.com",
#             "password": generate_password_hash("professional1"),
#             "is_blocked": False,
#             "is_admin": False,
#             "fs_uniquifier": "prof1uniquifier",
#             "role": "professional"
#         },
#         {
#             "username": "prof2",
#             "email": "professional2@email.com",
#             "password": generate_password_hash("professional2"),
#             "is_blocked": True,
#             "is_admin": False,
#             "fs_uniquifier": "prof2uniquifier",
#             "role": "professional"
#         },
#         {
#             "username": "customer1",
#             "email": "customer1@email.com",
#             "password": generate_password_hash("customer1"),
#             "is_blocked": False,
#             "is_admin": False,
#             "fs_uniquifier": "cust1uniquifier",
#             "role": "customer"
#         },
#         {
#             "username": "customer2",
#             "email": "customer2@email.com",
#             "password": generate_password_hash("customer2"),
#             "is_blocked": False,
#             "is_admin": False,
#             "fs_uniquifier": "cust2uniquifier",
#             "role": "customer"
#         }
#     ]

#     for user_data in users:
#         user = User.query.filter_by(email=user_data["email"]).first()
#         if not user:
#             user = User(
#                 username=user_data["username"],
#                 email=user_data["email"],
#                 password=user_data["password"],
#                 is_blocked=user_data["is_blocked"],
#                 is_admin=user_data["is_admin"],
#                 fs_uniquifier=user_data["fs_uniquifier"]
#             )
#             role = Role.query.filter_by(name=user_data["role"]).first()
#             if role:
#                 user.roles.append(role)
#             db.session.add(user)

#     db.session.commit()

#     # Create some sample services
#     services = [
#         {"name": "Plumbing", "price": 50.0, "time_required": 60, "description": "Fixing leaky pipes"},
#         {"name": "Electrical", "price": 75.0, "time_required": 90, "description": "Fixing electrical faults"}
#     ]

#     for service_data in services:
#         service = Service.query.filter_by(name=service_data["name"]).first()
#         if not service:
#             service = Service(**service_data)
#             db.session.add(service)

#     db.session.commit()

#     # Create professional profiles
#     professional_profiles = [
#         {
#             "user_email": "professional1@email.com",
#             "name": "John Doe",
#             "date_created": datetime.now(timezone.utc),
#             "description": "Experienced plumber",
#             "service_type": "Plumbing",
#             "experience": 5,
#             "active": True
#         }
#     ]

#     for profile_data in professional_profiles:
#         user = User.query.filter_by(email=profile_data["user_email"]).first()
#         if user and not ProfessionalProfile.query.filter_by(user_id=user.id).first():
#             profile = ProfessionalProfile(
#                 user_id=user.id,
#                 name=profile_data["name"],
#                 date_created=profile_data["date_created"],
#                 description=profile_data["description"],
#                 service_type=profile_data["service_type"],
#                 experience=profile_data["experience"],
#                 active=profile_data["active"]
#             )
#             db.session.add(profile)

#     db.session.commit()

#     # Create some service requests
#     service_requests = [
#         {
#             "service_name": "Plumbing",
#             "customer_email": "customer1@email.com",
#             "date_of_request": datetime.now(timezone.utc),
#             "service_status": "requested",
#             "remarks": "Leaking sink"
#         },
#         {
#             "service_name": "Electrical",
#             "customer_email": "customer2@email.com",
#             "date_of_request": datetime.now(timezone.utc),
#             "service_status": "requested",
#             "remarks": "Flickering light"
#         }
#     ]

#     for request_data in service_requests:
#         service = Service.query.filter_by(name=request_data["service_name"]).first()
#         customer = User.query.filter_by(email=request_data["customer_email"]).first()
#         if service and customer and not ServiceRequest.query.filter_by(customer_id=customer.id).first():
#             service_request = ServiceRequest(
#                 service_id=service.id,
#                 customer_id=customer.id,
#                 date_of_request=request_data["date_of_request"],
#                 service_status=request_data["service_status"],
#                 remarks=request_data["remarks"]
#             )
#             db.session.add(service_request)

#     db.session.commit()

#     # Create reviews for professionals
#     reviews = [
#         {
#             "professional_email": "professional1@email.com",
#             "customer_email": "customer1@email.com",
#             "rating": 4.5,
#             "comments": "Great job! Fixed the plumbing issue quickly.",
#             "created_at": datetime.now(timezone.utc)
#         }
#     ]

#     for review_data in reviews:
#         professional = User.query.filter_by(email=review_data["professional_email"]).first()
#         customer = User.query.filter_by(email=review_data["customer_email"]).first()
#         if professional and customer:
#             profile = ProfessionalProfile.query.filter_by(user_id=professional.id).first()
#             if profile and not Review.query.filter_by(customer_id=customer.id, professional_id=profile.id).first():
#                 review = Review(
#                     professional_id=profile.id,
#                     customer_id=customer.id,
#                     rating=review_data["rating"],
#                     comments=review_data["comments"],
#                     created_at=review_data["created_at"]
#                 )
#                 db.session.add(review)

#     db.session.commit()

from main import app
from application.models import db, User, Role, Service, ServiceRequest, ProfessionalProfile, Review
from werkzeug.security import generate_password_hash
from datetime import datetime, timezone
from passlib.hash import pbkdf2_sha256

with app.app_context():
    # Create all tables
    db.create_all()

    try:
        # Create roles if they don't exist
        roles = [
            {"name": "admin", "description": "Admin User"},
            {"name": "professional", "description": "Professional User"},
            {"name": "customer", "description": "Customer User"}
        ]

        for role_data in roles:
            role = Role.query.filter_by(name=role_data["name"]).first()
            if not role:
                role = Role(**role_data)
                db.session.add(role)

        # Commit roles
        db.session.commit()

        # Create users if they don't exist
        users = [
            {
                "username": "admin",
                "email": "admin@email.com",
                "password": generate_password_hash("adminpassword"),
                "is_blocked": False,
                "is_admin": True,
                "active": True,
                "fs_uniquifier": "admin123",
                "role": "admin"
            },
            {
                "username": "prof1",
                "email": "professional1@email.com",
                "password": generate_password_hash("professional1"),
                "is_blocked": True,
                "is_admin": False,
                "active": True,
                "fs_uniquifier": "prof1uniquifier",
                "role": "professional"
            },
            {
                "username": "prof2",
                "email": "professional2@email.com",
                "password": generate_password_hash("professional2"),
                "is_blocked": True,
                "is_admin": False,
                "active": False,
                "fs_uniquifier": "prof2uniquifier",
                "role": "professional"
            },
            {
                "username": "customer1",
                "email": "customer1@email.com",
                "password": generate_password_hash("customer1"),
                "is_blocked": True,
                "is_admin": False,
                "active": True,
                "fs_uniquifier": "cust1uniquifier",
                "role": "customer"
            },
            {
                "username": "customer2",
                "email": "customer2@email.com",
                "password": generate_password_hash("customer2"),
                "is_blocked": False,
                "is_admin": False,
                "active": True,
                "fs_uniquifier": "cust2uniquifier",
                "role": "customer"
            }
        ]

        for user_data in users:
            user = User.query.filter_by(email=user_data["email"]).first()
            if not user:
                user = User(
                    username=user_data["username"],
                    email=user_data["email"],
                    password=user_data["password"],
                    is_blocked=user_data["is_blocked"],
                    is_admin=user_data["is_admin"],
                    active=user_data["active"],
                    fs_uniquifier=user_data["fs_uniquifier"]
                )
                role = Role.query.filter_by(name=user_data["role"]).first()
                if role:
                    user.roles.append(role)
                db.session.add(user)

        # Commit users
        db.session.commit()

        # Create services if they don't exist
        services = [
            {"name": "Plumbing", "price": 50.0, "time_required": 60, "description": "Fixing leaky pipes"},
            {"name": "Electrical", "price": 75.0, "time_required": 90, "description": "Fixing electrical faults"}
        ]

        for service_data in services:
            service = Service.query.filter_by(name=service_data["name"]).first()
            if not service:
                service = Service(**service_data)
                db.session.add(service)

        # Commit services
        db.session.commit()

        # Create professional profiles
        professional_profiles = [
                {
                    "user_email": "professional1@email.com",
                    "name": "John Doe",
                    "city": "New York",
                    "state": "NY",
                    "pin_code": "10001",
                    "date_created": datetime.now(timezone.utc),
                    "description": "Experienced plumber",
                    "service_type": "Plumbing",
                    "experience": 5,                    
                    "is_verified": False
                },
                {
                    "user_email": "professional2@email.com",
                    "name": "Jane Smith",
                    "city": "Los Angeles",
                    "state": "CA",
                    "pin_code": "90001",
                    "date_created": datetime.now(timezone.utc),
                    "description": "Certified electrician",
                    "service_type": "Electrical",
                    "experience": 8,
                    "is_verified": False
                }
            ]

        for profile_data in professional_profiles:
            user = User.query.filter_by(email=profile_data["user_email"]).first()
            if user and not ProfessionalProfile.query.filter_by(user_id=user.id).first():
                profile = ProfessionalProfile(
                    user_id=user.id,
                    name=profile_data["name"],
                    city=profile_data["city"],
                    state=profile_data["state"],
                    pin_code=profile_data["pin_code"],
                    date_created=profile_data["date_created"],
                    description=profile_data["description"],
                    service_type=profile_data["service_type"],
                    experience=profile_data["experience"],
                    is_verified=profile_data["is_verified"]
                )
                db.session.add(profile)

        # Commit professional profiles
        db.session.commit()

        # Create service requests
        # service_requests = [
        #     {
        #         "service_name": "Plumbing",
        #         "customer_email": "customer1@email.com",
        #         "date_of_request": datetime.now(timezone.utc),
        #         "service_status": "requested",
        #         "remarks": "Leaking sink"
        #     },
        #     {
        #         "service_name": "Electrical",
        #         "customer_email": "customer2@email.com",
        #         "date_of_request": datetime.now(timezone.utc),
        #         "service_status": "requested",
        #         "remarks": "Flickering light"
        #     }
        # ]

        # for request_data in service_requests:
        #     service = Service.query.filter_by(name=request_data["service_name"]).first()
        #     customer = User.query.filter_by(email=request_data["customer_email"]).first()
        #     if service and customer and not ServiceRequest.query.filter_by(customer_id=customer.id).first():
        #         service_request = ServiceRequest(
        #             service_id=service.id,
        #             customer_id=customer.id,
        #             date_of_request=request_data["date_of_request"],
        #             service_status=request_data["service_status"],
        #             remarks=request_data["remarks"]
        #         )
        #         db.session.add(service_request)

        service_requests = [
            {
                "service_name": "Plumbing",
                "customer_email": "customer1@email.com",
                "date_of_request": datetime.now(timezone.utc),
                "service_status": "requested",
                "remarks": "Leaking sink",
                "professional_email": "professional1@email.com"  # Set a professional if assigned
            },
            {
                "service_name": "Electrical",
                "customer_email": "customer2@email.com",
                "date_of_request": datetime.now(timezone.utc),
                "service_status": "requested",
                "remarks": "Flickering light",
                "professional_email": "professional1@email.com"  # Example of an assigned professional
            }
        ]

        for request_data in service_requests:
            service = Service.query.filter_by(name=request_data["service_name"]).first()
            customer = User.query.filter_by(email=request_data["customer_email"]).first()
            professional = (
                User.query.filter_by(email=request_data["professional_email"]).first()
                if request_data["professional_email"]
                else None
            )

            if service and customer and not ServiceRequest.query.filter_by(
                customer_id=customer.id, service_id=service.id, service_status="requested"
            ).first():
                service_request = ServiceRequest(
                    service_id=service.id,
                    customer_id=customer.id,
                    professional_id=professional.id if professional else None,
                    date_of_request=request_data["date_of_request"],
                    service_status=request_data["service_status"],
                    remarks=request_data["remarks"]
                )
                db.session.add(service_request)


        # Commit service requests
        db.session.commit()

        # Create reviews
        # reviews = [
        #     {
        #         "professional_email": "professional1@email.com",
        #         "customer_email": "customer1@email.com",
        #         "rating": 4.5,
        #         "comments": "Great job! Fixed the plumbing issue quickly.",
        #         "created_at": datetime.now(timezone.utc)
        #     }
        # ]

        # for review_data in reviews:
        #     professional = User.query.filter_by(email=review_data["professional_email"]).first()
        #     customer = User.query.filter_by(email=review_data["customer_email"]).first()
        #     if professional and customer:
        #         profile = ProfessionalProfile.query.filter_by(user_id=professional.id).first()
        #         if profile and not Review.query.filter_by(customer_id=customer.id, professional_id=profile.id).first():
        #             review = Review(
        #                 professional_id=profile.id,
        #                 customer_id=customer.id,
        #                 rating=review_data["rating"],
        #                 comments=review_data["comments"],
        #                 created_at=review_data["created_at"]
        #             )
        #             db.session.add(review)

        reviews = [
            {
                "professional_email": "professional1@email.com",
                "customer_email": "customer1@email.com",
                "rating": 4.5,
                "comments": "Great job! Fixed the plumbing issue quickly.",
                "service_request_id": 1,  # Ensure this ID is valid in your database
                "created_at": datetime.now(timezone.utc)
            }
        ]

        for review_data in reviews:
            professional = User.query.filter_by(email=review_data["professional_email"]).first()
            customer = User.query.filter_by(email=review_data["customer_email"]).first()
            if professional and customer:
                profile = ProfessionalProfile.query.filter_by(user_id=professional.id).first()
                service_request = db.session.get(ServiceRequest, review_data["service_request_id"])
  # Fetch service request

                if profile and service_request and not Review.query.filter_by(
                    customer_id=customer.id, professional_id=profile.id, service_request_id=service_request.id
                ).first():
                    review = Review(
                        professional_id=profile.id,
                        customer_id=customer.id,
                        rating=review_data["rating"],
                        comments=review_data["comments"],
                        service_request_id=service_request.id,
                        created_at=review_data["created_at"]
                    )
                    db.session.add(review)


        # Commit reviews
        db.session.commit()

    except Exception as e:
        db.session.rollback()
        print(f"Error: {e}")


