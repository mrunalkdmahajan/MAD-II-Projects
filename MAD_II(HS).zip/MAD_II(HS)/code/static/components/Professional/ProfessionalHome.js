export default {
    template: `
    <div>
      This is P Home
    </div>
  `
}