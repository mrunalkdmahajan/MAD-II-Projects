export default {
    name: "ServiceRequests",
    template: `
    <div class="container mt-5">
      <div class="d-flex justify-content-between align-items-center">
        <h2>Service Requests</h2>
      </div>
      <div v-if="loading" class="text-center mt-3">
        <div class="spinner-border" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>
      </div>
      <div v-else-if="error" class="alert alert-danger mt-3">
        {{ error }}
      </div>
      <div v-else>
        <div class="mb-3">
          <select v-model="statusFilter" class="form-select w-auto">
            <option value="">All Requests</option>
            <option value="requested">New Requests</option>
            <option value="assigned">Assigned to Me</option>
            <option value="closed">Completed</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
        <div v-if="isProfessional" class="alert alert-info mb-3">
          <i class="bi bi-info-circle me-2"></i>
          You are viewing service requests that match your service type: <strong>{{ serviceType }}</strong>
        </div>
        <table class="table table-bordered mt-3">
          <thead>
            <tr>
              <th>ID</th>
              <th>Service</th>
              <th>Customer</th>
              <th>Date Requested</th>
              <th>Status</th>
              <th>Remarks</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in filteredRequests" :key="request.id">
              <td>{{ request.id }}</td>
              <td>{{ request.service?.name || 'Unknown' }}</td>
              <td>{{ request.customer?.username || 'Unknown' }}</td>
              <td>{{ formatDate(request.date_of_request) }}</td>
              <td>
                <span 
                  :class="getStatusClass(request.service_status)"
                >
                  {{ request.service_status }}
                </span>
              </td>
              <td>{{ request.remarks || '-' }}</td>
              <td>
                <div v-if="request.service_status === 'requested'" class="d-flex gap-2">
                  <button 
                    class="btn btn-success btn-sm" 
                    @click="acceptRequest(request.id)"
                    :disabled="actionLoading"
                  >
                    Accept
                  </button>
                  <button 
                    class="btn btn-danger btn-sm" 
                    @click="rejectRequest(request.id)"
                    :disabled="actionLoading"
                  >
                    Reject
                  </button>
                </div>
                <div v-else-if="request.service_status === 'assigned' && request.professional_id === currentUserId">
                  <button 
                    class="btn btn-primary btn-sm" 
                    @click="completeRequest(request.id)"
                    :disabled="actionLoading"
                  >
                    Mark Complete
                  </button>
                </div>
                <div v-else>
                  -
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <div v-if="filteredRequests.length === 0" class="alert alert-info">
          No service requests found.
        </div>
      </div>
    </div>
  `,
    data() {
        return {
            requests: [],
            loading: true,
            actionLoading: false,
            error: null,
            currentUserId: null,
            statusFilter: "",
            isProfessional: false,
            serviceType: ""
        };
    },
    computed: {
        filteredRequests() {
            if (!this.statusFilter) {
                return this.requests;
            }
            return this.requests.filter(req => req.service_status === this.statusFilter);
        }
    },
    methods: {
        formatDate(dateString) {
            if (!dateString) return '-';
            const date = new Date(dateString);
            return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
        },
        getStatusClass(status) {
            switch (status) {
                case 'requested':
                    return 'badge bg-warning text-dark';
                case 'assigned':
                    return 'badge bg-primary';
                case 'closed':
                    return 'badge bg-success';
                case 'rejected':
                    return 'badge bg-danger';
                default:
                    return 'badge bg-secondary';
            }
        },
        async acceptRequest(requestId) {
            await this.updateRequestStatus(requestId, 'assigned');
        },
        async rejectRequest(requestId) {
            await this.updateRequestStatus(requestId, 'rejected', 'Request rejected by professional');
        },
        async completeRequest(requestId) {
            await this.updateRequestStatus(requestId, 'closed', 'Service completed');
        },
        async updateRequestStatus(requestId, status, remarks = '') {
            this.actionLoading = true;
            try {
                const token = localStorage.getItem("auth-token");

                if (!token) {
                    this.error = "Authentication required";
                    return;
                }

                const response = await fetch(`/api/service-requests/${requestId}/status`, {
                    method: "PUT",
                    headers: {
                        "Authentication-Token": token,
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        status: status,
                        remarks: remarks
                    })
                });

                if (!response.ok) {
                    const text = await response.text();
                    throw new Error(text || `Failed to update request status`);
                }

                // Refresh the list after action
                await this.fetchRequests();

            } catch (error) {
                console.error(`Error updating request status:`, error);
                this.error = error.message;
            } finally {
                this.actionLoading = false;
            }
        },
        async fetchRequests() {
            this.loading = true;
            this.error = null;

            try {
                const token = localStorage.getItem("auth-token");

                if (!token) {
                    this.error = "Authentication required";
                    this.loading = false;
                    return;
                }

                // Fetch current user info
                const userResponse = await fetch("/api/user", {
                    method: "GET",
                    headers: {
                        "Authentication-Token": token
                    }
                });

                if (!userResponse.ok) {
                    throw new Error("Failed to get user information");
                }

                const userData = await userResponse.json();
                this.currentUserId = userData.id;

                // Check if the user is a professional
                if (userData.profile) {
                    this.isProfessional = true;
                    this.serviceType = userData.profile.service_type;
                }

                // Fetch service requests
                const response = await fetch("/api/service-requests", {
                    method: "GET",
                    headers: {
                        "Authentication-Token": token
                    }
                });

                if (!response.ok) {
                    const text = await response.text();
                    throw new Error(text || "Failed to fetch service requests");
                }

                this.requests = await response.json();
            } catch (error) {
                console.error("Error fetching service requests:", error);
                this.error = error.message;
            } finally {
                this.loading = false;
            }
        }
    },
    async created() {
        await this.fetchRequests();
    }
};