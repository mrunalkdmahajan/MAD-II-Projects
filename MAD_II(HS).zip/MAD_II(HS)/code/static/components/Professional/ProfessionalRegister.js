// export default {
//     template: `
//       <div>
//         <div class="heading">
//           <h1 class="display-1">Register as Professional</h1>
//           <div class="d-flex flex-column align-items-start m-3">
//             <router-link to="/login" class="btn btn-light-yellow">
//               <i class="fas fa-sign-in-alt"></i> Login
//             </router-link>
//             <router-link to="/register-customer" class="btn btn-light-yellow">
//               <i class="fas fa-user"></i> Customer Register
//             </router-link>
//           </div>
//         </div>

//         <form @submit.prevent="registerProfessional" class="form">
//           <!-- User Information -->
//           <div class="form-section">
//             <h3>Account Information</h3>
//             <div class="form-group">
//               <label for="username" class="form-label">Username</label>
//               <input v-model="form.username" type="text" name="username" required class="form-control" />
//             </div>
//             <div class="form-group">
//               <label for="email" class="form-label">Email</label>
//               <input v-model="form.email" type="email" name="email" required class="form-control" />
//             </div>
//             <div class="form-group">
//               <label for="password" class="form-label">Password</label>
//               <input v-model="form.password" type="password" name="password" required class="form-control" />
//             </div>
//             <div class="form-group">
//               <label for="confirm_password" class="form-label">Confirm Password</label>
//               <input v-model="form.confirmPassword" type="password" name="confirm_password" required class="form-control" />
//             </div>
//           </div>

//           <!-- Professional Profile Information -->
//           <div class="form-section mt-4">
//             <h3>Professional Information</h3>
//             <div class="form-group">
//               <label for="name" class="form-label">Professional Name</label>
//               <input v-model="form.profile.name" type="text" name="name" required class="form-control" />
//             </div>
//             <div class="form-group">
//               <label for="service_type" class="form-label">Service Type</label>
//               <select v-model="form.profile.service_type" class="form-select" required>
//                 <option value="" disabled>Select Service Type</option>
//                 <option value="Personal Training">Personal Training</option>
//                 <option value="Life Coaching">Life Coaching</option>
//                 <option value="Financial Advisory">Financial Advisory</option>
//                 <option value="Legal Consultation">Legal Consultation</option>
//                 <option value="Mental Health Counseling">Mental Health Counseling</option>
//                 <option value="Career Coaching">Career Coaching</option>
//                 <option value="Nutrition Consulting">Nutrition Consulting</option>
//                 <option value="Business Consulting">Business Consulting</option>
//                 <option value="Other">Other</option>
//               </select>
//             </div>
//             <div class="form-group">
//               <label for="experience" class="form-label">Years of Experience</label>
//               <input v-model="form.profile.experience" type="number" name="experience" required class="form-control" />
//             </div>
//             <div class="form-group">
//               <label for="description" class="form-label">Professional Description</label>
//               <textarea v-model="form.profile.description" name="description" class="form-control" rows="4"></textarea>
//             </div>
//           </div>

//           <div class="form-group mt-4">
//             <input type="submit" value="Register" class="btn btn-primary" />
//           </div>
//         </form>
//       </div>
//     `,

//     data() {
//         return {
//             form: {
//                 username: '',
//                 email: '',
//                 password: '',
//                 confirmPassword: '',
//                 profile: {
//                     name: '',
//                     service_type: '',
//                     experience: '',
//                     description: '',
//                     date_created: new Date().toISOString()
//                 }
//             },
//         };
//     },

//     methods: {
//         async registerProfessional() {
//             if (this.form.password !== this.form.confirmPassword) {
//                 alert("Passwords don't match!");
//                 return;
//             }

//             try {
//                 const response = await fetch('/api/register-professional', {
//                     method: 'POST',
//                     headers: { 'Content-Type': 'application/json' },
//                     body: JSON.stringify(this.form),
//                 });
//                 const result = await response.json();
//                 if (response.ok) {
//                     alert(result.message);
//                     this.$router.push('/login');
//                 } else {
//                     alert(result.error);
//                 }
//             } catch (error) {
//                 alert('An error occurred during registration.');
//             }
//         },
//     },
// };


export default {
    template: `
    <div>
      <div class="heading">
        <h1 class="display-1">Register as Professional</h1>
        <div class="d-flex flex-column align-items-start m-3">
          <router-link to="/login" class="btn btn-light-yellow">
            <i class="fas fa-sign-in-alt"></i> Login
          </router-link>
          <router-link to="/register-customer" class="btn btn-light-yellow">
            <i class="fas fa-user"></i> Customer Register
          </router-link>
        </div>
      </div>

      <form @submit.prevent="registerProfessional" class="form">
        <div class="form-section">
          <h3>Account Information</h3>
          <div class="form-group">
            <label for="username" class="form-label">Username</label>
            <input v-model="form.username" type="text" name="username" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="email" class="form-label">Email</label>
            <input v-model="form.email" type="email" name="email" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="password" class="form-label">Password</label>
            <input v-model="form.password" type="password" name="password" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="confirm_password" class="form-label">Confirm Password</label>
            <input v-model="form.confirmPassword" type="password" name="confirm_password" required class="form-control" />
          </div>
        </div>

        <div class="form-section mt-4">
          <h3>Professional Information</h3>
          <div class="form-group">
            <label for="name" class="form-label">Professional Name</label>
            <input v-model="form.profile.name" type="text" name="name" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="service_type" class="form-label">Service Type</label>
            <select v-model="form.profile.service_type" class="form-select" required>
              <option value="" disabled>Select Service Type</option>
              <option value="Personal Training">Personal Training</option>
              <option value="Life Coaching">Life Coaching</option>
              <option value="Financial Advisory">Financial Advisory</option>
              <option value="Legal Consultation">Legal Consultation</option>
              <option value="Mental Health Counseling">Mental Health Counseling</option>
              <option value="Career Coaching">Career Coaching</option>
              <option value="Nutrition Consulting">Nutrition Consulting</option>
              <option value="Business Consulting">Business Consulting</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div class="form-group">
            <label for="experience" class="form-label">Years of Experience</label>
            <input v-model="form.profile.experience" type="number" name="experience" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="description" class="form-label">Professional Description</label>
            <textarea v-model="form.profile.description" name="description" class="form-control" rows="4"></textarea>
          </div>
          <div class="form-group">
            <label for="city" class="form-label">City</label>
            <input v-model="form.profile.city" type="text" name="city" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="state" class="form-label">State</label>
            <input v-model="form.profile.state" type="text" name="state" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="pin_code" class="form-label">Pin Code</label>
            <input v-model="form.profile.pin_code" type="text" name="pin_code" required class="form-control" />
          </div>
        </div>

        <div class="form-group mt-4">
          <input type="submit" value="Register" class="btn btn-primary" />
        </div>
      </form>
    </div>
  `,

    data() {
        return {
            form: {
                username: '',
                email: '',
                password: '',
                confirmPassword: '',
                profile: {
                    name: '',
                    service_type: '',
                    experience: '',
                    description: '',
                    city: '',
                    state: '',
                    pin_code: '',
                    date_created: new Date().toISOString()
                }
            },
        };
    },

    methods: {
        async registerProfessional() {
            if (this.form.password !== this.form.confirmPassword) {
                alert("Passwords don't match!");
                return;
            }

            try {
                const response = await fetch('/api/register-professional', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.form),
                });
                const result = await response.json();
                if (response.ok) {
                    alert(result.message);
                    this.$router.push('/login');
                } else {
                    alert(result.error);
                }
            } catch (error) {
                alert('An error occurred during registration.');
            }
        },
    },
};