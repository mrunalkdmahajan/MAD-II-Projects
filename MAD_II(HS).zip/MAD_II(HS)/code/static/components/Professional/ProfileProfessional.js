export default {
    data() {
        return {
            professional: {
                id: null,
                username: '',
                email: '',
                active: false,
                is_blocked: false,
                name: '',
                city: '',
                state: '',
                pin_code: '',
                description: '',
                service_type: '',
                experience: 0,
                is_verified: false
            },
            loading: true,
            error: null
        };
    },
    async created() {
        try {
            const token = localStorage.getItem("auth-token");
            console.log("Token:", token); // Debug token

            if (!token) {
                this.error = "Authentication required";
                this.loading = false;
                return;
            }

            const response = await fetch('/api/professional/profile', {
                method: 'GET',
                headers: {
                    "Authentication-Token": token
                }
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Full error response:', errorText);
                throw new Error(`HTTP error! Status: ${response.status}, ${errorText}`);
            }

            this.professional = await response.json();
            this.loading = false;
        } catch (error) {
            console.error('Detailed error:', error);
            this.error = error.message;
            this.loading = false;
        }
    },
    methods: {
        navigateToEditProfile() {
            this.$router.push('/professional/edit/profile');
        }
    },
    template: `
<div class="container mt-4">
<h3 class="text-center mb-3">Professional Profile</h3>
<div v-if="loading" class="text-center">
  <div class="spinner-border" role="status">
    <span class="visually-hidden">Loading...</span>
  </div>
</div>
<div v-else-if="error" class="alert alert-danger" role="alert">
  {{ error }}
</div>
<div v-else class="card mx-auto" style="max-width: 500px;">
  <div class="card-body">
    <h5 class="card-title text-center">{{ professional.name }}</h5>
    <p class="card-text"><strong>ID:</strong> {{ professional.id }}</p>
    <p class="card-text"><strong>Email:</strong> {{ professional.email }}</p>
    <p class="card-text"><strong>City:</strong> {{ professional.city }}</p>
    <p class="card-text"><strong>State:</strong> {{ professional.state }}</p>
    <p class="card-text"><strong>Pin Code:</strong> {{ professional.pin_code }}</p>
    <p class="card-text"><strong>Service Type:</strong> {{ professional.service_type }}</p>
    <p class="card-text"><strong>Experience:</strong> {{ professional.experience }} years</p>
    <p class="card-text"><strong>Description:</strong> {{ professional.description }}</p>
    <p class="card-text">
      <strong>Verified:</strong> 
      <span :class="{'text-success': professional.is_verified, 'text-danger': !professional.is_verified}">
        {{ professional.is_verified ? 'Yes' : 'No' }}
      </span>
    </p>
    <p class="card-text">
      <strong>Active:</strong> 
      <span :class="{'text-success': professional.active, 'text-danger': !professional.active}">
        {{ professional.active ? 'Yes' : 'No' }}
      </span>
    </p>
    <p class="card-text">
      <strong>Blocked:</strong> 
      <span :class="{'text-success': !professional.is_blocked, 'text-danger': professional.is_blocked}">
        {{ professional.is_blocked ? 'Yes' : 'No' }}
      </span>
    </p>
    <button 
      @click="navigateToEditProfile" 
      class="btn btn-primary w-100 mt-3"
    >
      Edit Profile
    </button>
  </div>
</div>
</div>
`
};