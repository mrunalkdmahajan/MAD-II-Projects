export default {
    data() {
        return {
            professional: {
                name: '',
                city: '',
                state: '',
                pin_code: '',
                description: '',
                service_type: '',
                experience: 0,
                is_verified: false
            },
            loading: true,
            error: null
        };
    },
    async created() {
        try {
            const token = localStorage.getItem("auth-token");
            if (!token) {
                this.error = "Authentication required";
                this.loading = false;
                return;
            }
            const response = await fetch('/api/professional/profile', {
                method: 'GET',
                headers: { "Authentication-Token": token }
            });
            if (!response.ok) throw new Error(await response.text());

            this.professional = await response.json();
            this.loading = false;
        } catch (error) {
            this.error = error.message;
            this.loading = false;
        }
    },
    methods: {
        async updateProfile() {
            try {
                const token = localStorage.getItem("auth-token");
                if (!token) {
                    this.error = "Authentication required";
                    return;
                }

                const response = await fetch('/api/professional/profile/update', {
                    method: 'PUT',
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token
                    },
                    body: JSON.stringify(this.professional)
                });

                if (!response.ok) throw new Error(await response.text());

                alert("Profile updated successfully!");
                this.$router.push('/professional/profile');
            } catch (error) {
                this.error = error.message;
            }
        }
    },
    template: `
      <div class="container mt-4">
        <h3 class="text-center mb-3">Edit Professional Profile</h3>
        <div v-if="loading" class="text-center">
          <div class="spinner-border" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>
        <div v-else-if="error" class="alert alert-danger" role="alert">
          {{ error }}
        </div>
        <form v-else @submit.prevent="updateProfile" class="card mx-auto p-4" style="max-width: 500px;">
          <div class="mb-3">
            <label class="form-label">Name</label>
            <input v-model="professional.name" type="text" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">City</label>
            <input v-model="professional.city" type="text" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">State</label>
            <input v-model="professional.state" type="text" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Pin Code</label>
            <input v-model="professional.pin_code" type="text" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Service Type</label>
            <input v-model="professional.service_type" type="text" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Experience (years)</label>
            <input v-model.number="professional.experience" type="number" class="form-control" min="0" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea v-model="professional.description" class="form-control" rows="3"></textarea>
          </div>
          <div class="mb-3 form-check">
            <input v-model="professional.is_verified" type="checkbox" class="form-check-input" />
            <label class="form-check-label">Verified</label>
          </div>
          <button type="submit" class="btn btn-success w-100">Save Changes</button>
        </form>
      </div>
    `
};