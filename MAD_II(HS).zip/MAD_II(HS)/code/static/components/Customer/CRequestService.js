export default {
    name: "SearchServices",
    data() {
        return {
            services: [],
            hasSearched: false,
            filters: {
                professionalName: "",
                serviceType: "",
                location: {
                    city: "",
                    state: "",
                    pinCode: "",
                },
            },
            error: null,
        };
    },
    methods: {
        async searchServices() {
            try {
                const token = localStorage.getItem("auth-token");
                console.log("Auth token:", token);

                if (!token) {
                    this.error = "Authentication required.";
                    this.hasSearched = true;
                    return;
                }

                const queryParams = new URLSearchParams();
                if (this.filters.professionalName) {
                    queryParams.append("professional_name", this.filters.professionalName);
                }
                if (this.filters.serviceType) {
                    queryParams.append("service_type", this.filters.serviceType);
                }
                if (this.filters.location.city) {
                    queryParams.append("city", this.filters.location.city);
                }
                if (this.filters.location.state) {
                    queryParams.append("state", this.filters.location.state);
                }
                if (this.filters.location.pinCode) {
                    queryParams.append("pin_code", this.filters.location.pinCode);
                }

                const response = await fetch(`/api/services/search?${queryParams.toString()}`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token,
                    },
                });

                const text = await response.text();
                console.log("Response:", text);

                if (!response.ok) {
                    throw new Error(text);
                }

                const data = JSON.parse(text);
                this.services = data.services || [];
                this.hasSearched = true;
            } catch (error) {
                console.error("Error fetching services:", error);
                this.error = "Unable to load services. Please try again later.";
            }
        },
    },
    template: `
        <div class="container mt-4">
            <div class="card mb-4">
                <div class="card-body bg-light">
                    <h3 class="mb-3">Find Services</h3>
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Search by professional name"
                                v-model="filters.professionalName"
                            />
                        </div>
                        <div class="col-md-6 mb-2">
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Service type (e.g. Plumbing, Electrical)"
                                v-model="filters.serviceType"
                            />
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-4 mb-2">
                            <input
                                type="text"
                                class="form-control"
                                placeholder="City"
                                v-model="filters.location.city"
                            />
                        </div>
                        <div class="col-md-4 mb-2">
                            <input
                                type="text"
                                class="form-control"
                                placeholder="State"
                                v-model="filters.location.state"
                            />
                        </div>
                        <div class="col-md-4 mb-2">
                            <input
                                type="text"
                                class="form-control"
                                placeholder="PIN Code"
                                v-model="filters.location.pinCode"
                            />
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col">
                            <button @click="searchServices" class="btn btn-primary">
                                Search Services
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div v-if="error" class="alert alert-danger">
                {{ error }}
            </div>

            <div v-if="hasSearched">
                <h3 class="display-6 mb-3">Available Services</h3>
                <div v-if="services.length === 0" class="alert alert-info">
                    No services found matching your search criteria.
                </div>
                <div v-else class="row">
                    <div v-for="service in services" 
                         :key="service.id" 
                         class="col-md-4 mb-3">
                        <div class="card h-100 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">{{ service.name || service.service_type }}</h5>
                                <div class="card-text">
                                    <p class="mb-1">
                                        <strong>Provider:</strong> {{ service.professional.name }}
                                    </p>
                                    <p class="mb-1">
                                        <strong>Location:</strong> {{ service.professional.city }}, {{ service.professional.state }}
                                    </p>
                                    <p class="mb-1">
                                        <strong>PIN Code:</strong> {{ service.professional.pin_code }}
                                    </p>
                                    <p class="mb-1">
                                        <strong>Description:</strong> {{ service.description }}
                                    </p>
                                    <p v-if="service.price" class="mb-1">
                                        <strong>Price:</strong> $, {{ service.price.toFixed(2) }}
                                    </p>
                                    <p v-if="service.time_required" class="mb-1">
                                        <strong>Estimated Time:</strong> {{ service.time_required }} mins
                                    </p>
                                    <p class="mb-1">
                                        <strong>Experience:</strong> {{ service.professional.experience }} years
                                    </p>
                                </div>
                                <div class="mt-3 d-flex gap-2">
                                    
                                    <router-link 
                                        class="btn btn-outline-primary" 
                                        :to="{ 
                                            path: '/request-service', 
                                            query: { 
                                                serviceId: service.id,
                                                professionalId: service.professional.user_id 
                                            }
                                        }"
                                    >
                                        Request Service
                                    </router-link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `,
};
// export default {
//     name: "SearchServices",
//     data() {
//         return {
//             services: [],
//             hasSearched: false,
//             filters: {
//                 professionalName: "",
//                 serviceType: "",
//                 location: {
//                     city: "",
//                     state: "",
//                     pinCode: "",
//                 },
//             },
//             error: null,
//         };
//     },
//     methods: {
//         async searchServices() {
//             try {
//                 const token = localStorage.getItem("auth-token");
//                 console.log("Auth token:", token);

//                 if (!token) {
//                     this.error = "Authentication required.";
//                     this.hasSearched = true;
//                     return;
//                 }

//                 const queryParams = new URLSearchParams();
//                 if (this.filters.professionalName) {
//                     queryParams.append("professional_name", this.filters.professionalName);
//                 }
//                 if (this.filters.serviceType) {
//                     queryParams.append("service_type", this.filters.serviceType);
//                 }
//                 if (this.filters.location.city) {
//                     queryParams.append("city", this.filters.location.city);
//                 }
//                 if (this.filters.location.state) {
//                     queryParams.append("state", this.filters.location.state);
//                 }
//                 if (this.filters.location.pinCode) {
//                     queryParams.append("pin_code", this.filters.location.pinCode);
//                 }

//                 const response = await fetch(`/api/services/search?${queryParams.toString()}`, {
//                     method: "GET",
//                     headers: {
//                         "Content-Type": "application/json",
//                         "Authentication-Token": token, // Added authentication token
//                     },
//                 });

//                 const text = await response.text();
//                 console.log("Response:", text);

//                 if (!response.ok) {
//                     throw new Error(text);
//                 }

//                 const data = JSON.parse(text);
//                 this.services = data.services || [];
//                 this.hasSearched = true;
//             } catch (error) {
//                 console.error("Error fetching services:", error);
//                 this.error = "Unable to load services. Please try again later.";
//             }
//         },
//     },
//     template: `
//         <div class="container mt-4">
//             <div class="card mb-4">
//                 <div class="card-body bg-light">
//                     <h3 class="mb-3">Find Services</h3>
//                     <div class="row">
//                         <div class="col-md-6 mb-2">
//                             <input
//                                 type="text"
//                                 class="form-control"
//                                 placeholder="Search by professional name"
//                                 v-model="filters.professionalName"
//                             />
//                         </div>
//                         <div class="col-md-6 mb-2">
//                             <input
//                                 type="text"
//                                 class="form-control"
//                                 placeholder="Service type (e.g. Plumbing, Electrical)"
//                                 v-model="filters.serviceType"
//                             />
//                         </div>
//                     </div>
//                     <div class="row mt-2">
//                         <div class="col-md-4 mb-2">
//                             <input
//                                 type="text"
//                                 class="form-control"
//                                 placeholder="City"
//                                 v-model="filters.location.city"
//                             />
//                         </div>
//                         <div class="col-md-4 mb-2">
//                             <input
//                                 type="text"
//                                 class="form-control"
//                                 placeholder="State"
//                                 v-model="filters.location.state"
//                             />
//                         </div>
//                         <div class="col-md-4 mb-2">
//                             <input
//                                 type="text"
//                                 class="form-control"
//                                 placeholder="PIN Code"
//                                 v-model="filters.location.pinCode"
//                             />
//                         </div>
//                     </div>
//                     <div class="row mt-3">
//                         <div class="col">
//                             <button @click="searchServices" class="btn btn-primary">
//                                 Search Services
//                             </button>
//                         </div>
//                     </div>
//                 </div>
//             </div>

//             <div v-if="error" class="alert alert-danger">
//                 {{ error }}
//             </div>

//             <div v-if="hasSearched">
//                 <h3 class="display-6 mb-3">Available Services</h3>
//                 <div v-if="services.length === 0" class="alert alert-info">
//                     No services found matching your search criteria.
//                 </div>
//                 <div v-else class="row">
//                     <div v-for="service in services" 
//                          :key="service.id" 
//                          class="col-md-4 mb-3">
//                         <div class="card h-100 shadow-sm">
//                             <div class="card-body">
//                                 <h5 class="card-title">{{ service.name || service.service_type }}</h5>
//                                 <div class="card-text">
//                                     <p class="mb-1">
//                                         <strong>Provider:</strong> {{ service.professional.name }}
//                                     </p>
//                                     <p class="mb-1">
//                                         <strong>Location:</strong> {{ service.professional.city }}, {{ service.professional.state }}
//                                     </p>
//                                     <p class="mb-1">
//                                         <strong>PIN Code:</strong> {{ service.professional.pin_code }}
//                                     </p>
//                                     <p class="mb-1">
//                                         <strong>Description:</strong> {{ service.description }}
//                                     </p>
//                                     <p v-if="service.price" class="mb-1">
//                                         <strong>Price:</strong> $, {{ service.price.toFixed(2) }}
//                                     </p>
//                                     <p v-if="service.time_required" class="mb-1">
//                                         <strong>Estimated Time:</strong> {{ service.time_required }} mins
//                                     </p>
//                                     <p class="mb-1">
//                                         <strong>Experience:</strong> {{ service.professional.experience }} years
//                                     </p>
//                                 </div>
//                                 <div class="mt-3 d-flex gap-2">
//                                     <router-link 
//                                         :to="{ name: 'ViewProfile', params: { id: service.professional.user_id }}"
//                                         class="btn btn-outline-primary"
//                                     >
//                                         View Provider
//                                     </router-link>
//                                     <router-link 
//                                         class="btn btn-outline-secondary" 
//                                         :to="{ 
//                                             path: '/request-service', 

//                                         }"
//                                     >
//                                         Request Service
//                                     </router-link>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     `,
// };