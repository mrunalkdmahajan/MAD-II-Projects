export default {
    data() {
        return {
            user: {
                id: null,
                username: '',
                email: '',
                active: false,
                is_blocked: false
            },
            loading: true,
            error: null
        };
    },
    async created() {
        try {
            const token = localStorage.getItem("auth-token");
            console.log("Token:", token); // Debug token

            if (!token) {
                this.error = "Authentication required";
                this.loading = false;
                return;
            }

            const response = await fetch('/api/user/profile', {
                method: 'GET',
                headers: {
                    // For Flask-Security token authentication
                    "Authentication-Token": token
                }
            });

            // More detailed error logging
            if (!response.ok) {
                const errorText = await response.text();
                console.error('Full error response:', errorText);
                throw new Error(`HTTP error! Status: ${response.status}, ${errorText}`);
            }

            this.user = await response.json();
            this.loading = false;
        } catch (error) {
            console.error('Detailed error:', error);
            this.error = error.message;
            this.loading = false;
        }
    },
    methods: {
        navigateToEditProfile() {
            // Assuming you're using vue-router for navigation
            this.$router.push('/admin/edit/profile');
        }
    },
    template: `
<div class="container mt-4">
  <h3 class="text-center mb-3">User Profile</h3>
  <div v-if="loading" class="text-center">
    <div class="spinner-border" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
  </div>
  <div v-else-if="error" class="alert alert-danger" role="alert">
    {{ error }}
  </div>
  <div v-else class="card mx-auto" style="max-width: 400px;">
    <div class="card-body">
      <h5 class="card-title text-center">{{ user.username }}</h5>
      <p class="card-text"><strong>ID:</strong> {{ user.id }}</p>
      <p class="card-text"><strong>Email:</strong> {{ user.email }}</p>
      <p class="card-text">
        <strong>Active:</strong> 
        <span :class="{'text-success': user.active, 'text-danger': !user.active}">
          {{ user.active ? 'Yes' : 'No' }}
        </span>
      </p>
      <p class="card-text">
        <strong>Blocked:</strong> 
        <span :class="{'text-success': !user.is_blocked, 'text-danger': user.is_blocked}">
          {{ user.is_blocked ? 'Yes' : 'No' }}
        </span>
      </p>
      <button 
        @click="navigateToEditProfile" 
        class="btn btn-primary w-100 mt-3"
      >
        Edit Profile
      </button>
    </div>
  </div>
</div>
`
};