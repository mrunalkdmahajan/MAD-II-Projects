export default {
    template: `
      <div>
        <div class="heading">
          <h1 class="display-1">Register as Customer</h1>
          <div class="d-flex flex-column align-items-start m-3">
            <router-link to="/login" class="btn btn-light-yellow">
              <i class="fas fa-sign-in-alt"></i> Login
            </router-link>
            <router-link to="/register-professional" class="btn btn-light-yellow">
              <i class="fas fa-briefcase"></i> Professional Register
            </router-link>
          </div>
        </div>
  
        <form @submit.prevent="registerCustomer" class="form">
          <div class="form-group">
            <label for="username" class="form-label">Username</label>
            <input v-model="form.username" type="text" name="username" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="email" class="form-label">Email</label>
            <input v-model="form.email" type="email" name="email" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="password" class="form-label">Password</label>
            <input v-model="form.password" type="password" name="password" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="confirm_password" class="form-label">Confirm Password</label>
            <input v-model="form.confirmPassword" type="password" name="confirm_password" required class="form-control" />
          </div>
          <div class="form-group">
            <input type="submit" value="Register" class="btn btn-primary" />
          </div>
        </form>
      </div>
    `,

    data() {
        return {
            form: {
                username: '',
                email: '',
                password: '',
                confirmPassword: ''
            },
        };
    },

    methods: {
        async registerCustomer() {
            if (this.form.password !== this.form.confirmPassword) {
                alert("Passwords don't match!");
                return;
            }

            try {
                const response = await fetch('/api/register_customer', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.form),
                });
                const result = await response.json();
                if (response.ok) {
                    alert(result.message);
                    this.$router.push('/login');
                } else {
                    alert(result.error);
                }
            } catch (error) {
                alert('An error occurred during registration.');
            }
        },
    },
};