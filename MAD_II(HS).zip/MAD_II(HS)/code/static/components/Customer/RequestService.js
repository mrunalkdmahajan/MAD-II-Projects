export default {
    name: "RequestService",
    data() {
        return {
            serviceId: null,
            professionalId: null,
            remarks: "",
            isSubmitting: false,
            successMessage: "",
            errorMessage: "",
            serviceDetails: null
        };
    },
    created() {
        // Get the serviceId from the route query parameters
        this.serviceId = this.$route.query.serviceId;
        this.professionalId = this.$route.query.professionalId;

        if (this.serviceId) {
            this.fetchServiceDetails();
        }
    },
    methods: {
        async fetchServiceDetails() {
            try {
                const token = localStorage.getItem("auth-token");
                console.log("Auth Token:", token);
                if (!token) {
                    this.errorMessage = "Authentication required.";
                    return;
                }
                console.log("Auth token:", token);
                console.log("Stored Token:", localStorage.getItem("auth-token"));

                const response = await fetch(`/api/service/${this.serviceId}`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token
                            // "Authorization": `Bearer ${token}`

                    },
                    credentials: "include"
                });

                if (!response.ok) {
                    throw new Error("Failed to fetch service details");
                }

                const data = await response.json();
                this.serviceDetails = data.service;
            } catch (error) {
                console.error("Error fetching service details:", error);
                // this.errorMessage = "Unable to load service details. Please try again later.";
            }
        },
        async submitRequest() {
            try {
                this.isSubmitting = true;
                this.errorMessage = "";
                this.successMessage = "";

                const token = localStorage.getItem("auth-token");
                if (!token) {
                    this.errorMessage = "Authentication required.";
                    this.isSubmitting = false;
                    return;
                }

                // Validate required fields
                if (!this.serviceId) {
                    this.errorMessage = "Service ID is required.";
                    this.isSubmitting = false;
                    return;
                }

                const requestData = {
                    service_id: this.serviceId,
                    professional_id: this.professionalId,
                    remarks: this.remarks
                };

                const response = await fetch("/api/service-requests", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token
                    },
                    body: JSON.stringify(requestData)
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(errorText || "Failed to create service request");
                }

                this.successMessage = "Service request submitted successfully!";
                this.remarks = ""; // Clear form

                // Redirect to requests list after 2 seconds
                setTimeout(() => {
                    this.$router.push("/customer/request-service");
                }, 2000);
            } catch (error) {
                console.error("Error submitting service request:", error);
                this.errorMessage = "Failed to submit service request. Please try again later.";
            } finally {
                this.isSubmitting = false;
            }
        }
    },
    template: `
        <div class="container mt-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3>Request Service</h3>
                </div>
                <div class="card-body">
                    <div v-if="errorMessage" class="alert alert-danger">
                        {{ errorMessage }}
                    </div>
                    <div v-if="successMessage" class="alert alert-success">
                        {{ successMessage }}
                    </div>

                    <div v-if="serviceDetails" class="mb-4">
                        <h4>Service Details</h4>
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title">{{ serviceDetails.name || serviceDetails.service_type }}</h5>
                                <p><strong>Provider:</strong> {{ serviceDetails.professional.name }}</p>
                                <p><strong>Description:</strong> {{ serviceDetails.description }}</p>
                                <p v-if="serviceDetails.price"><strong>Price:</strong> $, {{ serviceDetails.price.toFixed(2) }}</p>
                                <p v-if="serviceDetails.time_required"><strong>Estimated Time:</strong> {{ serviceDetails.time_required }} mins</p>
                            </div>
                        </div>
                    </div>

                    <form @submit.prevent="submitRequest">
                        <div class="mb-3">
                            <label for="remarks" class="form-label">Additional Information or Requirements</label>
                            <textarea 
                                id="remarks" 
                                v-model="remarks" 
                                class="form-control" 
                                rows="4" 
                                placeholder="Provide any additional details about your service request..."
                            ></textarea>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button 
                                type="submit" 
                                class="btn btn-primary" 
                                :disabled="isSubmitting"
                            >
                                <span v-if="isSubmitting" class="spinner-border spinner-border-sm me-1"></span>
                                Submit Request
                            </button>
                            <router-link to="/search-services" class="btn btn-outline-secondary">
                                Cancel
                            </router-link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `
};