export default {
    name: "CustomerFinds",
    template: `
<div class="container mt-5">
  <h2>Find Professionals (Services Available)</h2>
  <div v-if="loading" class="text-center mt-3">
    <div class="spinner-border" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
  </div>
  <div v-else-if="error" class="alert alert-danger mt-3">
    {{ error }}
  </div>
  <table v-else class="table table-bordered mt-3">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Price</th>
        <th>Time Required</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="service in services" :key="service.id">
        <td>{{ service.id }}</td>
        <td>{{ service.name }}</td>
        <td>{{ service.price }}</td>
        <td>{{ service.time_required }} mins</td>
        <td>{{ service.description }}</td>
      </tr>
    </tbody>
  </table>
</div>
`,
    data() {
        return {
            services: [],
            loading: true,
            error: null
        };
    },
    async created() {
        try {
            const token = localStorage.getItem("auth-token"); // Ensure correct key name
            console.log(localStorage.getItem("auth-token"));


            if (!token) {
                this.error = "Authentication required";
                this.loading = false;
                return;
            }

            const response = await fetch("/api/customer/find", {
                method: "GET",
                headers: {
                    "Authentication-Token": token // Flask-Security uses "Authentication-Token"
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            this.services = await response.json();
        } catch (error) {
            console.error("Error fetching services:", error);
            this.error = error.message;
        } finally {
            this.loading = false;
        }
    }
};