export default {
    template: `
    <div class="container">
        <h1>Available Services</h1>
        
        <!-- Search and Filter -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <input v-model="searchQuery" 
                               class="form-control" 
                               placeholder="Search services...">
                    </div>
                    <div class="col-md-4">
                        <select v-model="categoryFilter" class="form-select">
                            <option value="">All Categories</option>
                            <option v-for="category in categories" 
                                    :key="category"
                                    :value="category">
                                {{ category }}
                            </option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <select v-model="sortBy" class="form-select">
                            <option value="name">Name</option>
                            <option value="price">Price</option>
                            <option value="rating">Rating</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Service Cards -->
        <div class="row">
            <div v-for="service in filteredServices" 
                 :key="service.id" 
                 class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">{{ service.name }}</h5>
                        <p class="card-text">{{ service.description }}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="h5">$, {{ service.price }}</span>
                            <div class="text-warning">
                                {{ service.rating }} ⭐
                            </div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <router-link :to="{ name: 'ServiceDetail', params: { id: service.id }}"
                                       class="btn btn-primary">
                                View Details
                            </router-link>
                            <button @click="requestService(service.id)"
                                    class="btn btn-success">
                                Request Service
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `,
    data() {
        return {
            services: [],
            categories: [],
            searchQuery: '',
            categoryFilter: '',
            sortBy: 'name'
        };
    },
    computed: {
        filteredServices() {
            return this.services
                .filter(service => {
                    const matchesSearch = service.name.toLowerCase().includes(this.searchQuery.toLowerCase());
                    const matchesCategory = !this.categoryFilter || service.category === this.categoryFilter;
                    return matchesSearch && matchesCategory;
                })
                .sort((a, b) => {
                    if (this.sortBy === 'price') return a.price - b.price;
                    if (this.sortBy === 'rating') return b.rating - a.rating;
                    return a.name.localeCompare(b.name);
                });
        }
    },
    methods: {
        async fetchServices() {
            try {
                const response = await fetch('/api/services');
                const data = await response.json();
                this.services = data.services;
                this.categories = [...new Set(data.services.map(s => s.category))];
            } catch (error) {
                console.error('Error fetching services:', error);
            }
        },
        async requestService(serviceId) {
            try {
                const response = await fetch('/api/service-requests', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ service_id: serviceId })
                });
                const data = await response.json();
                if (response.ok) {
                    alert('Service requested successfully!');
                } else {
                    alert(data.error);
                }
            } catch (error) {
                console.error('Error requesting service:', error);
                alert('Failed to request service');
            }
        }
    },
    created() {
        this.fetchServices();
    }
};