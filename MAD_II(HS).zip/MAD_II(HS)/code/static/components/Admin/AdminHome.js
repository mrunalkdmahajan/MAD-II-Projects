export default {
    data() {
        return {
            professionals: [],
            customers: [],
            pendingVerifications: [],
            loading: true,
            error: null,
            activeTab: 'professionals',
            showDetailsModal: false,
            selectedProfessional: null,
            isWaiting: false
        };
    },
    async created() {
        this.fetchData();
    },
    methods: {
        async viewProfessional(professionalId) {
            try {
                const token = localStorage.getItem("auth-token");
                if (!token) {
                    alert("Authentication required");
                    return;
                }

                const response = await fetch(`/api/admin/professionals/${professionalId}/details`, {
                    headers: {
                        "Authentication-Token": token,
                    }
                });

                const data = await response.json();

                if (response.ok) {
                    this.selectedProfessional = data;
                    this.showDetailsModal = true; // Open modal
                } else {
                    alert("Error fetching details: " + (data.error || "Unknown error"));
                }
            } catch (error) {
                console.error("Error fetching professional details:", error);
                alert("Failed to fetch professional details");
            }
        },

        async handleVerification(userId, approved) {
            try {
                const token = localStorage.getItem("auth-token");


                if (!token) {
                    alert("Authentication required");
                    return;
                }

                const response = await fetch(`/api/admin/professionals/${userId}/verify`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token,
                    },

                    body: JSON.stringify({ approved })
                });

                const data = await response.json();

                if (response.ok) {
                    alert(data.message || "Verification processed successfully");
                    // Refresh data after verification
                    await this.fetchData();
                } else {
                    alert(`Error: ${data.error || "Failed to process verification"}`);
                }
            } catch (error) {
                console.error("Verification failed:", error);
                alert("An error occurred while processing verification.");
            }
        },
        async downloadResource() {
            this.isWaiting = true;
            const token = localStorage.getItem("auth-token");
            const res = await fetch('/export-service-requests', {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            const data = await res.json();
            if (res.ok) {
                const taskId = data['task-id'];
                const intv = setInterval(async() => {
                    const csv_res = await fetch(`/get-service-requests-csv/${taskId}`, {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    });
                    if (csv_res.ok) {
                        this.isWaiting = false;
                        clearInterval(intv);
                        window.location.href = `/get-service-requests-csv/${taskId}`;
                    }
                }, 1000);
            }
        },

        async fetchData() {
            try {
                const token = localStorage.getItem("auth-token");
                if (!token) {
                    this.error = "Authentication required";
                    this.loading = false;
                    return;
                }

                // Fetch blocked professionals
                const proResponse = await fetch('/api/admin/professionals/blocked', {
                    headers: {
                        "Authentication-Token": token
                    }
                });

                // Fetch blocked customers
                const custResponse = await fetch('/api/admin/customers/blocked', {
                    headers: {
                        "Authentication-Token": token
                    }
                });

                // Fetch pending verifications
                const verifyResponse = await fetch('/api/admin/professionals/pending', {
                    headers: {
                        "Authentication-Token": token
                    }
                });

                if (!proResponse.ok || !custResponse.ok || !verifyResponse.ok) {
                    throw new Error('Failed to fetch data');
                }

                this.professionals = await proResponse.json();
                this.customers = await custResponse.json();
                this.pendingVerifications = await verifyResponse.json();
                this.loading = false;
            } catch (error) {
                console.error('Error fetching data:', error);
                this.error = error.message;
                this.loading = false;
            }
        },

        async handleUnblock(userId, userType) {
            try {
                const token = localStorage.getItem("auth-token");

                const response = await fetch(`/api/admin/users/${userId}/unblock`, {
                    method: 'POST',
                    headers: {
                        "Authentication-Token": token,
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ user_type: userType })
                });

                if (!response.ok) {
                    throw new Error('Failed to unblock user');
                }

                // Refresh data
                await this.fetchData();
            } catch (error) {
                this.error = error.message;
            }
        }


    },

    template: `
        <div class="container mt-4">
            <h2 class="text-center mb-4">Admin Dashboard</h2>

            <!-- Loading Spinner -->
            <div v-if="loading" class="text-center">
                <div class="spinner-border" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>

            <!-- Error Alert -->
            <div v-else-if="error" class="alert alert-danger" role="alert">
                {{ error }}
            </div>

            <!-- Dashboard Content -->
            <div v-else>
                
                <!-- Export Button -->
                <div class="d-flex justify-content-end mb-3">
                    <button @click="downloadResource" class="btn btn-primary" :disabled="isWaiting">
                        {{ isWaiting ? 'Processing...' : 'Export Service Requests' }}
                    </button>
                </div>
                <!-- Navigation Tabs -->
                <ul class="nav nav-tabs mb-4">
                    <li class="nav-item">
                        <a class="nav-link" 
                           :class="{ active: activeTab === 'professionals' }"
                           @click.prevent="activeTab = 'professionals'"
                           href="#">
                            Blocked Professionals
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           :class="{ active: activeTab === 'customers' }"
                           @click.prevent="activeTab = 'customers'"
                           href="#">
                            Blocked Customers
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           :class="{ active: activeTab === 'verifications' }"
                           @click.prevent="activeTab = 'verifications'"
                           href="#">
                            Pending Verifications
                        </a>
                    </li>
                </ul>

                <!-- Blocked Professionals Tab -->
                <div v-if="activeTab === 'professionals'" class="tab-content">
                    <div class="card">
                        <div class="card-header">
                            <h4>Blocked Professionals</h4>
                        </div>
                        <div class="card-body">
                            <div v-if="professionals.length === 0" class="text-center text-muted">
                                No blocked professionals found
                            </div>
                            <div v-else class="list-group">
                                <div v-for="pro in professionals" 
                                     :key="pro.id"
                                     class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <h5 class="mb-1">{{ pro.username }}</h5>
                                        <p class="mb-1">{{ pro.email }}</p>
                                        <small v-if="pro.profile">
                                            Service: {{ pro.profile.service_type }} | 
                                            Experience: {{ pro.profile.experience }} years
                                        </small>
                                    </div>
                                    <button @click="handleUnblock(pro.id, 'professional')"
                                            class="btn btn-success">
                                        Unblock
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Blocked Customers Tab -->
                <div v-if="activeTab === 'customers'" class="tab-content">
                    <div class="card">
                        <div class="card-header">
                            <h4>Blocked Customers</h4>
                        </div>
                        <div class="card-body">
                            <div v-if="customers.length === 0" class="text-center text-muted">
                                No blocked customers found
                            </div>
                            <div v-else class="list-group">
                                <div v-for="customer in customers" 
                                     :key="customer.id"
                                     class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <h5 class="mb-1">{{ customer.username }}</h5>
                                        <p class="mb-1">{{ customer.email }}</p>
                                    </div>
                                    <button @click="handleUnblock(customer.id, 'customer')"
                                            class="btn btn-success">
                                        Unblock
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pending Verifications Tab -->
                <div v-if="activeTab === 'verifications'" class="tab-content">
                    <div class="card">
                        <div class="card-header">
                            <h4>Pending Verifications</h4>
                        </div>
                        <div class="card-body">
                            <div v-if="pendingVerifications.length === 0" class="text-center text-muted">
                                No pending verifications found
                            </div>
                            <div v-else class="list-group">
                                <div v-for="pro in pendingVerifications" 
                                     :key="pro.id"
                                     class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h5 class="mb-1">{{ pro.username }}</h5>
                                            <p class="mb-1">{{ pro.email }}</p>
                                            <div v-if="pro.profile">
                                                <p class="mb-1">Service: {{ pro.profile.service_type }}</p>
                                                <p class="mb-1">Experience: {{ pro.profile.experience }} years</p>
                                                <p class="mb-1">Description: {{ pro.profile.description }}</p>
                                            </div>
                                        </div>
                                        <div class="btn-group">
                                            <button @click="handleVerification(pro.id, true)"
                                                    class="btn btn-success me-2">
                                                Approve
                                            </button>
                                            <button @click="handleVerification(pro.id, false)"
                                                    class="btn btn-danger me-2">
                                                Reject
                                            </button>
                                            <button @click="viewProfessional(pro.id)"
                                                    class="btn btn-info">
                                                View
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Professional Details Modal -->
                <div v-if="showDetailsModal" class="modal fade show d-block" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Professional Details</h5>
                                <button type="button" class="btn-close" @click="showDetailsModal = false"></button>
                            </div>
                            <div class="modal-body" v-if="selectedProfessional">
                                <p><strong>Username:</strong> {{ selectedProfessional.username }}</p>
                                <p><strong>Email:</strong> {{ selectedProfessional.email }}</p>
                                <p><strong>Role:</strong> {{ selectedProfessional.roles.map(r => r.name).join(', ') }}</p>
                                <hr>
                                <h5>Professional Profile</h5>
                                <div v-if="selectedProfessional.profile">
                                    <p><strong>Service Type:</strong> {{ selectedProfessional.profile.service_type }}</p>
                                    <p><strong>Experience:</strong> {{ selectedProfessional.profile.experience }} years</p>
                                    <p><strong>Description:</strong> {{ selectedProfessional.profile.description }}</p>
                                    <p><strong>City:</strong> {{ selectedProfessional.profile.city }}</p>
                                    <p><strong>State:</strong> {{ selectedProfessional.profile.state }}</p>
                                    <p><strong>Pin Code:</strong> {{ selectedProfessional.profile.pin_code }}</p>
                                    <p><strong>Verified:</strong> {{ selectedProfessional.profile.is_verified ? "Yes" : "No" }}</p>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" @click="showDetailsModal = false">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `
};