export default {
    data() {
        return {
            users: [] // Store all user details
        };
    },
    async created() {
        try {
            const response = await fetch('/api/admin/profile', {
                headers: {
                    "Authorization": "Bearer " + localStorage.getItem("token") // Ensure token is sent
                }
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            this.users = await response.json();
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    },
    template: `
      <div class="container mt-4">
        <h3 class="text-center mb-3">Admin - User Profiles</h3>
        <div class="table-responsive">
          <table class="table table-striped table-bordered">
            <thead class="thead-dark">
              <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Active</th>
                <th>Blocked</th>
                <th>Admin</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="user in users" :key="user.id">
                <td>{{ user.id }}</td>
                <td>{{ user.username }}</td>
                <td>{{ user.email }}</td>
                <td :class="{'text-success': user.active, 'text-danger': !user.active}">
                  {{ user.active ? 'Yes' : 'No' }}
                </td>
                <td :class="{'text-success': !user.is_blocked, 'text-danger': user.is_blocked}">
                  {{ user.is_blocked ? 'Yes' : 'No' }}
                </td>
                <td :class="{'text-success': user.is_admin, 'text-danger': !user.is_admin}">
                  {{ user.is_admin ? 'Yes' : 'No' }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `
};