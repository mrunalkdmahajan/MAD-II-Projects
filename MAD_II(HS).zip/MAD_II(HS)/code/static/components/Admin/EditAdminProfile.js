export default {
    data() {
        return {
            admin: {
                username: '',
                email: '',
                active: false,
                is_blocked: false,
                is_admin: false
            },
            loading: true,
            error: null
        };
    },
    async created() {
        await this.fetchAdminProfile();
    },
    methods: {
        async fetchAdminProfile() {
            try {
                const token = localStorage.getItem("auth-token");
                if (!token) {
                    this.error = "Authentication required";
                    this.loading = false;
                    return;
                }

                const response = await fetch('/api/admin/profile', {
                    headers: { "Authentication-Token": token }
                });

                if (!response.ok) throw new Error(await response.text());

                this.admin = await response.json();
            } catch (error) {
                this.error = error.message;
            } finally {
                this.loading = false;
            }
        },
        async updateProfile() {
            try {
                const token = localStorage.getItem("auth-token");
                if (!token) {
                    this.error = "Authentication required";
                    return;
                }

                const response = await fetch('/api/admin/profile/update', {
                    method: 'PUT',
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token
                    },
                    body: JSON.stringify(this.admin)
                });

                if (!response.ok) throw new Error(await response.text());

                alert("Profile updated successfully!");
                this.$router.push('/admin/profile');
            } catch (error) {
                this.error = error.message;
            }
        }
    },
    template: `
      <div class="container mt-4">
        <h3 class="text-center mb-3">Edit Admin Profile</h3>
        <div v-if="loading" class="text-center">
          <div class="spinner-border" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>
        <div v-else-if="error" class="alert alert-danger" role="alert">
          {{ error }}
        </div>
        <form v-else @submit.prevent="updateProfile" class="card mx-auto p-4" style="max-width: 500px;">
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input v-model="admin.username" type="text" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input v-model="admin.email" type="email" class="form-control" required />
          </div>
          <div class="mb-3 form-check">
            <input v-model="admin.active" type="checkbox" class="form-check-input" />
            <label class="form-check-label">Active</label>
          </div>
          <div class="mb-3 form-check">
            <input v-model="admin.is_blocked" type="checkbox" class="form-check-input" />
            <label class="form-check-label">Blocked</label>
          </div>
          <div class="mb-3 form-check">
            <input v-model="admin.is_admin" type="checkbox" class="form-check-input" />
            <label class="form-check-label">Admin</label>
          </div>
          <button type="submit" class="btn btn-success w-100">Save Changes</button>
        </form>
      </div>
    `
};