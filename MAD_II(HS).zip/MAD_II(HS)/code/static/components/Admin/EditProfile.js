export default {
    data() {
        return {
            user: {
                username: '',
                email: '',
            },
            loading: true,
            error: null,
            success: null
        };
    },
    async created() {
        try {
            const token = localStorage.getItem("auth-token");
            if (!token) {
                this.error = "Authentication required";
                this.loading = false;
                return;
            }

            const response = await fetch('/api/user/profile', {
                headers: {
                    "Authentication-Token": token
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const userData = await response.json();
            this.user.username = userData.username;
            this.user.email = userData.email;
            this.loading = false;
        } catch (error) {
            console.error('Error fetching user profile:', error);
            this.error = error.message;
            this.loading = false;
        }
    },
    methods: {
        async updateProfile() {
            try {
                this.loading = true;
                this.error = null;
                this.success = null;

                const token = localStorage.getItem("auth-token");
                if (!token) {
                    this.error = "Authentication required";
                    this.loading = false;
                    return;
                }

                const response = await fetch('/api/user/profile/edit', {
                    method: 'PUT',
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token
                    },
                    body: JSON.stringify({
                        username: this.user.username,
                        email: this.user.email
                    })
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || `HTTP error! Status: ${response.status}`);
                }

                this.success = "Profile updated successfully!";
                this.loading = false;
                this.$router.push('/customer/profile');
            } catch (error) {
                console.error('Error updating profile:', error);
                this.error = error.message;
                this.loading = false;
            }
        }
    },
    template: `
  <div class="container mt-4">
    <h3 class="text-center mb-3">Edit Profile</h3>
    <div v-if="loading" class="text-center">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
    <div v-else-if="error" class="alert alert-danger" role="alert">
      {{ error }}
    </div>
    <div v-else-if="success" class="alert alert-success" role="alert">
      {{ success }}
    </div>
    <form v-else @submit.prevent="updateProfile" class="card mx-auto" style="max-width: 400px;">
      <div class="card-body">
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <input 
            type="text" 
            class="form-control" 
            id="username" 
            v-model="user.username" 
            required
          >
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
          <input 
            type="email" 
            class="form-control" 
            id="email" 
            v-model="user.email" 
            required
          >
        </div>
        <button type="submit" class="btn btn-primary w-100">Update Profile</button>
      </div>
    </form>
  </div>
`
};