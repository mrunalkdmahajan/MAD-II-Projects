export default {
    template: `
    <div>
      This is VP Home
    </div>
  `
}