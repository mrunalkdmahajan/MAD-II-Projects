// // export default {
// //     name: "ServiceRequestsChart",
// //     data() {
// //         return {
// //             error: null
// //         };
// //     },
// //     // Use mounted hook to ensure DOM is ready
// //     mounted() {
// //         // Directly create charts in mounted hook
// //         this.renderCharts();
// //     },
// //     methods: {
// //         renderCharts() {
// //             // Make sure Chart.js is available
// //             if (typeof Chart === 'undefined') {
// //                 console.error("Chart.js is not loaded!");
// //                 this.error = "Chart.js library not found. Please include Chart.js in your project.";
// //                 return;
// //             }

// //             // Basic data for charts
// //             const requestsData = {
// //                 labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
// //                 datasets: [{
// //                     label: "Service Requests",
// //                     data: [42, 56, 63, 51, 58, 70],
// //                     backgroundColor: "rgba(0, 123, 255, 0.2)",
// //                     borderColor: "rgba(0, 123, 255, 1)",
// //                     borderWidth: 1
// //                 }]
// //             };

// //             const ratingsData = {
// //                 labels: ["John", "Jane", "Mike", "Sarah", "David"],
// //                 datasets: [{
// //                     label: "Average Rating",
// //                     data: [4.7, 4.2, 4.9, 3.8, 4.5],
// //                     backgroundColor: "rgba(255, 193, 7, 0.2)",
// //                     borderColor: "rgba(255, 193, 7, 1)",
// //                     borderWidth: 1
// //                 }]
// //             };

// //             // Get canvas elements directly from DOM
// //             const requestsCanvas = document.getElementById('requestsChart');
// //             const ratingsCanvas = document.getElementById('ratingsChart');

// //             // Check if canvas elements exist
// //             if (!requestsCanvas || !ratingsCanvas) {
// //                 console.error("Canvas elements not found");
// //                 this.error = "Chart canvas elements not found in the DOM.";
// //                 return;
// //             }

// //             try {
// //                 // Create requests chart
// //                 new Chart(requestsCanvas, {
// //                     type: 'line',
// //                     data: requestsData,
// //                     options: {
// //                         responsive: true,
// //                         maintainAspectRatio: false
// //                     }
// //                 });

// //                 // Create ratings chart
// //                 new Chart(ratingsCanvas, {
// //                     type: 'bar',
// //                     data: ratingsData,
// //                     options: {
// //                         responsive: true,
// //                         maintainAspectRatio: false,
// //                         scales: {
// //                             y: {
// //                                 beginAtZero: true,
// //                                 max: 5
// //                             }
// //                         }
// //                     }
// //                 });

// //                 console.log("Charts created successfully");
// //             } catch (err) {
// //                 console.error("Error creating charts:", err);
// //                 this.error = "Failed to render charts: " + err.message;
// //             }
// //         }
// //     },
// //     template: `
// //       <div class="container mt-4">
// //           <h2 class="mb-4">Service Insights</h2>
// //           <div v-if="error" class="alert alert-danger">{{ error }}</div>
// //           <div class="row">
// //               <div class="col-md-6 mb-4">
// //                   <div class="card">
// //                       <div class="card-header bg-primary text-white">
// //                           <h5 class="mb-0">Service Requests Over Time</h5>
// //                       </div>
// //                       <div class="card-body" style="height: 300px;">
// //                           <!-- Use ID instead of ref -->
// //                           <canvas id="requestsChart"></canvas>
// //                       </div>
// //                   </div>
// //               </div>
// //               <div class="col-md-6 mb-4">
// //                   <div class="card">
// //                       <div class="card-header bg-warning text-dark">
// //                           <h5 class="mb-0">Average Rating per Professional</h5>
// //                       </div>
// //                       <div class="card-body" style="height: 300px;">
// //                           <!-- Use ID instead of ref -->
// //                           <canvas id="ratingsChart"></canvas>
// //                       </div>
// //                   </div>
// //               </div>
// //           </div>
// //       </div>
// //   `
// // };


// export default {
//     name: "ServiceRequestsChart",
//     data() {
//         return {
//             error: null,
//             requestsData: null,
//             ratingsData: null,
//             serviceTypeData: null,
//             completionTimeData: null,
//             loading: true
//         };
//     },
//     // Use mounted hook to ensure DOM is ready
//     mounted() {
//         // Fetch data from API endpoints
//         this.fetchChartData();
//     },
//     methods: {
//         async fetchChartData() {
//             try {
//                 // Fetch all required data for charts
//                 const [requestsResponse, ratingsResponse, serviceTypeResponse, completionTimeResponse] = await Promise.all([
//                     fetch('/api/service-requests/monthly'),
//                     fetch('/api/professionals/ratings'),
//                     fetch('/api/service-types/distribution'),
//                     fetch('/api/service-requests/completion-time')
//                 ]);

//                 // Process responses
//                 this.requestsData = await requestsResponse.json();
//                 this.ratingsData = await ratingsResponse.json();
//                 this.serviceTypeData = await serviceTypeResponse.json();
//                 this.completionTimeData = await completionTimeResponse.json();

//                 this.loading = false;
//                 // Render charts once data is loaded
//                 this.renderCharts();
//             } catch (err) {
//                 console.error("Error fetching chart data:", err);
//                 this.error = "Failed to fetch chart data: " + err.message;
//                 this.loading = false;
//             }
//         },
//         renderCharts() {
//             // Make sure Chart.js is available
//             if (typeof Chart === 'undefined') {
//                 console.error("Chart.js is not loaded!");
//                 this.error = "Chart.js library not found. Please include Chart.js in your project.";
//                 return;
//             }

//             // Get canvas elements directly from DOM
//             const requestsCanvas = document.getElementById('requestsChart');
//             const ratingsCanvas = document.getElementById('ratingsChart');
//             const serviceTypeCanvas = document.getElementById('serviceTypeChart');
//             const completionTimeCanvas = document.getElementById('completionTimeChart');

//             // Check if canvas elements exist
//             if (!requestsCanvas || !ratingsCanvas || !serviceTypeCanvas || !completionTimeCanvas) {
//                 console.error("Canvas elements not found");
//                 this.error = "Chart canvas elements not found in the DOM.";
//                 return;
//             }

//             try {
//                 // If no data received yet, use dummy data
//                 const requestsData = this.requestsData || {
//                     labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
//                     datasets: [{
//                         label: "Service Requests",
//                         data: [42, 56, 63, 51, 58, 70],
//                         backgroundColor: "rgba(0, 123, 255, 0.2)",
//                         borderColor: "rgba(0, 123, 255, 1)",
//                         borderWidth: 1
//                     }]
//                 };

//                 const ratingsData = this.ratingsData || {
//                     labels: ["John", "Jane", "Mike", "Sarah", "David"],
//                     datasets: [{
//                         label: "Average Rating",
//                         data: [4.7, 4.2, 4.9, 3.8, 4.5],
//                         backgroundColor: "rgba(255, 193, 7, 0.2)",
//                         borderColor: "rgba(255, 193, 7, 1)",
//                         borderWidth: 1
//                     }]
//                 };

//                 // Service Type Distribution - Pie Chart
//                 const serviceTypeData = this.serviceTypeData || {
//                     labels: ["Plumbing", "Electrical", "Carpentry", "Cleaning", "Others"],
//                     datasets: [{
//                         label: "Service Type Distribution",
//                         data: [30, 25, 15, 20, 10],
//                         backgroundColor: [
//                             "rgba(255, 99, 132, 0.6)",
//                             "rgba(54, 162, 235, 0.6)",
//                             "rgba(255, 206, 86, 0.6)",
//                             "rgba(75, 192, 192, 0.6)",
//                             "rgba(153, 102, 255, 0.6)"
//                         ],
//                         borderColor: [
//                             "rgba(255, 99, 132, 1)",
//                             "rgba(54, 162, 235, 1)",
//                             "rgba(255, 206, 86, 1)",
//                             "rgba(75, 192, 192, 1)",
//                             "rgba(153, 102, 255, 1)"
//                         ],
//                         borderWidth: 1
//                     }]
//                 };

//                 // Average Completion Time - Bar Chart
//                 const completionTimeData = this.completionTimeData || {
//                     labels: ["Plumbing", "Electrical", "Carpentry", "Cleaning", "Others"],
//                     datasets: [{
//                         label: "Average Completion Time (hours)",
//                         data: [3.5, 2.8, 5.2, 4.0, 3.2],
//                         backgroundColor: "rgba(75, 192, 192, 0.2)",
//                         borderColor: "rgba(75, 192, 192, 1)",
//                         borderWidth: 1
//                     }]
//                 };

//                 // Create requests chart
//                 new Chart(requestsCanvas, {
//                     type: 'line',
//                     data: requestsData,
//                     options: {
//                         responsive: true,
//                         maintainAspectRatio: false
//                     }
//                 });

//                 // Create ratings chart
//                 new Chart(ratingsCanvas, {
//                     type: 'bar',
//                     data: ratingsData,
//                     options: {
//                         responsive: true,
//                         maintainAspectRatio: false,
//                         scales: {
//                             y: {
//                                 beginAtZero: true,
//                                 max: 5
//                             }
//                         }
//                     }
//                 });

//                 // Create service type distribution chart
//                 new Chart(serviceTypeCanvas, {
//                     type: 'pie',
//                     data: serviceTypeData,
//                     options: {
//                         responsive: true,
//                         maintainAspectRatio: false,
//                         plugins: {
//                             legend: {
//                                 position: 'right'
//                             }
//                         }
//                     }
//                 });

//                 // Create completion time chart
//                 new Chart(completionTimeCanvas, {
//                     type: 'bar',
//                     data: completionTimeData,
//                     options: {
//                         responsive: true,
//                         maintainAspectRatio: false,
//                         scales: {
//                             y: {
//                                 beginAtZero: true,
//                                 title: {
//                                     display: true,
//                                     text: 'Average Hours'
//                                 }
//                             }
//                         }
//                     }
//                 });

//                 console.log("Charts created successfully");
//             } catch (err) {
//                 console.error("Error creating charts:", err);
//                 this.error = "Failed to render charts: " + err.message;
//             }
//         }
//     },
//     template: `
//       <div class="container mt-4">
//           <h2 class="mb-4">Service Insights</h2>
//           <div v-if="error" class="alert alert-danger">{{ error }}</div>
//           <div v-if="loading" class="text-center">
//               <div class="spinner-border text-primary" role="status">
//                   <span class="visually-hidden">Loading...</span>
//               </div>
//           </div>
//           <div class="row">
//               <div class="col-md-6 mb-4">
//                   <div class="card">
//                       <div class="card-header bg-primary text-white">
//                           <h5 class="mb-0">Service Requests Over Time</h5>
//                       </div>
//                       <div class="card-body" style="height: 300px;">
//                           <canvas id="requestsChart"></canvas>
//                       </div>
//                   </div>
//               </div>
//               <div class="col-md-6 mb-4">
//                   <div class="card">
//                       <div class="card-header bg-warning text-dark">
//                           <h5 class="mb-0">Average Rating per Professional</h5>
//                       </div>
//                       <div class="card-body" style="height: 300px;">
//                           <canvas id="ratingsChart"></canvas>
//                       </div>
//                   </div>
//               </div>
//               <div class="col-md-6 mb-4">
//                   <div class="card">
//                       <div class="card-header bg-success text-white">
//                           <h5 class="mb-0">Service Type Distribution</h5>
//                       </div>
//                       <div class="card-body" style="height: 300px;">
//                           <canvas id="serviceTypeChart"></canvas>
//                       </div>
//                   </div>
//               </div>
//               <div class="col-md-6 mb-4">
//                   <div class="card">
//                       <div class="card-header bg-info text-white">
//                           <h5 class="mb-0">Average Completion Time by Service Type</h5>
//                       </div>
//                       <div class="card-body" style="height: 300px;">
//                           <canvas id="completionTimeChart"></canvas>
//                       </div>
//                   </div>
//               </div>
//           </div>
//       </div>
//   `
// };


export default {
    name: "ServiceRequestsChart",
    data() {
        return {
            error: null,
            requestsData: null,
            ratingsData: null,
            serviceTypeData: null,
            completionTimeData: null,
            customerSatisfactionData: null,
            revenueData: null,
            loading: true
        };
    },
    // Use mounted hook to ensure DOM is ready
    mounted() {
        // Fetch data from API endpoints
        this.fetchChartData();
    },
    methods: {
        async fetchChartData() {
            try {
                // Fetch all required data for charts
                const [requestsResponse, ratingsResponse, serviceTypeResponse, completionTimeResponse] = await Promise.all([
                    fetch('/api/service-requests/monthly'),
                    fetch('/api/professionals/ratings'),
                    fetch('/api/service-types/distribution'),
                    fetch('/api/service-requests/completion-time')
                ]);

                // Process responses
                this.requestsData = await requestsResponse.json();
                this.ratingsData = await ratingsResponse.json();
                this.serviceTypeData = await serviceTypeResponse.json();
                this.completionTimeData = await completionTimeResponse.json();

                // Set loading to false
                this.loading = false;

                // Render charts once data is loaded
                this.renderCharts();
            } catch (err) {
                console.error("Error fetching chart data:", err);
                this.error = "Failed to fetch chart data: " + err.message;
                this.loading = false;
            }
        },
        renderCharts() {
            // Make sure Chart.js is available
            if (typeof Chart === 'undefined') {
                console.error("Chart.js is not loaded!");
                this.error = "Chart.js library not found. Please include Chart.js in your project.";
                return;
            }

            // Get canvas elements directly from DOM
            const requestsCanvas = document.getElementById('requestsChart');
            const ratingsCanvas = document.getElementById('ratingsChart');
            const serviceTypeCanvas = document.getElementById('serviceTypeChart');
            const completionTimeCanvas = document.getElementById('completionTimeChart');
            const customerSatisfactionCanvas = document.getElementById('customerSatisfactionChart');
            const revenueCanvas = document.getElementById('revenueChart');

            // Check if canvas elements exist
            if (!requestsCanvas || !ratingsCanvas || !serviceTypeCanvas || !completionTimeCanvas ||
                !customerSatisfactionCanvas || !revenueCanvas) {
                console.error("Canvas elements not found");
                this.error = "Chart canvas elements not found in the DOM.";
                return;
            }

            try {
                // Service Requests - Line Chart
                const requestsData = this.requestsData || {
                    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                    datasets: [{
                        label: "Service Requests",
                        data: [42, 56, 63, 51, 58, 70],
                        backgroundColor: "rgba(0, 123, 255, 0.2)",
                        borderColor: "rgba(0, 123, 255, 1)",
                        borderWidth: 1
                    }]
                };

                // Professional Ratings - Bar Chart
                const ratingsData = this.ratingsData || {
                    labels: ["John", "Jane", "Mike", "Sarah", "David"],
                    datasets: [{
                        label: "Average Rating",
                        data: [4.7, 4.2, 4.9, 3.8, 4.5],
                        backgroundColor: "rgba(255, 193, 7, 0.2)",
                        borderColor: "rgba(255, 193, 7, 1)",
                        borderWidth: 1
                    }]
                };

                // Service Type Distribution - Pie Chart
                const serviceTypeData = this.serviceTypeData || {
                    labels: ["Plumbing", "Electrical", "Carpentry", "Cleaning", "Others"],
                    datasets: [{
                        label: "Service Type Distribution",
                        data: [30, 25, 15, 20, 10],
                        backgroundColor: [
                            "rgba(255, 99, 132, 0.6)",
                            "rgba(54, 162, 235, 0.6)",
                            "rgba(255, 206, 86, 0.6)",
                            "rgba(75, 192, 192, 0.6)",
                            "rgba(153, 102, 255, 0.6)"
                        ],
                        borderColor: [
                            "rgba(255, 99, 132, 1)",
                            "rgba(54, 162, 235, 1)",
                            "rgba(255, 206, 86, 1)",
                            "rgba(75, 192, 192, 1)",
                            "rgba(153, 102, 255, 1)"
                        ],
                        borderWidth: 1
                    }]
                };

                // Average Completion Time - Bar Chart
                const completionTimeData = this.completionTimeData || {
                    labels: ["Plumbing", "Electrical", "Carpentry", "Cleaning", "Others"],
                    datasets: [{
                        label: "Average Completion Time (hours)",
                        data: [3.5, 2.8, 5.2, 4.0, 3.2],
                        backgroundColor: "rgba(75, 192, 192, 0.2)",
                        borderColor: "rgba(75, 192, 192, 1)",
                        borderWidth: 1
                    }]
                };

                // Customer Satisfaction over Time - Line Chart (NEW)
                const customerSatisfactionData = {
                    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                    datasets: [{
                        label: "Customer Satisfaction (%)",
                        data: [92, 88, 91, 94, 89, 95],
                        backgroundColor: "rgba(153, 102, 255, 0.2)",
                        borderColor: "rgba(153, 102, 255, 1)",
                        borderWidth: 1,
                        fill: true
                    }]
                };

                // Monthly Revenue - Bar Chart (NEW)
                const revenueData = {
                    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                    datasets: [{
                        label: "Monthly Revenue ($)",
                        data: [25000, 32000, 28500, 37000, 42000, 35000],
                        backgroundColor: "rgba(255, 99, 132, 0.2)",
                        borderColor: "rgba(255, 99, 132, 1)",
                        borderWidth: 1
                    }]
                };

                // Create requests chart
                new Chart(requestsCanvas, {
                    type: 'line',
                    data: requestsData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false
                    }
                });

                // Create ratings chart
                new Chart(ratingsCanvas, {
                    type: 'bar',
                    data: ratingsData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 5
                            }
                        }
                    }
                });

                // Create service type distribution chart
                new Chart(serviceTypeCanvas, {
                    type: 'pie',
                    data: serviceTypeData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'right'
                            }
                        }
                    }
                });

                // Create completion time chart
                new Chart(completionTimeCanvas, {
                    type: 'bar',
                    data: completionTimeData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Average Hours'
                                }
                            }
                        }
                    }
                });

                // Create customer satisfaction chart (NEW)
                new Chart(customerSatisfactionCanvas, {
                    type: 'line',
                    data: customerSatisfactionData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: false,
                                min: 80,
                                max: 100,
                                title: {
                                    display: true,
                                    text: 'Satisfaction %'
                                }
                            }
                        }
                    }
                });

                // Create revenue chart (NEW)
                new Chart(revenueCanvas, {
                    type: 'bar',
                    data: revenueData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Revenue ($)'
                                }
                            }
                        }
                    }
                });

                console.log("Charts created successfully");
            } catch (err) {
                console.error("Error creating charts:", err);
                this.error = "Failed to render charts: " + err.message;
            }
        }
    },
    template: `
      <div class="container mt-4">
          <h2 class="mb-4">Service Insights Dashboard</h2>
          <div v-if="error" class="alert alert-danger">{{ error }}</div>
          <div v-if="loading" class="text-center">
              <div class="spinner-border text-primary" role="status">
                  <span class="visually-hidden">Loading...</span>
              </div>
          </div>
          <div class="row">
              <div class="col-md-6 mb-4">
                  <div class="card">
                      <div class="card-header bg-primary text-white">
                          <h5 class="mb-0">Service Requests Over Time</h5>
                      </div>
                      <div class="card-body" style="height: 300px;">
                          <canvas id="requestsChart"></canvas>
                      </div>
                  </div>
              </div>
              <div class="col-md-6 mb-4">
                  <div class="card">
                      <div class="card-header bg-warning text-dark">
                          <h5 class="mb-0">Average Rating per Professional</h5>
                      </div>
                      <div class="card-body" style="height: 300px;">
                          <canvas id="ratingsChart"></canvas>
                      </div>
                  </div>
              </div>
              <div class="col-md-6 mb-4">
                  <div class="card">
                      <div class="card-header bg-success text-white">
                          <h5 class="mb-0">Service Type Distribution</h5>
                      </div>
                      <div class="card-body" style="height: 300px;">
                          <canvas id="serviceTypeChart"></canvas>
                      </div>
                  </div>
              </div>
              <div class="col-md-6 mb-4">
                  <div class="card">
                      <div class="card-header bg-info text-white">
                          <h5 class="mb-0">Average Completion Time by Service Type</h5>
                      </div>
                      <div class="card-body" style="height: 300px;">
                          <canvas id="completionTimeChart"></canvas>
                      </div>
                  </div>
              </div>
              <div class="col-md-6 mb-4">
                  <div class="card">
                      <div class="card-header bg-purple text-white" style="background-color: #6f42c1;">
                          <h5 class="mb-0">Customer Satisfaction Trends</h5>
                      </div>
                      <div class="card-body" style="height: 300px;">
                          <canvas id="customerSatisfactionChart"></canvas>
                      </div>
                  </div>
              </div>
              <div class="col-md-6 mb-4">
                  <div class="card">
                      <div class="card-header bg-danger text-white">
                          <h5 class="mb-0">Monthly Revenue</h5>
                      </div>
                      <div class="card-body" style="height: 300px;">
                          <canvas id="revenueChart"></canvas>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  `
};