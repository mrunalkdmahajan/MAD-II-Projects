export default {
    name: 'FindProfessionals',
    data() {
        return {
            professionals: [],
            customers: [],
            hasSearched: false,
            isFetching: false,
            filters: {
                username: '',
                profileName: '',
                userType: 'all'
            }
        }
    },
    methods: {
        hasAdminRole(user) {
            return user.roles && user.roles.some(role => role.name === 'admin');
        },
        isProfessional(user) {
            return user.roles && user.roles.some(role => role.name === 'professional');
        },
        isCustomer(user) {
            return user.roles && user.roles.some(role => role.name === 'customer');
        },
        // async searchUsers() {
        //     try {
        //         const queryParams = new URLSearchParams();

        //         if (this.filters && this.filters.username) {
        //             queryParams.append('username', this.filters.username);
        //         }
        //         if (this.filters && this.filters.profileName) {
        //             queryParams.append('profile_name', this.filters.profileName);
        //         }
        //         if (this.filters && this.filters.userType && this.filters.userType !== 'all') {
        //             queryParams.append('user_type', this.filters.userType);
        //         }

        //         const url = queryParams.toString() ? `/api/users/search?${queryParams}` : '/api/users/search';

        //         // Set a timeout for fetch
        //         const controller = new AbortController();
        //         const timeoutId = setTimeout(() => controller.abort(), 10000);

        //         const response = await fetch(url, {
        //             method: 'GET',
        //             headers: { 'Content-Type': 'application/json' },
        //             signal: controller.signal // Attach abort signal
        //         });

        //         clearTimeout(timeoutId); // Clear timeout if response is received

        //         if (!response.ok) {
        //             throw new Error(`Error: ${response.status} - ${response.statusText}`);
        //         }

        //         const data = await response.json();
        //         this.professionals = data.professionals || [];
        //         this.customers = data.customers || [];
        //         this.hasSearched = true;
        //     } catch (error) {
        //         if (error.name === 'AbortError') {
        //             console.error('Request timed out');
        //         } else {
        //             console.error('Error fetching users:', error.message);
        //         }
        //     }
        // }
        async searchUsers() {
            this.isFetching = true;
            try {
                const queryParams = new URLSearchParams();

                if (this.filters.username) queryParams.append('username', this.filters.username);
                if (this.filters.profileName) queryParams.append('profile_name', this.filters.profileName);
                if (this.filters.userType && this.filters.userType !== 'all') queryParams.append('user_type', this.filters.userType);

                const url = queryParams.toString() ? `/api/users/search?${queryParams}` : '/api/users/search';

                const response = await fetch(url, {
                    method: 'GET',
                    headers: { 'Content-Type': 'application/json' }
                });

                if (!response.ok) throw new Error(`Error: ${response.status} - ${response.statusText}`);

                const data = await response.json();
                this.professionals = data.professionals || [];
                this.customers = data.customers || [];
                this.hasSearched = true;
            } catch (error) {
                console.error('Error fetching users:', error.message);
            } finally {
                this.isFetching = false;
            }
        }




    },
    template: `
        <div class="container mt-4">
            <div class="card mb-4">
                <div class="card-body bg-light">
                    <div class="row">
                        <div class="col-md-4 mb-2">
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Search by username"
                                v-model="filters.username"
                            />
                        </div>
                        <div class="col-md-4 mb-2">
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Search by profile name"
                                v-model="filters.profileName"
                            />
                        </div>
                        <div class="col-md-4 mb-2">
                            <select
                                class="form-control"
                                v-model="filters.userType"
                            >
                                <option value="all">All Users</option>
                                <option value="professional">Professionals Only</option>
                                <option value="customer">Customers Only</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col">
                            <button @click="searchUsers" class="btn btn-primary">
                                Search Users
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div v-if="hasSearched">
                <div v-if="filters.userType === 'all' || filters.userType === 'professional'"
                     class="mb-4">
                    <h3 class="display-6 mb-3">Professional Profiles</h3>
                    <div v-if="professionals.length === 0" class="alert alert-info">
                        No professional profiles found matching your search criteria.
                    </div>
                    <div v-else class="row">
                        <div v-for="prof in professionals.filter(p => isProfessional(p))" 
                             :key="prof.id" 
                             class="col-md-4 mb-3">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h5 class="card-title">{{ prof.profile.name }}</h5>
                                        <span v-if="hasAdminRole(prof)" class="badge bg-danger">Admin</span>
                                    </div>
                                    <h6 class="card-subtitle mb-2 text-muted">{{ prof.username }}</h6>
                                    <div class="card-text">
                                        <p class="mb-1"><strong>Service:</strong> {{ prof.profile.service_type }}</p>
                                        <p class="mb-1"><strong>Experience:</strong> {{ prof.profile.experience }} years</p>
                                        <p class="mb-1"><strong>Description:</strong> {{ prof.profile.description }}</p>
                                    </div>
                                    <div class="mt-3 d-flex gap-2">
                                        <router-link 
                                            :to="{ name: 'ProfessionalProfileView', params: { id: prof.id }}"
                                            class="btn btn-outline-primary"
                                        >
                                            View Profile
                                        </router-link>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div v-if="filters.userType === 'all' || filters.userType === 'customer'">
                    <h3 class="display-6 mb-3">Customer Profiles</h3>
                    <div v-if="customers.length === 0" class="alert alert-info">
                        No customer profiles found matching your search criteria.
                    </div>
                    <div v-else class="row">
                        <div v-for="customer in customers.filter(c => isCustomer(c))" 
                             :key="customer.id" 
                             class="col-md-4 mb-3">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h5 class="card-title">{{ customer.username }}</h5>
                                        <span v-if="hasAdminRole(customer)" class="badge bg-danger">Admin</span>
                                    </div>
                                    <div class="card-text">
                                        <p class="mb-1"><strong>Email:</strong> {{ customer.email }}</p>
                                        <p class="mb-1"><strong>Services Requested:</strong> {{ customer.services_requested }}</p>
                                    </div>
                                    <div class="mt-3">
                                        <router-link 
                                            :to="{ name: 'AdminViewCustomerProfile', params: { id: customer.id } }"
                                            class="btn btn-outline-primary"
                                        >
                                            View Profile
                                        </router-link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `
};