export default {
    data() {
        return {
            admin: {
                id: null,
                username: '',
                email: '',
                active: false,
                is_blocked: false,
                is_admin: false
            },
            loading: true,
            error: null
        };
    },
    async created() {
        try {
            const token = localStorage.getItem("auth-token");
            if (!token) {
                this.error = "Authentication required";
                this.loading = false;
                return;
            }

            const response = await fetch('/api/admin/profile', {
                headers: {
                    "Authentication-Token": token // Changed to match Flask-Security expectations
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            this.admin = await response.json();
            this.loading = false;
        } catch (error) {
            console.error('Error fetching admin profile:', error);
            this.error = error.message;
            this.loading = false;
        }
    },
    methods: {
        showShortcutGuide() {
            alert("To add this website to your desktop:\n\n📌 On Chrome: Click the three dots (⋮) > More tools > Create Shortcut.\n📌 On Edge: Click the three dots (⋮) > Apps > Install.");
        },
        navigateToEditProfile() {
            this.$router.push('/edit/admin/profile');
        }
    },
    template: `
  <div class="container mt-4">
    <button @click="showShortcutGuide" class="btn btn-secondary">Add to Desktop</button>
    <h3 class="text-center mb-3">Admin Profile</h3>
    <div v-if="loading" class="text-center">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
    <div v-else-if="error" class="alert alert-danger" role="alert">
      {{ error }}
    </div>
    <div v-else class="card mx-auto" style="max-width: 400px;">
      <div class="card-body">
        <h5 class="card-title text-center">{{ admin.username }}</h5>
        <p class="card-text"><strong>ID:</strong> {{ admin.id }}</p>
        <p class="card-text"><strong>Email:</strong> {{ admin.email }}</p>
        <p class="card-text">
          <strong>Active:</strong> 
          <span :class="{'text-success': admin.active, 'text-danger': !admin.active}">
            {{ admin.active ? 'Yes' : 'No' }}
          </span>
        </p>
        <p class="card-text">
          <strong>Blocked:</strong> 
          <span :class="{'text-success': !admin.is_blocked, 'text-danger': admin.is_blocked}">
            {{ admin.is_blocked ? 'Yes' : 'No' }}
          </span>
        </p>
        <p class="card-text">
          <strong>Admin:</strong> 
          <span :class="{'text-success': admin.is_admin, 'text-danger': !admin.is_admin}">
            {{ admin.is_admin ? 'Yes' : 'No' }}
          </span>
        </p>
        <button 
          @click="navigateToEditProfile" 
          class="btn btn-primary w-100 mt-3"
        >
          Edit Profile
        </button>
      </div>
    </div>
  </div>
`
};