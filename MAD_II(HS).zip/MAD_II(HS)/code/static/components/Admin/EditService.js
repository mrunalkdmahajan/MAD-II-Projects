export default {
    name: "EditService",
    data() {
        return {
            service: {
                id: null,
                name: "",
                price: null,
                time_required: null,
                description: ""
            },
            loading: true,
            error: null
        };
    },
    created() {
        // Check if service data was passed during navigation
        if (this.$route.params.serviceData) {
            this.service = this.$route.params.serviceData;
            this.loading = false;
        } else {
            // Fallback to fetching service if no data was passed
            this.fetchService();
        }
    },
    methods: {
        async fetchService() {
            try {
                const token = localStorage.getItem("auth-token");
                const serviceId = this.$route.params.id;

                const response = await fetch(`/api/services/${serviceId}`, {
                    method: "GET",
                    headers: {
                        "Authentication-Token": token
                    }
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || "Failed to fetch service");
                }

                this.service = await response.json();
                this.loading = false;
            } catch (error) {
                console.error("Error fetching service:", error);
                this.error = error.message;
                this.loading = false;
            }
        },
        // ... other methods

        async updateService() {
            try {
                const token = localStorage.getItem("auth-token");
                const serviceId = this.$route.params.id;

                const response = await fetch(`/api/services/${serviceId}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token
                    },
                    body: JSON.stringify(this.service)
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || "Failed to update service");
                }

                alert("Service updated successfully!");
                this.$router.push("/admin/all-services");
            } catch (error) {
                console.error("Error updating service:", error);
                alert(error.message);
            }
        }
    },
    template: `
    <div class="container mt-5">
        <h2>Edit Service</h2>
        <div v-if="loading" class="text-center">
            <div class="spinner-border" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
        <div v-else-if="error" class="alert alert-danger">
            {{ error }}
        </div>
        <form v-else @submit.prevent="updateService" class="mt-3">
            <div class="mb-3">
                <label for="name" class="form-label">Service Name</label>
                <input 
                    type="text" 
                    class="form-control" 
                    id="name" 
                    v-model="service.name" 
                    required
                >
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price</label>
                <input 
                    type="number" 
                    class="form-control" 
                    id="price" 
                    v-model.number="service.price" 
                    step="0.01" 
                    required
                >
            </div>
            <div class="mb-3">
                <label for="time" class="form-label">Time Required (Minutes)</label>
                <input 
                    type="number" 
                    class="form-control" 
                    id="time" 
                    v-model.number="service.time_required" 
                    required
                >
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea 
                    class="form-control" 
                    id="description" 
                    v-model="service.description" 
                    required
                ></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update Service</button>
            <button 
                type="button" 
                class="btn btn-secondary ms-2" 
                @click="$router.push('/admin/all-services')"
            >
                Cancel
            </button>
        </form>
    </div>
    `
};