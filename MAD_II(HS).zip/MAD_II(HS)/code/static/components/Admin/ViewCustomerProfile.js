// export default {
//     template: `
//         <div class="container mt-4">
//             <div v-if="customerProfile" class="card">
//                 <div class="card-header">
//                     <h3>Customer Profile Details</h3>
//                 </div>
//                 <div class="card-body">
//                     <div class="row">
//                         <div class="col-md-6">
//                             <h5>Personal Information</h5>
//                             <p><strong>Username:</strong> {{ customerProfile.username }}</p>
//                             <p><strong>Email:</strong> {{ customerProfile.email }}</p>
//                             <p><strong>Account Status:</strong> 
//                                 <span :class="customerProfile.is_active ? 'text-success' : 'text-danger'">
//                                     {{ customerProfile.is_active ? 'Active' : 'Inactive' }}
//                                 </span>
//                             </p>
//                             <p><strong>Blocked Status:</strong> 
//                                 <span :class="customerProfile.is_blocked ? 'text-danger' : 'text-success'">
//                                     {{ customerProfile.is_blocked ? 'Blocked' : 'Not Blocked' }}
//                                 </span>
//                             </p>
//                         </div>
//                         <div class="col-md-6">
//                             <h5>Service Request Summary</h5>
//                             <p><strong>Total Service Requests:</strong> {{ customerProfile.total_service_requests }}</p>
//                         </div>
//                     </div>

//                     <h5 class="mt-4">Service Request History</h5>
//                     <table class="table table-striped" v-if="customerProfile.service_requests.length">
//                         <thead>
//                             <tr>
//                                 <th>Service Name</th>
//                                 <th>Request Date</th>
//                                 <th>Status</th>
//                                 <th>Assigned Professional</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             <tr v-for="request in customerProfile.service_requests" :key="request.id">
//                                 <td>{{ request.service_name }}</td>
//                                 <td>{{ request.date_of_request }}</td>
//                                 <td>{{ request.service_status }}</td>
//                                 <td>{{ request.professional_name }}</td>
//                             </tr>
//                         </tbody>
//                     </table>
//                     <p v-else class="text-muted">No service requests found.</p>
//                 </div>
//                 <div class="card-footer">
//                     <router-link to="/professional/search" class="btn btn-secondary">
//                         Back to Customer List
//                     </router-link>
//                 </div>
//             </div>
//             <div v-else class="text-center">
//                 <p>Loading customer profile...</p>
//             </div>
//         </div>
//     `,
//     data() {
//         return {
//             customerProfile: null
//         };
//     },
//     async created() {
//         const customerId = this.$route.params.id;
//         try {
//             const token = localStorage.getItem("auth-token");
//             // const response = await fetch(`/api/admin/customer/${customerId}/profile`);
//             const response = await fetch(`/api/admin/customer/${customerId}/profile`, {
//                 headers: {
//                     "Authentication-Token": token,
//                 }
//             });

//             console.log(customerId);
//             console.log("Hiii");

//             if (!response.ok) {
//                 throw new Error('Failed to fetch customer profile');
//             }
//             this.customerProfile = await response.json();
//         } catch (error) {
//             console.error('Error fetching customer profile:', error);
//         }
//     }
// };

export default {
    template: `
        <div class="container mt-4">
            <div v-if="customerProfile" class="card">
                <div class="card-header">
                    <h3>Customer Profile Details</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Personal Information</h5>
                            <p><strong>Username:</strong> {{ customerProfile.username }}</p>
                            <p><strong>Email:</strong> {{ customerProfile.email }}</p>
                            <p><strong>Account Status:</strong> 
                                <span :class="customerProfile.is_active ? 'text-success' : 'text-danger'">
                                    {{ customerProfile.is_active ? 'Active' : 'Inactive' }}
                                </span>
                            </p>
                            <p><strong>Blocked Status:</strong> 
                                <span :class="customerProfile.is_blocked ? 'text-danger' : 'text-success'">
                                    {{ customerProfile.is_blocked ? 'Blocked' : 'Not Blocked' }}
                                </span>
                            </p>
                            <button @click="toggleBlockStatus" class="btn" 
                                :class="customerProfile.is_blocked ? 'btn-success' : 'btn-danger'">
                                {{ customerProfile.is_blocked ? 'Unblock' : 'Block' }} Customer
                            </button>
                        </div>
                        <div class="col-md-6">
                            <h5>Service Request Summary</h5>
                            <p><strong>Total Service Requests:</strong> {{ customerProfile.total_service_requests }}</p>
                        </div>
                    </div>

                    <h5 class="mt-4">Service Request History</h5>
                    <table class="table table-striped" v-if="customerProfile.service_requests.length">
                        <thead>
                            <tr>
                                <th>Service Name</th>
                                <th>Request Date</th>
                                <th>Status</th>
                                <th>Assigned Professional</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="request in customerProfile.service_requests" :key="request.id">
                                <td>{{ request.service_name }}</td>
                                <td>{{ request.date_of_request }}</td>
                                <td>{{ request.service_status }}</td>
                                <td>{{ request.professional_name }}</td>
                            </tr>
                        </tbody>
                    </table>
                    <p v-else class="text-muted">No service requests found.</p>
                </div>
                <div class="card-footer">
                    <router-link to="/professional/search" class="btn btn-secondary">
                        Back to Customer List
                    </router-link>
                </div>
            </div>
            <div v-else class="text-center">
                <p>Loading customer profile...</p>
            </div>
        </div>
    `,
    data() {
        return {
            customerProfile: null
        };
    },
    async created() {
        await this.fetchCustomerProfile();
    },
    methods: {
        async fetchCustomerProfile() {
            const customerId = this.$route.params.id;
            try {
                const token = localStorage.getItem("auth-token");
                const response = await fetch(`/api/admin/customer/${customerId}/profile`, {
                    headers: {
                        "Authentication-Token": token,
                    }
                });

                if (!response.ok) {
                    throw new Error('Failed to fetch customer profile');
                }
                this.customerProfile = await response.json();
            } catch (error) {
                console.error('Error fetching customer profile:', error);
            }
        },
        async toggleBlockStatus() {
            const customerId = this.$route.params.id;
            try {
                const token = localStorage.getItem("auth-token");
                const response = await fetch(`/api/admin/users/${customerId}/block`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token,
                    },
                    body: JSON.stringify({ block: !this.customerProfile.is_blocked })
                });

                if (!response.ok) {
                    throw new Error('Failed to update block status');
                }

                this.customerProfile.is_blocked = !this.customerProfile.is_blocked;
            } catch (error) {
                console.error('Error updating block status:', error);
            }
        }
    }
};