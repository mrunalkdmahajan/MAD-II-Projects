// export default {
//     name: 'ProfessionalProfileView',
//     data() {
//         return {
//             professionalId: this.$route.params.id || null,

//             professional_profile: {}, // Ensure it's always an object
//             user: {},
//             userId: null,
//             professional: null,
//             reviews: [],
//             loading: true,
//             loadingReviews: true,
//             error: null,
//             currentUser: null,
//             currentUserIsAdmin: false,
//             currentUserIsCustomer: false
//         }
//     },
//     created() {
//         this.fetchCurrentUser();
//         this.fetchProfessionalData();
//         this.fetchReviews();
//     },
//     methods: {
//         async fetchCurrentUser() {
//             try {
//                 const token = localStorage.getItem("auth-token");
//                 const response = await fetch("/api/user/profile", {
//                     headers: {
//                         "Authentication-Token": token,
//                     },
//                     credentials: "include"
//                 });

//                 if (!response.ok) throw new Error("Failed to fetch current user");

//                 const data = await response.json();
//                 console.log("Fetched user data:", data);
//                 console.log(this.$route.params.id)
//                 console.log()

//                 this.currentUser = data;
//                 this.currentUserIsAdmin = this.hasAdminRole(data);
//                 this.currentUserIsCustomer = this.isCustomer(data);
//             } catch (error) {
//                 console.error("Error fetching current user:", error);
//             }
//         },

//         async fetchProfessionalData() {
//             try {
//                 const token = localStorage.getItem("auth-token");
//                 const response = await fetch(`/api/professionals/${this.professionalId}`, {
//                     method: 'GET',
//                     headers: {
//                         'Content-Type': 'application/json',
//                         "Authentication-Token": token,
//                     }
//                 });

//                 if (!response.ok) throw new Error('Failed to fetch professional data');

//                 const data = await response.json();
//                 console.log("Professional Data:", data);

//                 this.professional = data;
//                 this.user = data.user || {};
//                 this.loading = false;
//             } catch (error) {
//                 this.error = 'Failed to load professional profile';
//                 this.loading = false;
//                 console.error('Error fetching professional:', error);
//             }
//         },

//         async fetchReviews() {
//             try {
//                 const token = localStorage.getItem("auth-token");
//                 const professionalId = this.$route.params.id;
//                 const response = await fetch(`/api/professionals/${professionalId}/reviews`, {
//                     method: 'GET',
//                     headers: {
//                         'Content-Type': 'application/json',
//                         "Authentication-Token": token
//                     }
//                 });

//                 if (!response.ok) {
//                     throw new Error('Failed to fetch reviews');
//                 }

//                 this.reviews = await response.json();
//                 this.loadingReviews = false;
//             } catch (error) {
//                 console.error('Error fetching reviews:', error);
//                 this.loadingReviews = false;
//             }
//         },

//         async toggleBlockStatus() {
//             try {
//                 const action = this.professional.is_blocked ? 'unblock' : 'block';
//                 const response = await fetch(`/api/users/${this.professional.id}/${action}`, {
//                     method: 'POST',
//                     headers: {
//                         'Content-Type': 'application/json'
//                     }
//                 });

//                 if (!response.ok) {
//                     throw new Error(`Failed to ${action} user`);
//                 }

//                 // Update the local state
//                 this.professional.is_blocked = !this.professional.is_blocked;

//                 // Show notification
//                 alert(`User has been ${action}ed successfully`);
//             } catch (error) {
//                 console.error(`Error ${this.professional.is_blocked ? 'unblocking' : 'blocking'} user:`, error);
//                 alert('An error occurred. Please try again.');
//             }
//         },

//         hasAdminRole(user) {
//             return user && user.roles && user.roles.some(role => role.name === 'admin');
//         },

//         isProfessional(user) {
//             return user && user.roles && user.roles.some(role => role.name === 'professional');
//         },

//         isCustomer(user) {
//             return user && user.roles && user.roles.some(role => role.name === 'customer');
//         },

//         formatDate(dateString) {
//             const date = new Date(dateString);
//             return date.toLocaleDateString('en-US', {
//                 year: 'numeric',
//                 month: 'short',
//                 day: 'numeric'
//             });
//         }
//     },
//     template: `
//       <div class="container mt-4">
//         <div class="card shadow-sm mb-4">
//           <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
//             <h2 class="mb-0">Professional Profile</h2>
//             <div v-if="currentUserIsAdmin">
//               <button 
//                 @click="toggleBlockStatus" 
//                 class="btn" 
//                 :class="professional.is_blocked ? 'btn-success' : 'btn-danger'">
//                 {{ professional.is_blocked ? 'Unblock User' : 'Block User' }}
//               </button>
//             </div>
//           </div>

//           <div class="card-body">
//             <div v-if="loading" class="text-center py-5">
//               <div class="spinner-border text-primary" role="status">
//                 <span class="visually-hidden">Loading...</span>
//               </div>
//             </div>

//             <div v-else-if="error" class="alert alert-danger">
//               {{ error }}
//             </div>

//             <div v-else>
//               <div class="row">
//                 <div class="col-md-4">
//                   <div class="text-center mb-4">
//                     <div 
//                       class="bg-light rounded-circle mx-auto d-flex justify-content-center align-items-center"
//                       style="width: 150px; height: 150px;">
//                       <i class="bi bi-person-circle" style="font-size: 100px;"></i>
//                     </div>

//                     <div class="mt-3">
//                       <h3 class="mb-0" v-if="professional>{{ professional.profile.name }}</h3>
//                       <h3 class="mb-0" v-else>Loading...</h3>
//                       <p class="text-muted mb-2">@{{ professional.username }}</p>
//                       <span v-if="hasAdminRole(professional)" class="badge bg-danger">Admin</span>
//                       <span v-if="professional.is_blocked" class="badge bg-danger ms-2">Blocked</span>
//                     </div>
//                   </div>
//                 </div>

//                 <div class="col-md-8">
//                   <h4 class="border-bottom pb-2">Profhyjails</h4>

//                   <div class="row mb-3">
//                     <div class="col-md-6">
//                       <p><strong>Service Type:</strong> {{ professional.profile.service_type }}</p>
//                       <p><strong>Experience:</strong> {{ professional.profile.experience }} years</p>
//                       <p><strong>Email:</strong> {{ professional.email }}</p>
//                     </div>
//                     <div class="col-md-6">
//                       <p><strong>Location:</strong> {{ professional.profile.city }}, {{ professional.profile.state }}</p>
//                       <p><strong>Pin Code:</strong> {{ professional.profile.pin_code }}</p>
//                       <p>
//                         <strong>Verified:</strong>
//                         <span :class="professional.profile.is_verified ? 'text-success' : 'text-danger'">
//                           {{ professional.profile.is_verified ? 'Yes' : 'No' }}
//                         </span>
//                       </p>
//                     </div>
//                   </div>

//                   <div class="mb-4">
//                     <h5>Description</h5>
//                     <p>{{ professional.profile.description }}</p>
//                   </div>

//                   <div v-if="currentUserIsAdmin || currentUserIsCustomer" class="mt-4">
//                     <router-link 
//                       :to="{ name: 'RequestService', params: { professionalId: professional.id }}" 
//                       class="btn btn-primary">
//                       Request Service
//                     </router-link>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>

//         <!-- Reviews Section -->
//         <div class="card shadow-sm">
//           <div class="card-header bg-light">
//             <h3 class="mb-0">Reviews</h3>
//           </div>
//           <div class="card-body">
//             <div v-if="loadingReviews" class="text-center py-3">
//               <div class="spinner-border text-primary" role="status">
//                 <span class="visually-hidden">Loading reviews...</span>
//               </div>
//             </div>

//             <div v-else-if="reviews.length === 0" class="alert alert-info">
//               No reviews yet for this professional.
//             </div>

//             <div v-else>
//               <div 
//                 v-for="review in reviews" 
//                 :key="review.id" 
//                 class="mb-4 border-bottom pb-3">
//                 <div class="d-flex justify-content-between align-items-start">
//                   <div>
//                     <h5 class="mb-1">{{ review.customer_username }}</h5>
//                     <div class="mb-2">
//                       <span class="text-warning" v-for="n in 5" :key="n">
//                         <i class="bi" :class="n <= review.rating ? 'bi-star-fill' : 'bi-star'"></i>
//                       </span>
//                       <span class="ms-2 text-muted">{{ formatDate(review.created_at) }}</span>
//                     </div>
//                     <p class="mb-1">{{ review.comments }}</p>
//                     <div class="text-muted small">
//                       Service: {{ review.service_name }}
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     `
//
// //////////////////////////////////////////////////////////////////////////

// export default {
//     name: "ProfessionalProfileView",
//     data() {
//         return {
//             professional: null,
//             reviews: [],
//             loading: true,
//             error: null,
//         };
//     },
//     methods: {
//         async fetchProfessionalData() {
//             try {
//                 // const token = localStorage.getItem("auth-token");

//                 // const response = await fetch(`/api/professionals/${this.professionalId}`, {
//                 //     method: 'GET',
//                 //     headers: {
//                 //         'Content-Type': 'application/json',
//                 //         "Authentication-Token": token,
//                 //     }
//                 // });

//                 const token = localStorage.getItem("auth-token");
//                 const professionalId = this.$route.params.id;
//                 console.log(professionalId)
//                 const response = await fetch(`/api/professionals/${professionalId}`, {
//                     method: 'GET',
//                     headers: {
//                         'Content-Type': 'application/json',
//                         "Authentication-Token": token,
//                     }
//                 });

//                 const text = await response.text(); // Get raw response
//                 console.log("Raw Response:", text); // Log it for debugging

//                 const data = JSON.parse(text); // Parse JSON manually
//                 console.log("Professional Data:", data);

//                 this.professional = data.professional;
//                 this.reviews = data.reviews;
//                 this.user = data.user || {};
//                 this.loading = false;
//             } catch (error) {
//                 this.error = 'Failed to load professional profile';
//                 this.loading = false;
//                 console.error('Error fetching professional:', error);
//             }
//         },
//     },
//     created() {
//         this.fetchProfessionalData();
//     },
//     template: `
//     <div class="container mt-4">
//       <div v-if="loading" class="text-center">
//         <p>Loading...</p>
//       </div>
//       <div v-else-if="error" class="alert alert-danger">
//         <p>{{ error }}</p>
//       </div>
//       <div v-else>
//         <div class="card">
//           <div class="card-body">
//             <h2 class="card-title">{{ professional.name }}</h2>
//             <p><strong>City:</strong> {{ professional.city }}</p>
//             <p><strong>State:</strong> {{ professional.state }}</p>
//             <p><strong>Experience:</strong> {{ professional.experience }} years</p>
//             <p><strong>Service Type:</strong> {{ professional.service_type }}</p>
//             <p><strong>Description:</strong> {{ professional.description }}</p>
//           </div>
//         </div>
//         <div class="mt-4">
//           <h3>Reviews</h3>
//           <div v-if="reviews.length === 0">
//             <p>No reviews yet.</p>
//           </div>
//           <div v-else>
//             <div v-for="review in reviews" :key="review.id" class="card mb-2">
//               <div class="card-body">
//                 <h5 class="card-title">Rating: {{ review.rating }}/5</h5>
//                 <p class="card-text">{{ review.comments }}</p>
//                 <small class="text-muted">Reviewed on {{ new Date(review.created_at).toLocaleDateString() }}</small>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   `,
// };


export default {
    name: "ProfessionalProfileView",
    data() {
        return {
            professional: null,
            reviews: [],
            loading: true,
            error: null,
            is_blocked: false,
            professionalProfile: null
        };
    },
    methods: {
        async toggleBlockStatus() {
            try {
                const action = this.professional.is_blocked ? 'unblock' : 'block';

                const token = localStorage.getItem("auth-token");
                console.log(this.professional.id)
                console.log(token)
                const response = await fetch(`/api/users/${this.professional.id}/${action}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        "Authentication-Token": token
                    }
                });

                if (!response.ok) {
                    throw new Error(`Failed to ${action} user`);
                }


                // Update the local state
                this.professional.is_blocked = !this.professional.is_blocked;

                // Show notification
                alert(`User has been ${action}ed successfully`);
            } catch (error) {
                console.error(`Error ${this.professional.is_blocked ? 'unblocking' : 'blocking'} user:`, error);
                alert('An error occurred. Please try again.');
            }
        },

        async fetchReviews() {
            try {
                const token = localStorage.getItem("auth-token");
                const professionalId = this.$route.params.id;
                console.log(professionalId)
                const response = await fetch(`/api/professionals/${professionalId}/reviews`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        "Authentication-Token": token
                    }
                });

                if (!response.ok) {
                    throw new Error('Failed to fetch reviews');
                }

                this.reviews = await response.json();
                this.loadingReviews = false;
            } catch (error) {
                console.error('Error fetching reviews:', error);
                this.loadingReviews = false;
            }
        },
        async fetchProfessionalData() {
            try {
                // const token = localStorage.getItem("auth-token");

                // const response = await fetch(`/api/professionals/${this.professionalId}`, {
                //     method: 'GET',
                //     headers: {
                //         'Content-Type': 'application/json',
                //         "Authentication-Token": token,
                //     }
                // });

                const token = localStorage.getItem("auth-token");
                const professionalId = this.$route.params.id;
                console.log(professionalId)
                const response = await fetch(`/api/professionals/${professionalId}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        "Authentication-Token": token,
                    }
                });

                const text = await response.text(); // Get raw response
                console.log("Raw Response:", text); // Log it for debugging

                const data = JSON.parse(text); // Parse JSON manually
                console.log("Professional Data:", data);

                // this.professional = data.professional;
                this.professional = {
                    ...data.professional,
                    is_blocked: (data.professional && data.professional.is_blocked) || false,
                };


                this.reviews = data.reviews;
                this.user = data.user || {};
                this.loading = false;
            } catch (error) {
                this.error = 'Failed to load professional profile';
                this.loading = false;
                console.error('Error fetching professional:', error);
            }
        },
        hasAdminRole(user) {
            return user && user.roles && user.roles.some(role => role.name === 'admin');
        },
    },
    created() {
        this.fetchProfessionalData();
        this.fetchReviews();
    },
    template: `
  <div class="container mt-4">
    <div class="card shadow-sm mb-4">
          <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h2 class="mb-0">Professional Profile</h2>
            <div >
              <button 
                @click="toggleBlockStatus" 
                class="btn" 
                :class="professional.is_blocked ? 'btn-success' : 'btn-danger'">
                    {{ professional.is_blocked ? 'Unblock User' : 'Block User' }}
                 
              </button>
            </div>
          </div>
    <div v-if="loading" class="text-center">
      <p>Loading...</p>
    </div>
    <div v-else-if="error" class="alert alert-danger">
      <p>{{ error }}</p>
    </div>
    <div v-else>
      <div class="card">
        <div class="card-body">
          <h2 class="card-title">{{ professional.name }}</h2>
          <p><strong>City:</strong> {{ professional.city }}</p>
          <p><strong>State:</strong> {{ professional.state }}</p>
          <p><strong>Experience:</strong> {{ professional.experience }} years</p>
          <p><strong>Service Type:</strong> {{ professional.service_type }}</p>
          <p><strong>Description:</strong> {{ professional.description }}</p>
        </div>
        
      </div>
      <div class="mt-4">
        <h3>Reviews</h3>
        <div v-if="reviews.length === 0">
          <p>No reviews yet.</p>
        </div>
        <div v-else>
          <div v-for="review in reviews" :key="review.id" class="card mb-2">
            <div class="card-body">
              <h5 class="card-title">Rating: {{ review.rating }}/5</h5>
              <p class="card-text">{{ review.comments }}</p>
              <small class="text-muted">Reviewed on {{ new Date(review.created_at).toLocaleDateString() }}</small>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
`,
};