export default {
    name: "CreateService",
    template: `
  <div class="container mt-5">
    <h2>Create New Service</h2>
    <form @submit.prevent="submitForm" class="form">
      <div class="form-group">
        <label for="name" class="form-label">Service Name</label>
        <input 
          type="text" 
          id="name" 
          v-model="service.name" 
          class="form-control" 
          placeholder="Enter service name" 
          required 
        />
      </div>
      <div class="form-group">
        <label for="price" class="form-label">Service Price</label>
        <input 
          type="number" 
          id="price" 
          v-model="service.price" 
          class="form-control" 
          placeholder="Enter service price" 
          required 
        />
      </div>
      <div class="form-group">
        <label for="time_required" class="form-label">Time Required (Minutes)</label>
        <input 
          type="number" 
          id="time_required" 
          v-model="service.time_required" 
          class="form-control" 
          placeholder="Enter time required" 
          required 
        />
      </div>
      <div class="form-group">
        <label for="description" class="form-label">Description</label>
        <textarea 
          id="description" 
          v-model="service.description" 
          class="form-control" 
          placeholder="Enter service description" 
          required
        ></textarea>
      </div>
      <div class="form-group">
        <label for="Actions" class="form-label">Actions</label>
        <textarea 
          id="action" 
          v-model="service.description" 
          class="form-control" 
          placeholder="Enter service description" 
          required
        ></textarea>
      </div>
      <div class="form-group mt-3">
        <button type="submit" class="btn btn-primary">Create Service</button>
      </div>
    </form>
  </div>
`,
    data() {
        return {
            service: {
                name: "",
                price: null,
                time_required: null,
                description: "",
            },
        };
    },
    methods: {
        async submitForm() {
            try {
                const token = localStorage.getItem("auth-token");
                console.log("Auth token:", token);

                if (!token) {
                    alert("You are not authenticated. Please login.");
                    this.$router.push({ name: "Login" });
                    return;
                }

                const response = await fetch("/api/services", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": token // Changed from Authorization: Bearer
                    },
                    body: JSON.stringify(this.service),
                });

                if (response.status === 401) {
                    alert("Session expired. Please login again.");
                    localStorage.removeItem("auth-token");
                    this.$router.push({ name: "Login" });
                    return;
                }

                const data = await response.json();
                if (response.ok) {
                    alert("Service created successfully!");
                    this.$router.push("/admin/all-services");
                } else {
                    alert(data.error || "Failed to create service");
                }
            } catch (error) {
                console.error("Error creating service:", error);
                alert("An error occurred while creating the service.");
            }
        }
    },
};