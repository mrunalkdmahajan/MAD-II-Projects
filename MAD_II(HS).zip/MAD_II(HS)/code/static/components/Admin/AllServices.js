// export default {
//     name: "AllServices",
//     template: `
//     <div class="container mt-5">
//       <div class="d-flex justify-content-between align-items-center">
//         <h2>All Services</h2>
//         <button 
//           class="btn btn-primary"
//           @click="$router.push({ name: 'CreateService' })"
//         >
//           Create New Service
//         </button>
//       </div>
//       <div v-if="loading" class="text-center mt-3">
//         <div class="spinner-border" role="status">
//           <span class="visually-hidden">Loading...</span>
//         </div>
//       </div>
//       <div v-else-if="error" class="alert alert-danger mt-3">
//         {{ error }}
//       </div>
//       <table v-else class="table table-bordered mt-3">
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Name</th>
//             <th>Price</th>
//             <th>Time Required</th>
//             <th>Description</th>

//           </tr>
//         </thead>
//         <tbody>
//           <tr v-for="service in services" :key="service.id">
//             <td>{{ service.id }}</td>
//             <td>{{ service.name }}</td>
//             <td>{{ service.price }}</td>
//             <td>{{ service.time_required }} mins</td>
//             <td>{{ service.description }}</td>
//           </tr>
//         </tbody>
//       </table>
//     </div>
//   `,
//     data() {
//         return {
//             services: [],
//             loading: true,
//             error: null
//         };
//     },
//     async created() {
//         try {
//             const token = localStorage.getItem("auth-token");
//             console.log("Auth token:", token);

//             if (!token) {
//                 this.error = "Authentication required";
//                 this.loading = false;
//                 return;
//             }

//             const response = await fetch("/api/services", {
//                 method: "GET",
//                 headers: {
//                     "Authentication-Token": token
//                 }
//             });

//             const text = await response.text();
//             console.log("Response:", text);

//             if (!response.ok) {
//                 throw new Error(text);
//             }

//             this.services = JSON.parse(text);
//         } catch (error) {
//             console.error("Error fetching services:", error);
//             this.error = error.message;
//         } finally {
//             this.loading = false;
//         }
//     }
// };


export default {
    name: "AllServices",
    template: `
  <div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center">
      <h2>All Services</h2>
      <button 
        class="btn btn-primary"
        @click="$router.push({ name: 'CreateService' })"
      >
        Create New Service
      </button>
    </div>
    <div v-if="loading" class="text-center mt-3">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
    <div v-else-if="error" class="alert alert-danger mt-3">
      {{ error }}
    </div>
    <table v-else class="table table-bordered mt-3">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Price</th>
          <th>Time Required</th>
          <th>Description</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="service in services" :key="service.id">
          <td>{{ service.id }}</td>
          <td>{{ service.name }}</td>
          <td>{{ service.price }}</td>
          <td>{{ service.time_required }} mins</td>
          <td>{{ service.description }}</td>
          <td>
                  <button 
                      class="btn btn-primary"
                      @click="editService(service.id)"
                  >
                      Edit
                  </button>
                  <button class="btn btn-danger" @click="deleteService(service.id)">Delete</button>
                  
          </td>
        </tr>
      </tbody>
    </table>
  </div>
`,
    data() {
        return {
            services: [],
            loading: true,
            error: null
        };
    },
    async created() {
        try {
            const token = localStorage.getItem("auth-token");
            console.log("Auth token:", token);

            if (!token) {
                this.error = "Authentication required";
                this.loading = false;
                return;
            }

            const response = await fetch("/api/services", {
                method: "GET",
                headers: {
                    "Authentication-Token": token
                }
            });

            const text = await response.text();
            console.log("Response:", text);

            if (!response.ok) {
                throw new Error(text);
            }

            this.services = JSON.parse(text);
        } catch (error) {
            console.error("Error fetching services:", error);
            this.error = error.message;
        } finally {
            this.loading = false;
        }
    },
    methods: {
        async editService(serviceId) {
            try {
                const token = localStorage.getItem("auth-token");

                // Fetch service details before navigating
                const response = await fetch(`/api/services/${serviceId}`, {
                    method: 'GET',
                    headers: {
                        'Authentication-Token': token
                    }
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || 'Failed to fetch service details');
                }

                const serviceData = await response.json();

                // Navigate to edit page with service data
                this.$router.push({
                    name: 'EditService',
                    params: {
                        id: serviceId,
                        serviceData: serviceData
                    }
                });
            } catch (error) {
                console.error('Error fetching service:', error);
                alert(error.message);
            }
        },
        // ... other methods
        async deleteService(serviceId) {
            try {
                const token = localStorage.getItem("auth-token");

                const response = await fetch(`/api/services/${serviceId}`, {
                    method: "DELETE",
                    headers: {
                        "Authentication-Token": token
                    }
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || "Failed to delete service");
                }

                // Remove service from UI after deletion
                this.services = this.services.filter(service => service.id !== serviceId);
                alert("Service deleted successfully");
            } catch (error) {
                console.error("Error deleting service:", error);
                alert(error.message);
            }
        }

    }
};