export default {
    template: `
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
      <div class="container-fluid">
          <a class="navbar-brand" href="#">Live Session</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
              <ul class="navbar-nav">
                  <li class="nav-item">
                      <router-link class="nav-link active" aria-current="page" to="/">Home</router-link>
                  </li>
                  
                  <!-- Admin Pages -->
                  <li class="nav-item" v-if="role === 'admin'">
                      <router-link class="nav-link" to="/admin/all-services">Service</router-link>
                  </li>
                  <li class="nav-item" v-if="role === 'admin'">
                      <router-link class="nav-link" to="/admin/charts">Statistics</router-link>
                  </li>
                  <li class="nav-item" v-if="role === 'admin'">          
                      <router-link class="nav-link" to="/professional/search">Find</router-link>
                  </li>
                  <li class="nav-item" v-if="role === 'admin'">
                      <router-link class="nav-link" to="/admin/profile">Profile</router-link> 
                  </li>

                  <!-- Customer Pages -->
                  <li class="nav-item" v-if="role === 'customer'">
                      <router-link class="nav-link" to="/customer/profile">Profile</router-link> 
                  </li>
                  <li class="nav-item" v-if="role === 'customer'">
                      <router-link class="nav-link" to="/customer/find">Services</router-link> 
                  </li>
                  <li class="nav-item" v-if="role === 'customer'">
                      <router-link class="nav-link" to="/customer/request-service">Find</router-link>
                  </li>

                  <!-- Professional Pages -->
                  <li class="nav-item" v-if="role === 'professional'">
                      <router-link class="nav-link" to="/professional/profile">Profile</router-link> 
                  </li>
                  <li class="nav-item" v-if="role === 'professional'">
                      <router-link class="nav-link" to="/professional/requests">Requests</router-link> 
                  </li>

                  <!-- Logout -->
                  <li class="nav-item" v-if="isLoggedIn">
                      <button class="nav-link" @click='logout'>Logout</button>
                  </li>
              </ul>
          </div>
      </div>
  </nav>`,

    data() {
        return {
            role: localStorage.getItem('role') || '',
            userId: localStorage.getItem('user-id') || '',
            isLoggedIn: !!localStorage.getItem('auth-token')
        }
    },
    methods: {
        logout() {
            localStorage.removeItem('auth-token');
            localStorage.removeItem('role');
            localStorage.removeItem('user-id');
            this.$router.push({ path: '/login' });
        }
    },
    created() {
        if (!this.isLoggedIn) {
            this.$router.push({ path: '/login' });
        }
    }
};
// export default {
//     template: `
//   <nav class="navbar navbar-expand-lg bg-body-tertiary">
//       <div class="container-fluid">
//           <a class="navbar-brand" href="#">Live Session</a>
//           <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
//               <span class="navbar-toggler-icon"></span>
//           </button>
//           <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
//               <ul class="navbar-nav">
//                   <li class="nav-item">
//                       <router-link class="nav-link active" aria-current="page" to="/">Home</router-link>
//                   </li>
//                   <li class="nav-item" v-if="role=='admin'">
//                       <router-link class="nav-link" to="/services">Service</router-link>
//                   </li>
//                   <li class="nav-item" v-if="role=='admin'">          
//                       <router-link class="nav-link" to="/professionals/search">Find</router-link>
//                   </li>
//                   <li class="nav-item" v-if="role=='admin'">
//                       <router-link class="nav-link" to="/admin/profile">Profile</router-link> 
//                   </li>
//                   <li class="nav-item" v-if="role=='customer'">
//                       <router-link class="nav-link" to="/customer/profilev
// 
// ">Profile</router-link> 
//                   </li>
//                   <li class="nav-item" v-if="role=='customer'">
//                       <router-link class="nav-link" to="/customer/find">Find</router-link>
//                   </li>
//                   <li class="nav-item" v-if="role=='professional'">
//                       <router-link class="nav-link" to="/professional/profile">Profile</router-link>
//                   </li>
//                   <li class="nav-item" v-if="role=='professional'">
//                       <router-link class="nav-link" to="/professional/requests">Requests</router-link>
//                   </li>
//                   <li class="nav-item" v-if="isLoggedIn">
//                       <button class="nav-link" @click='logout'>Logout</button>
//                   </li>
//               </ul>
//           </div>
//       </div>
//   </nav>`,
//     data() {
//         return {
//             role: localStorage.getItem('role') || '',
//             isLoggedIn: !!localStorage.getItem('auth-token')
//         }
//     },
//     methods: {
//         logout() {
//             localStorage.removeItem('auth-token');
//             localStorage.removeItem('role');
//             this.$router.push({ path: '/login' });
//         }
//     },
//     created() {
//         if (!this.isLoggedIn) {
//             this.$router.push({ path: '/login' });
//         }
//     }
// }

// 
// export default {
//     template: `
//   <nav class="navbar navbar-expand-lg bg-body-tertiary">
//       <div class="container-fluid">
//           <a class="navbar-brand" href="#">Live Session</a>
//           <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
//               <span class="navbar-toggler-icon"></span>
//           </button>
//           <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
//               <ul class="navbar-nav">
//                   <li class="nav-item">
//                       <router-link class="nav-link active" aria-current="page" to="/">Home</router-link>
//                   </li>
//                   <li class="nav-item" v-if="role=='admin'">
//                       <router-link class="nav-link" to="/services">Service</router-link>
//                   </li>
//                   <li class="nav-item" v-if="role=='admin'">          
//                       <router-link class="nav-link" to="/professionals/search">Find</router-link>
//                   </li>
//                   <li class="nav-item" v-if="role=='admin'">
//                       <router-link class="nav-link" to="/admin/profile">Profile</router-link> 
//                   </li>
//                   <li class="nav-item" v-if="role=='stud'">
//                       <router-link class="nav-link" to="/create-resource">Create Resource</router-link>
//                   </li>
//                   <li class="nav-item" v-if="role=='customer'">
//                       <router-link class="nav-link" to="/user/profile">Profile</router-link> 
//                   </li>
//                   <li class="nav-item" v-if="isLoggedIn">
//                       <button class="nav-link" @click='logout'>Logout</button>
//                   </li>
//               </ul>
//           </div>
//       </div>
//   </nav>`,
//     data() {
//         return {
//             role: localStorage.getItem('role') || '',
//             userId: localStorage.getItem('user-id') || '',
//             isLoggedIn: !!localStorage.getItem('auth-token')
//         }
//     },
//     methods: {
//         logout() {
//             localStorage.removeItem('auth-token');
//             localStorage.removeItem('role');
//             localStorage.removeItem('user-id');
//             this.$router.push({ path: '/login' });
//         }
//     },
//     created() {
//         // Check authentication status on component creation
//         if (!this.isLoggedIn) {
//             this.$router.push({ path: '/login' });
//         }
//     }
// }