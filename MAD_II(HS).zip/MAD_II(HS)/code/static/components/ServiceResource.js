export default {
    template: `
    <div>
      This is S Resource
    </div>
  `
}