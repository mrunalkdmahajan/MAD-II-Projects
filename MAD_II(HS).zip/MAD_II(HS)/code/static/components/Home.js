import CustomerHome from './Customer/CustomerHome.js';
import AdminHome from './Admin/AdminHome.js';
import ProfessionalHome from './Professional/ProfessionalHome.js';
import ServiceResource from './ServiceResource.js';

export default {
    template: `
    <div>
    This is home
      <CustomerHome v-if="userRole === 'customer'" />
      <AdminHome v-if="userRole === 'admin'" />
      <ProfessionalHome v-if="userRole === 'professional'" />
      <ServiceResource v-for="(resource, index) in resources" :key="index" :resource="resource" />
    </div>
  `,

    data() {
        return {
            userRole: localStorage.getItem('role'), // Retrieves the role from localStorage
            authToken: localStorage.getItem('auth-token'), // Retrieves the auth token from localStorage
            resources: [], // Array to store the service resources
        }
    },

    components: {
        CustomerHome,
        AdminHome,
        ProfessionalHome,
        ServiceResource,
    },

    async mounted() {
        // Fetching service resources from the backend using the stored auth token
        const res = await fetch('/api/service_material', {
            headers: {
                'Authentication-Token': this.authToken, // Pass the auth token in the request header
            },
        });

        const data = await res.json(); // Parse the response as JSON

        if (res.ok) {
            this.resources = data; // If successful, set resources to the data received
        } else {
            alert(data.message); // If there’s an error, show the message
        }
    },
}


// import CustomerHome from './Customer/CustomerHome.js';
// import AdminHome from './Admin/AdminHome.js';
// import ProfessionalHome from './Professional/ProfessionalHome.js';
// import ServiceResource from './ServiceResource.js';

// export default {
//     template: `
//     <div>
//     //   <button @click="installPWA" class="btn btn-success">Add to Desktop</button>
//       <p>This is home</p>
//       <CustomerHome v-if="userRole === 'customer'" />
//       <AdminHome v-if="userRole === 'admin'" />
//       <ProfessionalHome v-if="userRole === 'professional'" />
//       <ServiceResource v-for="(resource, index) in resources" :key="index" :resource="resource" />
//     </div>
//   `,

//     data() {
//         return {
//             userRole: localStorage.getItem('role'), // Retrieves the role from localStorage
//             authToken: localStorage.getItem('auth-token'), // Retrieves the auth token from localStorage
//             resources: [], // Array to store the service resources
//             deferredPrompt: null, // Store PWA install event
//         };
//     },

//     components: {
//         CustomerHome,
//         AdminHome,
//         ProfessionalHome,
//         ServiceResource,
//     },

//     async mounted() {
//         window.addEventListener("beforeinstallprompt", (event) => {
//             event.preventDefault();
//             this.deferredPrompt = event;
//         });

//         // Fetching service resources from the backend using the stored auth token
//         const res = await fetch('/api/service_material', {
//             headers: {
//                 'Authentication-Token': this.authToken, // Pass the auth token in the request header
//             },
//         });

//         const data = await res.json(); // Parse the response as JSON

//         if (res.ok) {
//             this.resources = data; // If successful, set resources to the data received
//         } else {
//             alert(data.message); // If there’s an error, show the message
//         }
//     },

//     // methods: {
//     //     async installPWA() {
//     //         if (this.deferredPrompt) {
//     //             this.deferredPrompt.prompt();
//     //             const choiceResult = await this.deferredPrompt.userChoice;
//     //             if (choiceResult.outcome === "accepted") {
//     //                 console.log("User accepted PWA installation");
//     //             } else {
//     //                 console.log("User dismissed PWA installation");
//     //             }
//     //             this.deferredPrompt = null;
//     //         }
//     //     }
//     // }
// };