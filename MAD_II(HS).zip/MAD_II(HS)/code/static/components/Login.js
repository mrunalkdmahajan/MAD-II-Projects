// export default {
//     template: `
//     <div class='d-flex justify-content-center' style="margin-top: 25vh">
//       <div class="mb-3 p-5 bg-light">

//         <label for="user-email" class="form-label">Email address</label>
//         <input type="email" class="form-control" id="user-email" v-model="email" placeholder="name@example.com">
//         <div class="form-text">We'll never share your email with anyone else.</div>
//     </div>
//     <div class="mb-3 p-5 bg-light">
//         <label for="user-password" class="form-label">Password</label>
//         <input type="password" class="form-control" id="user-password" v-model="password">
//      </div>
//         <button class="btn btn-primary mt-2" @click='login'>Login</button>
//         <div v-if="error" class='text-danger mt-2'>*{{error}}</div>
//         <div class="d-flex justify-content-between align-items-center mb-3">
//                         <router-link to="/register-customer" class="btn btn-outline-primary">
//                             <i class="fas fa-user-plus"></i> Customer Register
//                         </router-link>

//                         <router-link to="/register-professional" class="btn btn-outline-secondary">
//                             <i class="fas fa-briefcase"></i> Professional Register
//                         </router-link>
//         </div>
//       </div> 
//     </div>
//     `,
//     data() {
//         return {
//             email: '',
//             password: '',
//             error: null,
//         }
//     },
//     methods: {
//         async login() {
//             const credentials = {
//                 email: this.email,
//                 password: this.password,
//             };

//             // Send login request to the backend API
//             try {
//                 const response = await fetch('/user-login', {
//                     method: 'POST',
//                     headers: {
//                         'Content-Type': 'application/json',
//                     },
//                     body: JSON.stringify(credentials),
//                 });

//                 const data = await response.json();

//                 if (response.ok) {
//                     // On success, save token and role in localStorage
//                     localStorage.setItem('auth-token', data.token);
//                     localStorage.setItem('role', data.role);
//                     this.$router.push({ path: data.redirect_path || '/' }); // Redirect to the appropriate path
//                 } else {
//                     // Handle errors
//                     this.error = data.message || 'An error occurred. Please try again.';
//                 }
//             } catch (err) {
//                 console.error(err);
//                 this.error = 'Network error. Please try again later.';
//             }
//         },
//     },
// }


// last code b elow


export default {
    template: `
    <div class="d-flex justify-content-center" style="margin-top: 25vh">
        <div class="bg-light p-5 rounded">
            <form @submit.prevent="login">
                <div class="mb-3">
                    <label for="user-email" class="form-label">Email address</label>
                    <input 
                        type="email" 
                        class="form-control" 
                        id="user-email" 
                        v-model="email" 
                        placeholder="name@example.com"
                        required
                    >
                    <div class="form-text">We'll never share your email with anyone else.</div>
                </div>

                <div class="mb-3">
                    <label for="user-password" class="form-label">Password</label>
                    <input 
                        type="password" 
                        class="form-control" 
                        id="user-password" 
                        v-model="password"
                        required
                    >
                </div>

                <button type="submit" class="btn btn-primary w-100 mb-3">Login</button>

                <div v-if="error" class="alert alert-danger mb-3">
                    {{ error }}
                </div>

                <div class="d-flex justify-content-between align-items-center">
                   
                    
                    <button class="btn btn-secondary" @click="$router.push('/register-customer')">
                        Customer Register
                    </button>

                    <button class="btn btn-outline-primary" @click="$router.push('/register-professional')">
                        <i class="fas fa-briefcase"></i> Professional Register
                    </button>


                </div>
            </form>
        </div>
    </div>
    `,
    data() {
        return {
            email: '',
            password: '',
            error: null,
        }
    },
    methods: {
        async login() {
            const credentials = {
                email: this.email,
                password: this.password,
            };

            try {
                const response = await fetch('/user-login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(credentials),
                });

                const data = await response.json();

                if (response.ok) {
                    localStorage.setItem('auth-token', data.token);
                    localStorage.setItem('role', data.role);
                    this.$router.push({ path: data.redirect_path || '/' });
                } else {
                    this.error = data.message || 'An error occurred. Please try again.';
                }
            } catch (err) {
                console.error(err);
                this.error = 'Network error. Please try again later.';
            }
        },
    },
}