export default {
    template: `
    <div class="container">
        <div v-if="service" class="card">
            <div class="card-body">
                <h1 class="card-title">{{ service.name }}</h1>
                
                <div class="row mt-4">
                    <div class="col-md-8">
                        <h4>Description</h4>
                        <p>{{ service.description }}</p>
                        
                        <h4 class="mt-4">Requirements</h4>
                        <ul>
                            <li v-for="req in service.requirements" 
                                :key="req">{{ req }}</li>
                        </ul>

                        <h4 class="mt-4">Available Professionals</h4>
                        <div class="row">
                            <div v-for="professional in service.professionals"
                                 :key="professional.id"
                                 class="col-md-6 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h5>{{ professional.name }}</h5>
                                        <p>Experience: {{ professional.experience }} years</p>
                                        <div class="text-warning mb-2">
                                            Rating: {{ professional.rating }} ⭐
                                        </div>
                                        <button @click="requestProfessional(professional.id)"
                                                class="btn btn-primary">
                                            Request This Professional
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Service Details</h3>
                                <p class="h4">$, {{ service.price }}</p>
                                <p>Duration: {{ service.duration }} minutes</p>
                                <p>Category: {{ service.category }}</p>
                                <div class="text-warning mb-3">
                                    Rating: {{ service.rating }} ⭐
                                </div>
                                <button @click="requestService"
                                        class="btn btn-success btn-lg w-100">
                                    Request Service
                                </button>
                            </div>
                        </div>

                        <div class="card mt-4">
                            <div class="card-body">
                                <h4>Recent Reviews</h4>
                                <div v-for="review in service.reviews"
                                     :key="review.id"
                                     class="mb-3">
                                    <div class="text-warning">
                                        {{ review.rating }} ⭐
                                    </div>
                                    <p>{{ review.comment }}</p>
                                    <small class="text-muted">
                                        - {{ review.user_name }}, {{ review.date }}
                                    </small>
                                    <hr>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `,
    data() {
        return {
            service: null
        };
    },
    methods: {
        async fetchServiceDetails() {
            try {
                const response = await fetch(`/api/services/${this.$route.params.id}`);
                const data = await response.json();
                this.service = data;
            } catch (error) {
                console.error('Error fetching service details:', error);
            }
        },
        async requestService() {
            try {
                const response = await fetch('/api/service-requests', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        service_id: this.service.id
                    })
                });
                const data = await response.json();
                if (response.ok) {
                    alert('Service requested successfully!');
                } else {
                    alert(data.error);
                }
            } catch (error) {
                console.error('Error requesting service:', error);
                alert('Failed to request service');
            }
        },
        async requestProfessional(professionalId) {
            try {
                const response = await fetch('/api/service-requests', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        service_id: this.service.id,
                        professional_id: professionalId
                    })
                });
                const data = await response.json();
                if (response.ok) {
                    alert('Professional requested successfully!');
                } else {
                    alert(data.error);
                }
            } catch (error) {
                console.error('Error requesting professional:', error);
                alert('Failed to request professional');
            }
        }
    },
    created() {
        this.fetchServiceDetails();
    }
};