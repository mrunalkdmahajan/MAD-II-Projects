import Home from './components/Home.js'
import Login from './components/Login.js'

// Admin
import CreateService from './components/Admin/CreateService.js'
// import AllServices from './components/Admin/AllServices';
import FindProfessionals from './components/Admin/FindProfessionals.js';
import ProfileAdmin from './components/Admin/ProfileAdmin.js';
import AdminHome from './components/Admin/AdminHome.js';
import AllServices from './components/Admin/AllServices.js';
import Charts from './components/Admin/Charts.js';
// import FindProfessional from './components/Customer/CustomerFind.js'

import ViewProfessional from './components/Admin/ViewProfessional.js'
import AdminViewCustomerProfile from './components/Admin/ViewCustomerProfile.js'
import AdminEditProfile from './components/Admin/EditProfile.js'
import EditAdminProfile from './components/Admin/EditAdminProfile.js';
import EditService from './components/Admin/EditService.js';
// import ProfileProfessional from './components/Professional/ProfileProfessional.js';
import ProfessionalProfileView from './components/Admin/ProfessionalProfileView.js';
import Find from './components/Customer/Find.js';


// Customer
import CustomerRegister from './components/Customer/CustomerRegister.js'
import ProfileCustomer from './components/Customer/ProfileCustomer.js';
import CustomerHome from './components/Customer/CustomerHome.js';
import SearchServices from './components/Customer/CRequestService.js';
import RequestService from './components/Customer/RequestService.js';
import CustomerFinds from './components/Customer/CustomerFind.js';

// Professional
import ProfessionalRegister from './components/Professional/ProfessionalRegister.js'
import ProfileProfessional from './components/Professional/ProfileProfessional.js';
import ProfessionalHome from './components/Professional/ProfessionalHome.js';
import EditProfessionalProfile from './components/Professional/EditProfessionalProfile.js';

// import Users from './components/Users.js'
// import SudyResourceForm from './components/SudyResourceForm.js'
// import CustomerFind from './components/Customer/CustomerFind.js';
import ProfessionalRequests from './components/Professional/ProfessionalRequests.js';


const routes = [
    { path: '/', component: Home, name: 'Home' },
    { path: '/login', component: Login, name: 'Login' },
    { path: '/admin/charts', component: Charts, name: 'Charts' },
    // {
    //     path: '/admin/view/customer/profile',
    //     component: AdminViewCustomerProfile,
    //     name: 'AdminViewCustomerProfile',

    // },
    {
        path: '/admin/customer/:id/profile',
        name: 'AdminViewCustomerProfile',
        component: AdminViewCustomerProfile
    },
    {
        path: '/professionals/:id',
        name: 'ProfessionalProfileView',
        component: ProfessionalProfileView,
        // props: true
    },
    {
        path: '/admin/edit/profile',
        name: 'AdminEditProfile',
        component: AdminEditProfile
    },
    {
        path: '/professional/edit/profile',
        name: 'EditProfessionalProfile',
        component: EditProfessionalProfile
    },
    {
        path: '/edit/admin/profile',
        name: 'EditAdminProfile',
        component: EditAdminProfile
    },
    {
        path: '/edit/admin/service',
        name: 'EditService',
        component: EditService
    },
    // {
    //     path: "/edit-service-request/:id",
    //     name: "EditServiceRequest",
    //     component: EditServiceRequest // Ensure you have an EditServiceRequest component
    // },


    // {
    //     path: "/services",
    //     name: "AllServices",
    //     component: AllServices,
    // },
    { path: '/services/create', component: CreateService, name: 'CreateService' },
    {
        path: '/profile',
        name: 'ViewProfile',
    },
    // In your router configuration
    // In your router configuration
    {
        path: '/request-service', // No parameter in URL path
        name: 'RequestService',
        component: RequestService,
        props: (route) => ({
            serviceId: route.query.serviceId
        })
    },
    {
        path: '/professional/search',
        name: 'FindProfessionals',
        component: FindProfessionals
    },
    {
        path: '/customer/request-service',
        name: 'SearchServices',
        component: SearchServices
    },
    {
        path: "/admin/all-services",
        name: "AllServices",
        component: AllServices,
    },
    {
        path: "/customer/find",
        name: "Find",
        component: Find,
    },
    {
        path: "/professional/requests",
        name: "ProfessionalRequests",
        component: ProfessionalRequests,
    },
    {
        path: '/ViewProfile',
        name: 'ViewProfessional',
        component: ViewProfessional
    },

    {
        path: '/register-customer',
        name: 'CustomerRegister',
        component: CustomerRegister // You'll need to create this component
    },
    {
        path: '/admin/profile',
        name: 'ProfileAdmin',
        component: ProfileAdmin
    },
    {
        path: '/customer/profile',
        name: 'ProfileCustomer',
        component: ProfileCustomer
    },
    {
        path: '/professional/profile',
        name: 'ProfileProfessional',
        component: ProfileProfessional
    },
    {
        path: '/admin/home/:id',
        name: 'AdminHome',
        component: AdminHome
    },
    {
        path: '/customer/home/:id',
        name: 'CustomerHome',
        component: CustomerHome
    },
    {
        path: '/professional/home/:id',
        name: 'ProfessionalHome',
        component: ProfessionalHome
    },
    // {
    //     path: '/services',
    //     name: 'Services',
    //     component: () =>
    //         import ('@/views/Services.vue')
    // },
    // {
    //     path: '/service/:id',
    //     name: 'ServiceDetail',
    //     component: () =>
    //         import ('@/views/ServiceDetail.vue')
    // },
    {
        path: '/register-professional',
        name: 'ProfessionalRegister',
        component: ProfessionalRegister // You'll need to create this component
    },

    //     { path: '/users', component: Users },
    //     { path: '/create-resource', component: SudyResourceForm },
]

export default new VueRouter({
    routes,
})