// self.addEventListener("install", (event) => {
//     console.log("Service Worker installed");
//     event.waitUntil(
//         caches.open("pwa-cache").then((cache) => {
//             return cache.addAll(["/", "/index.html"]);
//         })
//     );
// });

// self.addEventListener("fetch", (event) => {
//     event.respondWith(
//         caches.match(event.request).then((response) => {
//             return response || fetch(event.request);
//         })
//     );
// });

const CACHE_NAME = "pwa-cache-v1";
const urlsToCache = [
    "/",
    "/static/manifest.json",
    "/static/icons/icon1.png",
    "/static/icons/icon2.png"
];

self.addEventListener("install", (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
        .then((cache) => {
            console.log("Caching files...");
            return cache.addAll(urlsToCache);
        })
        .catch((err) => console.error("Failed to cache:", err))
    );
});

self.addEventListener("fetch", (event) => {
    event.respondWith(
        caches.match(event.request)
        .then((response) => response || fetch(event.request))
        .catch(() => console.error("Fetch failed:", event.request))
    );
});