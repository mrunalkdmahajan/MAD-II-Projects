
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  BookOpen, 
  Briefcase, 
  Video, 
  MessageCircle, 
  ChevronRight,
  Users,
  School,
  GraduationCap,
  Clock
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import DashboardLayout from '@/components/layout/DashboardLayout';

const Dashboard = () => {
  // Mock data
  const placementStats = {
    totalStudents: 150,
    placed: 98,
    ongoingPlacements: 32,
    averageSalary: '12.4 LPA',
    topCompanies: ['Google', 'Microsoft', 'Amazon', 'Adobe', 'Goldman Sachs']
  };
  
  const recentActivities = [
    {
      id: '1',
      title: 'DSA Test 2 Completed',
      type: 'test',
      score: 85,
      date: 'Today'
    },
    {
      id: '2',
      title: 'Amazon Hiring Drive',
      type: 'job',
      company: 'Amazon',
      date: 'Yesterday'
    },
    {
      id: '3',
      title: 'Mock Interview Session',
      type: 'interview',
      date: '2 days ago'
    }
  ];
  
  const upcomingEvents = [
    {
      id: '1',
      title: 'Microsoft On-Campus Drive',
      date: 'Aug 15, 2023',
      type: 'recruitment'
    },
    {
      id: '2',
      title: 'Resume Building Workshop',
      date: 'Aug 12, 2023',
      type: 'workshop'
    }
  ];

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-1">
              Welcome back! Here's an overview of your placement activities
            </p>
          </div>
          <Button asChild className="mt-4 md:mt-0">
            <Link to="/placement-prep">
              Go to Placement Preparation
            </Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-gray-500">Total Students</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{placementStats.totalStudents}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-gray-500">Students Placed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{placementStats.placed}</div>
              <div className="text-sm text-gray-500 mt-1">
                {Math.round((placementStats.placed / placementStats.totalStudents) * 100)}% Placement Rate
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-gray-500">Ongoing Placements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{placementStats.ongoingPlacements}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-gray-500">Average Package</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-amber-600">{placementStats.averageSalary}</div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Recent Activities</CardTitle>
              <CardDescription>Your latest placement preparation activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map(activity => (
                  <div key={activity.id} className="flex items-start">
                    <div className={`p-2 rounded-md mr-4 ${
                      activity.type === 'test' ? 'bg-blue-50' : 
                      activity.type === 'job' ? 'bg-green-50' : 
                      'bg-purple-50'
                    }`}>
                      {activity.type === 'test' ? (
                        <BookOpen className="h-5 w-5 text-blue-600" />
                      ) : activity.type === 'job' ? (
                        <Briefcase className="h-5 w-5 text-green-600" />
                      ) : (
                        <Video className="h-5 w-5 text-purple-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium text-gray-900">{activity.title}</h4>
                        <span className="text-xs text-gray-500">{activity.date}</span>
                      </div>
                      {activity.type === 'test' && activity.score && (
                        <div className="mt-1">
                          <div className="flex justify-between items-center text-xs mb-1">
                            <span>Score</span>
                            <span className="font-medium">{activity.score}%</span>
                          </div>
                          <Progress value={activity.score} className="h-1.5" />
                        </div>
                      )}
                      {activity.type === 'job' && activity.company && (
                        <div className="mt-1 text-xs text-gray-600">
                          <span>{activity.company}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full">
                View All Activities
              </Button>
            </CardFooter>
          </Card>
          
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Upcoming Events</CardTitle>
              <CardDescription>Scheduled placement events and activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingEvents.map(event => (
                  <div key={event.id} className="flex items-start">
                    <div className={`p-2 rounded-md mr-4 ${
                      event.type === 'recruitment' ? 'bg-amber-50' : 'bg-green-50'
                    }`}>
                      {event.type === 'recruitment' ? (
                        <Briefcase className="h-5 w-5 text-amber-600" />
                      ) : (
                        <School className="h-5 w-5 text-green-600" />
                      )}
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">{event.title}</h4>
                      <div className="flex items-center mt-1 text-xs text-gray-600">
                        <Clock className="h-3 w-3 mr-1" />
                        <span>{event.date}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full">
                View All Events
              </Button>
            </CardFooter>
          </Card>
          
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Top Recruiters</CardTitle>
              <CardDescription>Companies hiring from our campus</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {placementStats.topCompanies.map((company, idx) => (
                  <Badge key={idx} variant="outline" className="px-3 py-1">
                    {company}
                  </Badge>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full">
                View All Companies
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        <div className="mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Placement Preparation</CardTitle>
              <CardDescription>
                Enhance your interview skills and prepare for placement
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start p-4 rounded-lg border hover:bg-slate-50 transition-colors">
                  <div className="p-3 bg-blue-50 rounded-md mr-4">
                    <BookOpen className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">Practice Tests</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      Take tests on DSA, logical reasoning, verbal ability, and quantitative aptitude.
                    </p>
                    <Button variant="outline" size="sm" asChild>
                      <Link to="/placement-prep/tests">
                        Take Tests <ChevronRight className="h-4 w-4 ml-1" />
                      </Link>
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-start p-4 rounded-lg border hover:bg-slate-50 transition-colors">
                  <div className="p-3 bg-purple-50 rounded-md mr-4">
                    <Video className="h-5 w-5 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">Demo Interviews</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      Practice with mock interviews from top companies.
                    </p>
                    <Button variant="outline" size="sm" asChild>
                      <Link to="/placement-prep/demo-interviews">
                        Try Interviews <ChevronRight className="h-4 w-4 ml-1" />
                      </Link>
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-start p-4 rounded-lg border hover:bg-slate-50 transition-colors">
                  <div className="p-3 bg-green-50 rounded-md mr-4">
                    <MessageCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">Placement Chatbot</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      Get guidance on placement processes and interview preparation.
                    </p>
                    <Button variant="outline" size="sm" asChild>
                      <Link to="/placement-prep/chatbot">
                        Chat Now <ChevronRight className="h-4 w-4 ml-1" />
                      </Link>
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-start p-4 rounded-lg border hover:bg-slate-50 transition-colors">
                  <div className="p-3 bg-amber-50 rounded-md mr-4">
                    <Briefcase className="h-5 w-5 text-amber-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">Job Recommendations</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      Explore job opportunities matched to your profile.
                    </p>
                    <Button variant="outline" size="sm" asChild>
                      <Link to="/placement-prep/job-recommendation">
                        View Jobs <ChevronRight className="h-4 w-4 ml-1" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link to="/placement-prep">
                  Go to Placement Preparation
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;
