
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, Video, MessageCircle, Briefcase } from 'lucide-react';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const PlacementPrep = () => {
  const prepSections = [
    {
      title: 'Practice Tests',
      description: 'DSA, Logical, Verbal & Quantitative Aptitude',
      icon: <BookOpen className="h-8 w-8 text-blue-600" />,
      path: '/placement-prep/tests',
      bgColor: 'bg-blue-50',
      color: 'text-blue-700'
    },
    {
      title: 'Demo Interviews',
      description: 'Practice with mock interviews from top companies',
      icon: <Video className="h-8 w-8 text-purple-600" />,
      path: '/placement-prep/demo-interviews',
      bgColor: 'bg-purple-50',
      color: 'text-purple-700'
    },
    {
      title: 'Placement Chatbot',
      description: 'Get answers to all your placement questions',
      icon: <MessageCircle className="h-8 w-8 text-green-600" />,
      path: '/placement-prep/chatbot',
      bgColor: 'bg-green-50',
      color: 'text-green-700'
    },
    {
      title: 'Job Recommendations',
      description: 'Personalized job matches based on your profile',
      icon: <Briefcase className="h-8 w-8 text-amber-600" />,
      path: '/placement-prep/job-recommendation',
      bgColor: 'bg-amber-50',
      color: 'text-amber-700'
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Placement Preparation</h1>
          <p className="text-gray-600 mt-2">
            Enhance your skills and prepare for placement with our comprehensive tools and resources.
          </p>
        </div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {prepSections.map((section) => (
            <motion.div key={section.title} variants={itemVariants}>
              <Link to={section.path}>
                <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1">
                  <CardHeader>
                    <div className={`p-3 rounded-lg w-fit ${section.bgColor}`}>
                      {section.icon}
                    </div>
                    <CardTitle className={`mt-4 ${section.color}`}>{section.title}</CardTitle>
                    <CardDescription>{section.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-500">
                      Click to explore {section.title.toLowerCase()}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </DashboardLayout>
  );
};

export default PlacementPrep;
