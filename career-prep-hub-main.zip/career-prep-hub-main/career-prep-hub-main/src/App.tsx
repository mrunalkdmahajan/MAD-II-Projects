
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import PlacementPrep from "./pages/PlacementPrep";
import Tests from "./pages/Tests";
import TestDetail from "./pages/TestDetail";
import DemoInterviews from "./pages/DemoInterviews";
import JobRecommendation from "./pages/JobRecommendation";
import PlacementChatbot from "./pages/PlacementChatbot";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/placement-prep" element={<PlacementPrep />} />
          <Route path="/placement-prep/tests" element={<Tests />} />
          <Route path="/placement-prep/tests/:category/:id" element={<TestDetail />} />
          <Route path="/placement-prep/demo-interviews" element={<DemoInterviews />} />
          <Route path="/placement-prep/job-recommendation" element={<JobRecommendation />} />
          <Route path="/placement-prep/chatbot" element={<PlacementChatbot />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
