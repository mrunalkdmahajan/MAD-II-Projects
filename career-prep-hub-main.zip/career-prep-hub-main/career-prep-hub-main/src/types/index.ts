
export type TestCategory = 'dsa' | 'logical' | 'verbal' | 'qa';

export type ProgrammingLanguage = 'python' | 'java' | 'cpp';

export interface TestQuestion {
  id: string;
  question: string;
  options?: string[];
  answer?: string;
  code?: string;
  explanation?: string;
  difficulty: 'easy' | 'medium' | 'hard';
  timeEstimate: number; // in seconds
  category: TestCategory;
  // For coding questions
  initialCode?: Record<ProgrammingLanguage, string>;
  testCases?: Array<{
    input: string;
    output: string;
    explanation?: string;
  }>;
}

export interface Test {
  id: string;
  title: string;
  description: string;
  category: TestCategory;
  timeLimit: number; // in seconds
  questions: TestQuestion[];
  isMasterTest?: boolean; // If true, this is the 6th test with mixed questions
}

export interface TestAttempt {
  id: string;
  testId: string;
  startTime: Date;
  endTime?: Date;
  answers: Record<string, string | null>;
  isCompleted: boolean;
  score?: number;
  strengths?: string[];
  weaknesses?: string[];
}

export interface DemoInterview {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  company?: string;
  role?: string;
  videoUrl?: string;
  questions: Array<{
    id: string;
    question: string;
    expectedAnswer?: string;
    tips?: string[];
  }>;
}

export interface JobRecommendation {
  id: string;
  title: string;
  company: string;
  location: string;
  salary?: string;
  description: string;
  requirements: string[];
  applicationUrl: string;
  postedDate: Date;
  deadline?: Date;
  matchPercentage: number;
}
