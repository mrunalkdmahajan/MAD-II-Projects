
import { ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { 
  BookOpen, 
  BriefcaseIcon, 
  MessageCircle, 
  Video, 
  LayoutDashboard, 
  Users, 
  FileText, 
  Settings, 
  Bell
} from "lucide-react";
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';

interface DashboardLayoutProps {
  children: ReactNode;
}

const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  const location = useLocation();
  
  const sidebarLinks = [
    { name: 'Dashboard', path: '/dashboard', icon: <LayoutDashboard className="h-5 w-5" /> },
    { name: 'Manage Students', path: '/manage-students', icon: <Users className="h-5 w-5" /> },
    { name: 'Job Postings', path: '/job-postings', icon: <BriefcaseIcon className="h-5 w-5" /> },
    { name: 'Messages', path: '/messages', icon: <MessageCircle className="h-5 w-5" /> },
    { name: 'Profile', path: '/profile', icon: <FileText className="h-5 w-5" /> },
    { name: 'Settings', path: '/settings', icon: <Settings className="h-5 w-5" /> },
  ];

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-md border-r border-gray-200 fixed h-full">
        <div className="px-6 py-4 border-b border-gray-200">
          <Link to="/dashboard" className="flex items-center space-x-2">
            <div className="bg-blue-600 text-white p-2 rounded-md">
              <BookOpen className="h-5 w-5" />
            </div>
            <h1 className="text-xl font-bold text-blue-700">PlaceNext</h1>
          </Link>
        </div>
        <nav className="mt-6 px-4">
          <ul className="space-y-2">
            {sidebarLinks.map((link) => (
              <li key={link.path}>
                <Link
                  to={link.path}
                  className={cn(
                    "flex items-center px-4 py-2.5 text-sm rounded-md transition-colors",
                    location.pathname === link.path
                      ? "bg-blue-50 text-blue-700 font-medium"
                      : "text-gray-600 hover:bg-gray-100"
                  )}
                >
                  <span className="mr-3">{link.icon}</span>
                  {link.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 ml-64">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="flex justify-between items-center px-6 py-3">
            <h1 className="text-lg font-medium">Student Dashboard</h1>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5 text-gray-600" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </Button>
              <Avatar className="h-8 w-8">
                <img src="https://github.com/shadcn.png" alt="User" />
              </Avatar>
            </div>
          </div>
        </header>
        
        {/* Content */}
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
