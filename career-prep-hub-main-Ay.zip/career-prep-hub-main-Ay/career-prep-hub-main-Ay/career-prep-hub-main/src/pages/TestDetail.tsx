import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { 
  ArrowLeft, 
  Clock, 
  Pause, 
  Play, 
  AlertCircle, 
  CheckCircle,
  ChevronRight, 
  ChevronLeft,
  Send,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { TestQuestion, ProgrammingLanguage, TestCategory } from '@/types';

// Mock data for the questions
const generateMockQuestions = (category: TestCategory, testId: string): TestQuestion[] => {
  // This is a simplified version. In a real app, you'd fetch this from an API
  switch(category) {
    case 'dsa':
      return Array.from({ length: 10 }, (_, i) => ({
        id: `${testId}-q${i+1}`,
        question: `Write a function to ${i % 3 === 0 ? 'find the maximum element in an array' : 
                   i % 3 === 1 ? 'reverse a linked list' : 'implement binary search'}`,
        difficulty: i < 4 ? 'easy' : i < 8 ? 'medium' : 'hard',
        timeEstimate: (i + 1) * 5 * 60, // increasing time estimates
        category: 'dsa',
        initialCode: {
          python: `def solution(arr):\n    # Your code here\n    pass\n\n# Example usage\nresult = solution([1, 2, 3, 4, 5])`,
          java: `class Solution {\n    public static void main(String[] args) {\n        // Example usage\n        int[] arr = {1, 2, 3, 4, 5};\n        System.out.println(solution(arr));\n    }\n\n    public static int solution(int[] arr) {\n        // Your code here\n        return 0;\n    }\n}`,
          cpp: `#include <iostream>\n#include <vector>\n\nusing namespace std;\n\nint solution(vector<int> arr) {\n    // Your code here\n    return 0;\n}\n\nint main() {\n    vector<int> arr = {1, 2, 3, 4, 5};\n    cout << solution(arr) << endl;\n    return 0;\n}`
        },
        testCases: [
          {
            input: '[1, 2, 3, 4, 5]',
            output: '5',
            explanation: 'The maximum element is 5'
          },
          {
            input: '[-1, -2, -3, -4, -5]',
            output: '-1',
            explanation: 'The maximum element is -1'
          }
        ]
      }));
    case 'logical':
      return Array.from({ length: 20 }, (_, i) => ({
        id: `${testId}-q${i+1}`,
        question: `If a train travels at 60 km/h and takes 15 minutes to pass through a tunnel, how long is the tunnel?`,
        options: ['15 km', '30 km', '7.5 km', '22.5 km'],
        answer: '7.5 km',
        explanation: 'Speed = 60 km/h = 1 km/min. Time = 15 min. Distance = Speed × Time = 1 × 15 = 15 km',
        difficulty: i < 7 ? 'easy' : i < 15 ? 'medium' : 'hard',
        timeEstimate: 60, // 1 minute per question
        category: 'logical'
      }));
    case 'verbal':
      // 20 unique verbal ability questions
      const verbalQuestions = [
        {
          question: "Choose the word that is most similar in meaning to 'Eloquent':",
          options: ['Articulate', 'Silent', 'Written', 'Complicated'],
          answer: 'Articulate',
          explanation: 'Eloquent means fluent or persuasive in speaking or writing.'
        },
        {
          question: "Select the antonym for 'Benevolent':",
          options: ['Malevolent', 'Generous', 'Charitable', 'Kind'],
          answer: 'Malevolent',
          explanation: 'Benevolent means kind and generous, while malevolent means having evil intentions.'
        },
        {
          question: "Choose the word that best completes the sentence: 'The detective's _______ remarks left everyone confused about the case.'",
          options: ['Ambiguous', 'Clear', 'Definite', 'Simple'],
          answer: 'Ambiguous',
          explanation: 'Ambiguous means unclear or open to interpretation, which fits the context of causing confusion.'
        },
        {
          question: "Identify the correct spelling:",
          options: ['Accommodation', 'Accomodation', 'Acommodation', 'Acomodation'],
          answer: 'Accommodation',
          explanation: 'Accommodation is the correct spelling with two "c"s and two "m"s.'
        },
        {
          question: "Choose the word that is most similar in meaning to 'Diligent':",
          options: ['Hardworking', 'Lazy', 'Careless', 'Distracted'],
          answer: 'Hardworking',
          explanation: 'Diligent means showing persistent effort and hard work.'
        },
        {
          question: "Select the antonym for 'Frugal':",
          options: ['Extravagant', 'Thrifty', 'Economical', 'Careful'],
          answer: 'Extravagant',
          explanation: 'Frugal means economical, while extravagant means spending freely or wastefully.'
        },
        {
          question: "Choose the correct meaning of the idiom: 'To beat around the bush'",
          options: ['To avoid the main topic', 'To search thoroughly', 'To solve a problem', 'To speak clearly'],
          answer: 'To avoid the main topic',
          explanation: 'To beat around the bush means to avoid talking about what is important or getting to the point.'
        },
        {
          question: "Identify the grammatically correct sentence:",
          options: [
            'Neither John nor his brothers was at the party.',
            'Neither John nor his brothers were at the party.',
            'Neither John nor his brothers is at the party.',
            'Neither John nor his brothers has at the party.'
          ],
          answer: 'Neither John nor his brothers were at the party.',
          explanation: 'When "neither/nor" connects subjects, the verb agrees with the subject closest to it (in this case "brothers," which is plural).'
        },
        {
          question: "Choose the word that is most similar in meaning to 'Audacious':",
          options: ['Bold', 'Timid', 'Careful', 'Weak'],
          answer: 'Bold',
          explanation: 'Audacious means showing a willingness to take surprisingly bold risks.'
        },
        {
          question: "Select the word that does NOT belong with the others:",
          options: ['Ecstatic', 'Jubilant', 'Melancholy', 'Elated'],
          answer: 'Melancholy',
          explanation: 'Melancholy means sad or depressed, while all other options describe happiness or excitement.'
        },
        {
          question: "Choose the correct meaning of the prefix 'inter-':",
          options: ['Between', 'Inside', 'Against', 'Beyond'],
          answer: 'Between',
          explanation: 'The prefix "inter-" means between, among, or in the midst of, as in intercontinental (between continents).'
        },
        {
          question: "Complete the analogy: Book is to Reading as Food is to _____",
          options: ['Cooking', 'Eating', 'Recipe', 'Ingredients'],
          answer: 'Eating',
          explanation: 'The relationship is object and its associated action. A book is read, and food is eaten.'
        },
        {
          question: "Choose the word with the correct suffix to complete: 'The artist's creativ_____ was evident in her work.'",
          options: ['ness', 'ity', 'ion', 'ment'],
          answer: 'ity',
          explanation: 'Creativity is the correct form of this noun. The suffix "-ity" is used to form nouns from adjectives.'
        },
        {
          question: "Select the most precise synonym for 'Describe':",
          options: ['Depict', 'Tell', 'Say', 'Talk'],
          answer: 'Depict',
          explanation: 'To depict means to represent or portray in words or pictures, which is more precise than the other options.'
        },
        {
          question: "Choose the correct meaning of the phrasal verb 'To look up to':",
          options: ['To admire', 'To search for', 'To visit', 'To climb'],
          answer: 'To admire',
          explanation: 'To look up to someone means to admire or respect them.'
        },
        {
          question: "Identify the word with the incorrect prefix:",
          options: ['Disagree', 'Disappear', 'Discomfort', 'Dispolite'],
          answer: 'Dispolite',
          explanation: 'The correct negative form is "impolite," not "dispolite." The prefix "dis-" is not used with "polite."'
        },
        {
          question: "Choose the word that best completes the sentence: 'The professor's lecture was so _______ that half the class fell asleep.'",
          options: ['Engaging', 'Tedious', 'Fascinating', 'Dynamic'],
          answer: 'Tedious',
          explanation: 'If people are falling asleep, the lecture was likely boring or tedious (tiresome), not engaging, fascinating, or dynamic.'
        },
        {
          question: "Select the pair of words that have a similar relationship to 'Author : Book':",
          options: [
            'Painter : Canvas',
            'Chef : Kitchen',
            'Doctor : Hospital',
            'Teacher : Student'
          ],
          answer: 'Painter : Canvas',
          explanation: 'An author creates a book, and a painter creates work on a canvas. The other pairs don\'t share this creator-creation relationship.'
        },
        {
          question: "Identify the sentence with correct subject-verb agreement:",
          options: [
            'The team are playing their best game.',
            'The team is playing their best game.',
            'The team is playing its best game.',
            'The team are playing its best game.'
          ],
          answer: 'The team is playing its best game.',
          explanation: 'In American English, collective nouns like "team" take singular verbs and pronouns.'
        },
        {
          question: "Choose the sentence with the correct use of apostrophes:",
          options: [
            'The childrens\' toys were scattered around the room.',
            'The children\'s toys were scattered around the room.',
            'The childrens\'s toys were scattered around the room.',
            'The childrens toys were scattered around the room.'
          ],
          answer: 'The children\'s toys were scattered around the room.',
          explanation: 'Since "children" is already plural, we add only an apostrophe followed by "s" to show possession.'
        }
      ];

      return verbalQuestions.map((q, i) => ({
        id: `${testId}-q${i+1}`,
        question: q.question,
        options: q.options,
        answer: q.answer,
        explanation: q.explanation,
        difficulty: i < 7 ? 'easy' : i < 15 ? 'medium' : 'hard',
        timeEstimate: 45, // 45 seconds per question
        category: 'verbal' as TestCategory
      }));
    case 'qa':
      return Array.from({ length: 20 }, (_, i) => ({
        id: `${testId}-q${i+1}`,
        question: `If 5x + 3y = 26 and 3x + 5y = 34, what is the value of x + y?`,
        options: ['7', '8', '9', '10'],
        answer: '10',
        explanation: 'Solving the system of equations: 5x + 3y = 26, 3x + 5y = 34. Multiplying the first by 5 and the second by 3: 25x + 15y = 130, 9x + 15y = 102. Subtracting: 16x = 28, so x = 1.75. Substituting back: 5(1.75) + 3y = 26, so 8.75 + 3y = 26, 3y = 17.25, y = 5.75. Therefore, x + y = 1.75 + 5.75 = 7.5 + 0.5 = 8.',
        difficulty: i < 7 ? 'easy' : i < 15 ? 'medium' : 'hard',
        timeEstimate: 90, // 90 seconds per question
        category: 'qa'
      }));
    default:
      return [];
  }
};

const TestDetail = () => {
  const { category, id } = useParams<{ category: TestCategory; id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { register, handleSubmit, setValue, watch } = useForm();
  
  const [questions, setQuestions] = useState<TestQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(3600); // Default 1 hour
  const [isPaused, setIsPaused] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [programmingLanguage, setProgrammingLanguage] = useState<ProgrammingLanguage>('python');
  const [results, setResults] = useState<{
    score: number;
    totalQuestions: number;
    correctAnswers: number;
    strengths: string[];
    weaknesses: string[];
  } | null>(null);
  
  // Get current question
  const currentQuestion = questions[currentQuestionIndex];
  
  // Form the title based on the category
  const getTitle = () => {
    switch(category) {
      case 'dsa': return 'Data Structures & Algorithms';
      case 'logical': return 'Logical Reasoning';
      case 'verbal': return 'Verbal Ability';
      case 'qa': return 'Quantitative Aptitude';
      default: return 'Test';
    }
  };

  // Initialize the test
  useEffect(() => {
    if (category && id) {
      const mockQuestions = generateMockQuestions(category, id);
      setQuestions(mockQuestions);
      
      // Set appropriate time limit based on category and number of questions
      let totalTime = 0;
      if (category === 'dsa') {
        totalTime = 3600; // 1 hour for DSA
      } else if (mockQuestions.length > 0) {
        // Sum up estimated time for all questions + 10% buffer
        totalTime = Math.ceil(mockQuestions.reduce((acc, q) => acc + q.timeEstimate, 0) * 1.1);
      } else {
        totalTime = 1800; // 30 minutes default
      }
      
      setTimeRemaining(totalTime);
    }
  }, [category, id]);

  // Timer
  useEffect(() => {
    if (!isPaused && timeRemaining > 0 && !isSubmitted) {
      const timer = setTimeout(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
      
      return () => clearTimeout(timer);
    } else if (timeRemaining <= 0 && !isSubmitted) {
      // Auto-submit when time runs out
      handleSubmitTest();
    }
  }, [timeRemaining, isPaused, isSubmitted]);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleLanguageChange = (language: ProgrammingLanguage) => {
    setProgrammingLanguage(language);
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const togglePause = () => {
    setIsPaused(prev => !prev);
    toast({
      title: isPaused ? "Test resumed" : "Test paused",
      description: isPaused ? "Timer is now running" : "Timer has been paused",
      duration: 3000,
    });
  };

  const handleSubmitTest = () => {
    // In a real app, you'd process the answers and calculate the score
    // Here we'll just simulate results
    
    // Calculate a random score between 65 and 95
    const score = Math.floor(Math.random() * 31) + 65;
    const correctAnswers = Math.floor((questions.length * score) / 100);
    
    // Generate mock strengths and weaknesses
    let strengths = [];
    let weaknesses = [];
    
    if (category === 'dsa') {
      if (score > 80) strengths.push('Algorithm complexity analysis', 'Data structure selection');
      else weaknesses.push('Algorithm complexity analysis', 'Data structure selection');
      
      if (score > 70) strengths.push('Problem decomposition');
      else weaknesses.push('Problem decomposition');
      
      if (score < 85) weaknesses.push('Optimization techniques');
    } else if (category === 'logical') {
      if (score > 80) strengths.push('Pattern recognition', 'Deductive reasoning');
      else weaknesses.push('Pattern recognition', 'Deductive reasoning');
      
      if (score > 75) strengths.push('Analytical thinking');
      else weaknesses.push('Analytical thinking');
    } else if (category === 'verbal') {
      if (score > 80) strengths.push('Vocabulary', 'Reading comprehension');
      else weaknesses.push('Vocabulary', 'Reading comprehension');
      
      if (score > 75) strengths.push('Grammar usage');
      else weaknesses.push('Grammar usage');
      
      if (score < 70) weaknesses.push('Synonyms and antonyms');
    } else if (category === 'qa') {
      if (score > 80) strengths.push('Mathematical reasoning', 'Numerical computation');
      else weaknesses.push('Mathematical reasoning', 'Numerical computation');
      
      if (score > 75) strengths.push('Problem-solving speed');
      else weaknesses.push('Problem-solving speed');
      
      if (score < 70) weaknesses.push('Advanced mathematical concepts');
    }
    
    setResults({
      score,
      totalQuestions: questions.length,
      correctAnswers,
      strengths,
      weaknesses
    });
    
    setIsSubmitted(true);
  };
  
  // Handle form submission confirmation
  const onSubmit = (data: any) => {
    setIsConfirmDialogOpen(true);
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto">
        {!isSubmitted ? (
          <div>
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
              <div className="flex items-center mb-4 md:mb-0">
                <Button 
                  variant="outline" 
                  size="icon"
                  className="mr-3" 
                  onClick={() => navigate('/placement-prep/tests')}
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">{getTitle()} Test</h1>
                  <p className="text-sm text-gray-500">Complete all questions before time runs out</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <Button 
                  variant="outline"
                  onClick={togglePause}
                  className="flex items-center space-x-2"
                >
                  {isPaused ? <Play className="h-4 w-4 mr-1" /> : <Pause className="h-4 w-4 mr-1" />}
                  {isPaused ? 'Resume' : 'Pause'}
                </Button>
                
                <div className={`flex items-center space-x-2 px-4 py-2 rounded-md ${
                  timeRemaining < 300 ? 'bg-red-50 text-red-700' : 'bg-blue-50 text-blue-700'
                }`}>
                  <Clock className="h-4 w-4" />
                  <span className="font-medium">{formatTime(timeRemaining)}</span>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">
                  Question {currentQuestionIndex + 1} of {questions.length}
                </span>
                <span className="text-xs text-gray-500">
                  {Math.round((currentQuestionIndex + 1) / questions.length * 100)}% complete
                </span>
              </div>
              <Progress value={(currentQuestionIndex + 1) / questions.length * 100} className="h-2" />
            </div>
            
            {currentQuestion && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle className="text-lg">{currentQuestion.question}</CardTitle>
                  </CardHeader>
                  
                  <CardContent>
                    {category === 'dsa' ? (
                      <div className="space-y-4">
                        <Tabs defaultValue={programmingLanguage} onValueChange={(val) => handleLanguageChange(val as ProgrammingLanguage)}>
                          <TabsList className="mb-4">
                            <TabsTrigger value="python">Python</TabsTrigger>
                            <TabsTrigger value="java">Java</TabsTrigger>
                            <TabsTrigger value="cpp">C++</TabsTrigger>
                          </TabsList>
                          
                          <TabsContent value="python" className="mt-0">
                            <div className="bg-gray-900 text-gray-50 p-4 rounded-md font-mono text-sm overflow-x-auto">
                              <pre>{currentQuestion.initialCode?.python}</pre>
                            </div>
                          </TabsContent>
                          <TabsContent value="java" className="mt-0">
                            <div className="bg-gray-900 text-gray-50 p-4 rounded-md font-mono text-sm overflow-x-auto">
                              <pre>{currentQuestion.initialCode?.java}</pre>
                            </div>
                          </TabsContent>
                          <TabsContent value="cpp" className="mt-0">
                            <div className="bg-gray-900 text-gray-50 p-4 rounded-md font-mono text-sm overflow-x-auto">
                              <pre>{currentQuestion.initialCode?.cpp}</pre>
                            </div>
                          </TabsContent>
                        </Tabs>
                        
                        <div>
                          <h4 className="font-medium mb-2">Test Cases</h4>
                          <div className="space-y-3">
                            {currentQuestion.testCases?.map((testCase, idx) => (
                              <div key={idx} className="bg-gray-50 p-3 rounded-md text-sm">
                                <div><span className="font-medium">Input:</span> {testCase.input}</div>
                                <div><span className="font-medium">Expected Output:</span> {testCase.output}</div>
                                {testCase.explanation && (
                                  <div className="text-gray-600 text-xs mt-1">{testCase.explanation}</div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <RadioGroup className="space-y-4">
                        {currentQuestion.options?.map((option, idx) => (
                          <div key={idx} className="flex items-center space-x-2">
                            <RadioGroupItem 
                              id={`option-${idx}`} 
                              value={option}
                              {...register(`question-${currentQuestion.id}`)}
                            />
                            <Label htmlFor={`option-${idx}`} className="text-base">{option}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                    )}
                  </CardContent>
                </Card>
                
                <div className="flex justify-between">
                  <Button 
                    variant="outline" 
                    onClick={handlePrev} 
                    disabled={currentQuestionIndex === 0}
                  >
                    <ChevronLeft className="h-4 w-4 mr-1" /> Previous
                  </Button>
                  
                  {currentQuestionIndex < questions.length - 1 ? (
                    <Button onClick={handleNext}>
                      Next <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  ) : (
                    <Button onClick={() => setIsConfirmDialogOpen(true)}>
                      Submit Test <Send className="h-4 w-4 ml-1" />
                    </Button>
                  )}
                </div>
              </motion.div>
            )}
            
            {/* Confirmation Dialog */}
            <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Submit Test</DialogTitle>
                  <DialogDescription>
                    Are you sure you want to submit your test? You won't be able to make any changes after submitting.
                  </DialogDescription>
                </DialogHeader>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>Cancel</Button>
                  <Button onClick={handleSubmitTest}>Submit Test</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-4">
                <CheckCircle className="h-8 w-8 text-blue-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900">Test Completed!</h1>
              <p className="text-gray-600 mt-2">
                Here's how you performed on the {getTitle()} test
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-gray-500">Score</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">{results?.score}%</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-gray-500">Questions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">
                    {results?.correctAnswers}/{results?.totalQuestions}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-gray-500">Time Taken</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">
                    {formatTime(3600 - timeRemaining)}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-green-600">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Strengths
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {results?.strengths && results.strengths.length > 0 ? (
                    <ul className="list-disc list-inside space-y-2">
                      {results.strengths.map((strength, idx) => (
                        <li key={idx} className="text-gray-700">{strength}</li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-gray-500">No specific strengths identified.</p>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-red-600">
                    <AlertCircle className="h-5 w-5 mr-2" />
                    Areas for Improvement
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {results?.weaknesses && results.weaknesses.length > 0 ? (
                    <ul className="list-disc list-inside space-y-2">
                      {results.weaknesses.map((weakness, idx) => (
                        <li key={idx} className="text-gray-700">{weakness}</li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-gray-500">No specific weaknesses identified.</p>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <div className="flex justify-between">
              <Button 
                variant="outline" 
                onClick={() => navigate('/placement-prep/tests')}
                className="flex items-center"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Tests
              </Button>
              
              <Button 
                onClick={() => navigate(`/placement-prep/tests/${category}`)}
                className="flex items-center"
              >
                <div className="mr-2">Take Another Test</div>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default TestDetail