
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Briefcase, 
  MapPin, 
  Calendar, 
  DollarSign, 
  ExternalLink, 
  ChevronDown,
  Building,
  Search,
  Filter,
  Award,
  Tag,
  Clock,
  Bookmark
} from 'lucide-react';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from '@/components/ui/accordion';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from '@/hooks/use-toast';
import { JobRecommendation } from '@/types';

const JobRecommendationPage = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [filterLocation, setFilterLocation] = useState('all');
  
  // Mock data for job recommendations
  const jobs: JobRecommendation[] = [
    {
      id: '1',
      title: 'Software Engineer',
      company: 'Google',
      location: 'Bangalore, India',
      salary: '₹15-25 LPA',
      description: 'Join Google as a Software Engineer to work on large-scale applications that impact millions of users worldwide. In this role, you\'ll collaborate with cross-functional teams to design, develop, and maintain software solutions.',
      requirements: [
        'B.Tech/M.Tech in Computer Science or related field',
        'Strong programming skills in Java, Python, or C++',
        'Experience with data structures and algorithms',
        'Problem-solving abilities and analytical thinking'
      ],
      applicationUrl: 'https://careers.google.com',
      postedDate: new Date('2023-06-15'),
      deadline: new Date('2023-07-15'),
      matchPercentage: 95
    },
    {
      id: '2',
      title: 'Full Stack Developer',
      company: 'Microsoft',
      location: 'Hyderabad, India',
      salary: '₹12-20 LPA',
      description: 'Microsoft is seeking a Full Stack Developer to join our dynamic team. The ideal candidate will build web applications using modern technologies and frameworks.',
      requirements: [
        'Bachelor\'s degree in Computer Science or related field',
        'Experience with JavaScript, React, and Node.js',
        'Understanding of database technologies',
        'Strong communication skills'
      ],
      applicationUrl: 'https://careers.microsoft.com',
      postedDate: new Date('2023-06-10'),
      deadline: new Date('2023-07-10'),
      matchPercentage: 88
    },
    {
      id: '3',
      title: 'Data Scientist',
      company: 'Amazon',
      location: 'Bangalore, India',
      salary: '₹18-28 LPA',
      description: 'Join Amazon as a Data Scientist to work on cutting-edge machine learning models and data analysis projects that drive business decisions.',
      requirements: [
        'Master\'s or PhD in Computer Science, Statistics, or related field',
        'Experience with machine learning algorithms and statistical modeling',
        'Proficiency in Python, R, or SQL',
        'Strong analytical and problem-solving skills'
      ],
      applicationUrl: 'https://www.amazon.jobs',
      postedDate: new Date('2023-06-05'),
      deadline: new Date('2023-07-05'),
      matchPercentage: 82
    },
    {
      id: '4',
      title: 'Frontend Developer',
      company: 'Flipkart',
      location: 'Bangalore, India',
      salary: '₹10-18 LPA',
      description: 'Develop and maintain user interfaces for Flipkart\'s e-commerce platform, ensuring optimal performance and user experience.',
      requirements: [
        'Bachelor\'s degree in Computer Science or related field',
        'Proficiency in HTML, CSS, JavaScript, and React',
        'Experience with responsive design and cross-browser compatibility',
        'Understanding of web performance optimization'
      ],
      applicationUrl: 'https://www.flipkartcareers.com',
      postedDate: new Date('2023-06-02'),
      deadline: new Date('2023-07-02'),
      matchPercentage: 76
    },
    {
      id: '5',
      title: 'Backend Engineer',
      company: 'Swiggy',
      location: 'Bangalore, India',
      salary: '₹12-22 LPA',
      description: 'Design and develop scalable backend services for Swiggy\'s food delivery platform, handling millions of concurrent users.',
      requirements: [
        'Bachelor\'s degree in Computer Science or related field',
        'Proficiency in Java, Go, or Python',
        'Experience with microservices architecture',
        'Knowledge of database systems and caching mechanisms'
      ],
      applicationUrl: 'https://careers.swiggy.com',
      postedDate: new Date('2023-06-01'),
      deadline: new Date('2023-07-01'),
      matchPercentage: 71
    },
    {
      id: '6',
      title: 'DevOps Engineer',
      company: 'IBM',
      location: 'Hyderabad, India',
      salary: '₹8-16 LPA',
      description: 'Join IBM as a DevOps Engineer to automate and optimize infrastructure deployment and management for enterprise applications.',
      requirements: [
        'Bachelor\'s degree in Computer Science or related field',
        'Experience with CI/CD tools and methodologies',
        'Knowledge of cloud platforms (AWS, Azure, GCP)',
        'Scripting skills in Python, Bash, or PowerShell'
      ],
      applicationUrl: 'https://www.ibm.com/careers',
      postedDate: new Date('2023-05-28'),
      matchPercentage: 65
    }
  ];
  
  // Filter jobs based on search term and filters
  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                        job.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || job.title.toLowerCase().includes(filterRole.toLowerCase());
    const matchesLocation = filterLocation === 'all' || job.location.toLowerCase().includes(filterLocation.toLowerCase());
    
    return matchesSearch && matchesRole && matchesLocation;
  });
  
  // Sort jobs by match percentage
  const sortedJobs = [...filteredJobs].sort((a, b) => b.matchPercentage - a.matchPercentage);
  
  // Format date
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };
  
  // Calculate days remaining
  const getDaysRemaining = (deadline?: Date) => {
    if (!deadline) return null;
    
    const today = new Date();
    const daysRemaining = Math.ceil((deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysRemaining >= 0 ? daysRemaining : null;
  };
  
  const handleSaveJob = (jobId: string, jobTitle: string) => {
    toast({
      title: "Job saved",
      description: `${jobTitle} has been added to your saved jobs`,
      duration: 3000,
    });
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.4 }
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Job Recommendations</h1>
            <p className="text-gray-600 mt-1">
              Personalized job matches based on your profile and skills
            </p>
          </div>
          <Button asChild className="mt-4 md:mt-0">
            <Link to="/placement-prep">
              Back to Placement Prep
            </Link>
          </Button>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full lg:w-64 space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Filters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Job Role</label>
                  <Select value={filterRole} onValueChange={setFilterRole}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roles</SelectItem>
                      <SelectItem value="software">Software Engineer</SelectItem>
                      <SelectItem value="full stack">Full Stack Developer</SelectItem>
                      <SelectItem value="data">Data Scientist</SelectItem>
                      <SelectItem value="frontend">Frontend Developer</SelectItem>
                      <SelectItem value="backend">Backend Engineer</SelectItem>
                      <SelectItem value="devops">DevOps Engineer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">Location</label>
                  <Select value={filterLocation} onValueChange={setFilterLocation}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Locations</SelectItem>
                      <SelectItem value="bangalore">Bangalore</SelectItem>
                      <SelectItem value="hyderabad">Hyderabad</SelectItem>
                      <SelectItem value="delhi">Delhi NCR</SelectItem>
                      <SelectItem value="mumbai">Mumbai</SelectItem>
                      <SelectItem value="pune">Pune</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="skills">
                    <AccordionTrigger className="text-sm font-medium">Skills</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <input type="checkbox" id="skill-java" className="mr-2" />
                          <label htmlFor="skill-java" className="text-sm">Java</label>
                        </div>
                        <div className="flex items-center">
                          <input type="checkbox" id="skill-python" className="mr-2" />
                          <label htmlFor="skill-python" className="text-sm">Python</label>
                        </div>
                        <div className="flex items-center">
                          <input type="checkbox" id="skill-javascript" className="mr-2" />
                          <label htmlFor="skill-javascript" className="text-sm">JavaScript</label>
                        </div>
                        <div className="flex items-center">
                          <input type="checkbox" id="skill-react" className="mr-2" />
                          <label htmlFor="skill-react" className="text-sm">React</label>
                        </div>
                        <div className="flex items-center">
                          <input type="checkbox" id="skill-sql" className="mr-2" />
                          <label htmlFor="skill-sql" className="text-sm">SQL</label>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="salary">
                    <AccordionTrigger className="text-sm font-medium">Salary Range</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <input type="checkbox" id="salary-0-10" className="mr-2" />
                          <label htmlFor="salary-0-10" className="text-sm">₹0-10 LPA</label>
                        </div>
                        <div className="flex items-center">
                          <input type="checkbox" id="salary-10-20" className="mr-2" />
                          <label htmlFor="salary-10-20" className="text-sm">₹10-20 LPA</label>
                        </div>
                        <div className="flex items-center">
                          <input type="checkbox" id="salary-20-30" className="mr-2" />
                          <label htmlFor="salary-20-30" className="text-sm">₹20-30 LPA</label>
                        </div>
                        <div className="flex items-center">
                          <input type="checkbox" id="salary-30+" className="mr-2" />
                          <label htmlFor="salary-30+" className="text-sm">₹30+ LPA</label>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
                
                <Button variant="outline" className="w-full">
                  <Filter className="h-4 w-4 mr-2" />
                  Apply Filters
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Your Profile Match</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-blue-50 rounded-md">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-blue-800">Match Score</span>
                    <Badge className="bg-blue-600">85%</Badge>
                  </div>
                  <div className="text-sm text-blue-700 mb-4">Your profile is a strong match for Software Engineering roles!</div>
                  <Button size="sm" variant="outline" className="w-full">
                    Update Profile
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Main Content */}
          <div className="flex-1">
            <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
              <div className="flex flex-col md:flex-row gap-4 items-stretch">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search job titles, companies..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline">
                      Sort By
                      <ChevronDown className="h-4 w-4 ml-2" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56">
                    <DropdownMenuGroup>
                      <DropdownMenuItem>
                        Match Percentage (High to Low)
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        Date Posted (Newest First)
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        Salary (High to Low)
                      </DropdownMenuItem>
                    </DropdownMenuGroup>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
            
            {sortedJobs.length > 0 ? (
              <motion.div 
                className="space-y-6"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {sortedJobs.map((job) => (
                  <motion.div key={job.id} variants={itemVariants}>
                    <Card className="overflow-hidden hover:shadow-md transition-all">
                      <div className={`h-1 ${
                        job.matchPercentage > 90 ? 'bg-green-500' :
                        job.matchPercentage > 80 ? 'bg-blue-500' :
                        job.matchPercentage > 70 ? 'bg-amber-500' : 'bg-gray-500'
                      }`}></div>
                      <CardHeader className="pb-2 flex flex-row justify-between items-start">
                        <div>
                          <div className="flex items-center">
                            <Badge variant="outline" className="mr-2">{job.matchPercentage}% Match</Badge>
                            {job.deadline && getDaysRemaining(job.deadline) !== null && getDaysRemaining(job.deadline)! < 5 && (
                              <Badge className="bg-red-100 text-red-800 hover:bg-red-200 border-red-200">
                                {getDaysRemaining(job.deadline)} days left
                              </Badge>
                            )}
                          </div>
                          <CardTitle className="mt-2">{job.title}</CardTitle>
                          <div className="flex items-center mt-1 text-gray-500 text-sm">
                            <Building className="h-4 w-4 mr-1" />
                            <span>{job.company}</span>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => handleSaveJob(job.id, job.title)}
                          className="h-8 w-8"
                        >
                          <Bookmark className="h-4 w-4" />
                        </Button>
                      </CardHeader>
                      <CardContent className="pb-4">
                        <div className="flex flex-wrap gap-4 text-sm mb-4">
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 text-gray-500 mr-1" />
                            <span>{job.location}</span>
                          </div>
                          {job.salary && (
                            <div className="flex items-center">
                              <DollarSign className="h-4 w-4 text-gray-500 mr-1" />
                              <span>{job.salary}</span>
                            </div>
                          )}
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 text-gray-500 mr-1" />
                            <span>Posted {formatDate(job.postedDate)}</span>
                          </div>
                        </div>
                        
                        <p className="text-gray-700 mb-4 line-clamp-2">{job.description}</p>
                        
                        <div className="mb-3">
                          <h4 className="text-sm font-medium mb-2">Key Requirements</h4>
                          <ul className="list-disc list-inside space-y-1">
                            {job.requirements.slice(0, 2).map((req, idx) => (
                              <li key={idx} className="text-sm text-gray-600">{req}</li>
                            ))}
                            {job.requirements.length > 2 && (
                              <li className="text-sm text-gray-500">+ {job.requirements.length - 2} more requirements</li>
                            )}
                          </ul>
                        </div>
                      </CardContent>
                      <CardFooter className="border-t pt-4 flex justify-between">
                        <div className="flex space-x-2">
                          <Badge 
                            variant="outline" 
                            className="bg-blue-50 border-blue-200 text-blue-800 hover:bg-blue-100"
                          >
                            <Tag className="h-3 w-3 mr-1" /> New Grad
                          </Badge>
                          <Badge 
                            variant="outline" 
                            className="bg-green-50 border-green-200 text-green-800 hover:bg-green-100"
                          >
                            <Award className="h-3 w-3 mr-1" /> Top Company
                          </Badge>
                        </div>
                        <Button>
                          Apply Now <ExternalLink className="h-4 w-4 ml-2" />
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <div className="text-center py-16 bg-white rounded-lg border">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-4">
                  <Briefcase className="h-8 w-8 text-blue-600" />
                </div>
                <h2 className="text-xl font-bold">No jobs found</h2>
                <p className="text-gray-500 mt-2 mb-4">Try adjusting your filters or search terms</p>
                <Button onClick={() => { setSearchTerm(''); setFilterLocation('all'); setFilterRole('all'); }}>
                  Clear Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default JobRecommendationPage;
