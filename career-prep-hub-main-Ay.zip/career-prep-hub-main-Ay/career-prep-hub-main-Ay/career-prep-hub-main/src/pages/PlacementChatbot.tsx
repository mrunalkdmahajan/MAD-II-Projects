
import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, RefreshCw, Bookmark } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Card, 
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle 
} from '@/components/ui/card';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import axios from 'axios';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'bot';
  timestamp: Date;
}

const PlacementChatbot = () => {
  const { toast } = useToast();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [userInput, setUserInput] = useState("");
  const [botResponse, setBotResponse] = useState<string>("");
  
  // Sample suggested questions
  const suggestedQuestions = [
    "What are the important DSA topics for placements?",
    "How to prepare for technical interviews?",
    "Which companies hire freshers regularly?",
    "What's the typical placement process?",
    "How to improve my resume for tech roles?"
  ];
  
  // Sample recommended resources
  const recommendedResources = [
    {
      title: "LeetCode Problems",
      description: "Practice coding problems for technical interviews",
      link: "https://leetcode.com"
    },
    {
      title: "System Design Primer",
      description: "Learn system design concepts for interviews",
      link: "https://github.com/donnemartin/system-design-primer"
    },
    {
      title: "Cracking the Coding Interview",
      description: "Popular book for interview preparation",
      link: "#"
    }
  ];
  
  useEffect(() => {
    // Initial bot message
    const initialMessage: Message = {
      id: Date.now().toString(),
      content: "Hello! I'm your placement preparation assistant. How can I help you today? You can ask about placement processes, interview preparation, or any specific topics you'd like to learn about.",
      role: 'bot',
      timestamp: new Date()
    };
    
    setMessages([initialMessage]);
  }, []);
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (input.trim() === '') return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input.trim(),
      role: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Await the bot response
      const botResponse = await generateBotResponse(input.trim());

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: botResponse,
        role: 'bot',
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error("Error fetching bot response:", error);
    } finally {
      setIsLoading(false);
    }
};


  
  const handleSuggestedQuestion = (question: string) => {
    setInput(question);
    handleSendMessage();
  };
  
  const generateBotResponse = async (userInput: string): Promise<string> => {
    // Simple pattern matching for demo purposes
    const API_KEY = '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'; // Replace with your actual Groq API key
    const API_URL = 'https://api.groq.com/openai/v1/chat/completions'; // Replace with the actual Groq API URL if different

    try {
        const response = await axios.post(
            API_URL,
            {
                model: 'llama3-8b-8192', // Change the model if needed
                messages: [{ role: 'user', content: userInput }],
            },
            {
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        return response.data.choices[0]?.message?.content || "No response generated.";
    } catch (error) {
        console.error('Error fetching response:', error);
        return "An error occurred while generating the response.";
    }
};

  const saveResource = (title: string) => {
    toast({
      title: "Resource saved",
      description: `${title} has been saved to your bookmarks`,
      duration: 3000,
    });
  };

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Placement Chatbot</h1>
            <p className="text-gray-600 mt-1">
              Get guidance on placement preparation and interview processes
            </p>
          </div>
          <Button asChild>
            <Link to="/placement-prep">
              Back to Placement Prep
            </Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="border shadow-sm h-[calc(100vh-16rem)]">
              <CardHeader className="p-4 border-b">
                <CardTitle className="flex items-center text-lg font-medium">
                  <Bot className="h-5 w-5 mr-2 text-blue-600" />
                  Placement Assistant
                </CardTitle>
                <CardDescription>
                  Ask questions about placement processes, interview preparation, and more
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0 overflow-hidden flex flex-col h-[calc(100%-8rem)]">
                <div className="flex-1 overflow-y-auto p-4">
                  <AnimatePresence initial={false}>
                    {messages.map((message) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className={`flex mb-4 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`flex gap-3 max-w-[80%] ${message.role === 'user' ? 'flex-row-reverse' : ''}`}>
                          <Avatar className={`h-8 w-8 ${message.role === 'bot' ? 'bg-blue-100' : 'bg-gray-100'}`}>
                            {message.role === 'bot' ? (
                              <Bot className="h-4 w-4 text-blue-600" />
                            ) : (
                              <User className="h-4 w-4 text-gray-600" />
                            )}
                          </Avatar>
                          <div>
                            <div 
                              className={`p-3 rounded-lg ${
                                message.role === 'bot' 
                                  ? 'bg-white border border-gray-200' 
                                  : 'bg-blue-600 text-white'
                              }`}
                            >
                              <div className="whitespace-pre-line">{message.content}</div>
                            </div>
                            <div className="text-xs text-gray-500 mt-1 px-1">
                              {new Date(message.timestamp).toLocaleTimeString([], { 
                                hour: '2-digit', 
                                minute: '2-digit' 
                              })}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                    
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex mb-4"
                      >
                        <div className="flex gap-3 max-w-[80%]">
                          <Avatar className="h-8 w-8 bg-blue-100">
                            <Bot className="h-4 w-4 text-blue-600" />
                          </Avatar>
                          <div className="p-3 rounded-lg bg-white border border-gray-200">
                            <div className="flex space-x-2">
                              <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                              <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '200ms' }}></div>
                              <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '400ms' }}></div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                    <div ref={messagesEndRef} />
                  </AnimatePresence>
                </div>
              </CardContent>
              <CardFooter className="p-4 border-t">
                <form onSubmit={handleSendMessage} className="w-full flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Type your message here..."
                    className="flex-1"
                    disabled={isLoading}
                  />
                  <Button type="submit" disabled={isLoading || input.trim() === ''}>
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </CardFooter>
            </Card>
          </div>
          
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Suggested Questions</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  {suggestedQuestions.map((question, idx) => (
                    <Button 
                      key={idx} 
                      variant="outline" 
                      className="w-full justify-start text-left h-auto py-2"
                      onClick={() => handleSuggestedQuestion(question)}
                    >
                      {question}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recommended Resources</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  {recommendedResources.map((resource, idx) => (
                    <div key={idx} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="font-medium">{resource.title}</h4>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => saveResource(resource.title)}
                        >
                          <Bookmark className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-sm text-gray-500 mb-2">{resource.description}</p>
                      <a 
                        href={resource.link} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 hover:underline"
                      >
                        View Resource
                      </a>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default PlacementChatbot;
