
import { useState, useRef, useEffect } from "react";

export default function InterviewPage() {
  const dummyQuestions = [
    "What is the time complexity of QuickSort?",
    "Explain the difference between TCP and UDP.",
    "What are the different types of database normalization?",
    "How does a hashmap work internally in Java?",
    "What are the four principles of OOP?",
  ];

  const [questions] = useState(dummyQuestions);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [studentAnswer, setStudentAnswer] = useState("");
  const [qnaPairs, setQnaPairs] = useState<{ question: string; answer: string }[]>([]);
  const [interviewStarted, setInterviewStarted] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaStream = useRef<MediaStream | null>(null);
  const recognition = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    if (interviewStarted) {
      startInterview();
    }
  }, [interviewStarted]);

  const startInterview = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      mediaStream.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.muted = true;
      }
      setInterviewStarted(true);
    } catch (error) {
      console.error("Error accessing camera:", error);
    }
  };

  const startVoiceRecognition = () => {
    if (!("webkitSpeechRecognition" in window)) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (!recognition.current) {
      recognition.current = new (window as any).webkitSpeechRecognition();
      recognition.current.lang = "en-US";
      recognition.current.continuous = true;
      recognition.current.interimResults = true;
    }

    recognition.current.onresult = (event: any) => {
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript + " ";
      }
      setStudentAnswer(transcript.trim());
    };

    recognition.current.start();
  };

  const stopVoiceRecognition = () => {
    recognition.current?.stop();
  };

  const finishAnswer = () => {
    stopVoiceRecognition();
    setQnaPairs([...qnaPairs, { question: questions[currentQuestionIndex], answer: studentAnswer }]);
    setStudentAnswer("");

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const submitInterview = async () => {
    // const apiKey = process.env.NEXT_PUBLIC_GROQ_API_KEY;
    const apiKey = "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";
    console.log(apiKey)
    if (!apiKey) {
      console.error("Groq API key is missing!");
      return;
    }

    try {
      console.log(qnaPairs);
      
      const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "llama3-8b-8192",
          messages: [
            {
              role: "system",
              content: "Review the interview answers , each quesrion on different line , with a focus on both technincal and speaking skills. Analyze correctness, confidence, fluency, and filler words. Format:",
            },
            {
              role: "user",
              content: qnaPairs
                .map(({ question, answer }) => `Question: ${question}\nAnswer: ${answer}`)
                .join("\n\n"),
            },
          ],
        }),
      });

      const data = await response.json();
      console.log("Groq API Response:", data);

      if (response.ok && data.choices) {
        setResult(data.choices[0].message.content);
      } else {
        console.error("Groq API Error:", data);
      }
    } catch (error) {
      console.error("Error submitting interview:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center p-6">
      <h1 className="text-2xl font-bold text-blue-600 mb-4">AI Interview Practice</h1>

      {!interviewStarted ? (
        <button onClick={startInterview} className="w-full max-w-sm bg-blue-500 text-white p-3 rounded-md hover:bg-blue-600">
          Start Interview
        </button>
      ) : (
        <div className="bg-white p-6 shadow-md rounded-lg w-full max-w-xl">
          <video ref={videoRef} autoPlay className="w-full h-64 bg-black rounded-md mb-4" />
          <p className="text-lg font-semibold">{questions[currentQuestionIndex]}</p>

          <button onClick={startVoiceRecognition} className="w-full bg-green-500 text-white p-2 rounded-md hover:bg-green-600 mt-4">
            Start Answering (Voice)
          </button>

          {studentAnswer && <p className="mt-4 p-2 bg-gray-100 border rounded-md">{studentAnswer}</p>}

          <button onClick={finishAnswer} className="w-full bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600 mt-4">
            Finish Answer & Next Question
          </button>

          <button onClick={submitInterview} className="w-full bg-purple-500 text-white p-3 rounded-md hover:bg-purple-600 mt-6">
            Submit Interview
          </button>

          {result && (
            <div className="mt-6 p-4 bg-gray-100 rounded-lg w-full max-w-xl">
              <h3 className="text-xl font-bold text-green-700 mb-2">AI Review:</h3>
              <pre className="p-3 bg-gray-200 text-gray-800 rounded-md text-sm overflow-auto max-h-auto">{result}</pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
