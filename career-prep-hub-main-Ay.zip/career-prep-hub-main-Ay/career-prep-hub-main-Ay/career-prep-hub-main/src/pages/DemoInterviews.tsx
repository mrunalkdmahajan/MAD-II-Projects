
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Video, 
  Play, 
  Clock, 
  Building, 
  User, 
  Calendar, 
  ArrowLeft, 
  BookOpen,
  ChevronRight
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { DemoInterview } from '@/types';

const DemoInterviews = () => {
  const [activeTab, setActiveTab] = useState<string>('technical');
  
  // Mock data for demo interviews
  const interviews: Record<string, DemoInterview[]> = {
    technical: [
      {
        id: '1',
        title: 'Google Software Engineer Interview',
        description: 'Learn how to tackle Google\'s technical interview rounds with this comprehensive simulation.',
        duration: 45,
        company: 'Google',
        role: 'Software Engineer',
        videoUrl: 'https://example.com/video1',
        questions: [
          {
            id: '1-1',
            question: 'Implement a function to check if a binary tree is balanced.',
            tips: [
              'Consider using a recursive approach',
              'Think about the height of subtrees',
              'You can use a bottom-up approach to improve efficiency'
            ]
          },
          {
            id: '1-2',
            question: 'Given an array of integers, find all unique triplets that sum up to zero.',
            tips: [
              'Sort the array first',
              'Use two pointers technique',
              'Be careful about duplicates'
            ]
          }
        ]
      },
      {
        id: '2',
        title: 'Microsoft Backend Developer Interview',
        description: 'Practice system design and coding for Microsoft backend roles.',
        duration: 60,
        company: 'Microsoft',
        role: 'Backend Developer',
        videoUrl: 'https://example.com/video2',
        questions: [
          {
            id: '2-1',
            question: 'Design a URL shortening service like bit.ly.',
            tips: [
              'Consider scale requirements',
              'Think about the encoding algorithm',
              'Discuss database schema'
            ]
          },
          {
            id: '2-2',
            question: 'Explain how you would implement a rate limiter for an API.',
            tips: [
              'Consider different rate limiting algorithms',
              'Discuss distributed systems considerations',
              'Think about error responses'
            ]
          }
        ]
      },
      {
        id: '3',
        title: 'Amazon Full Stack Developer Interview',
        description: 'Comprehensive practice for Amazon\'s coding and system design questions.',
        duration: 55,
        company: 'Amazon',
        role: 'Full Stack Developer',
        videoUrl: 'https://example.com/video3',
        questions: [
          {
            id: '3-1',
            question: 'Design an e-commerce shopping cart system.',
            tips: [
              'Consider user sessions and persistence',
              'Discuss inventory management integration',
              'Think about payment processing'
            ]
          }
        ]
      }
    ],
    hr: [
      {
        id: '4',
        title: 'Behavioral Interview Preparation',
        description: 'Learn how to answer common behavioral questions using the STAR method.',
        duration: 30,
        company: 'Multiple',
        role: 'Various',
        videoUrl: 'https://example.com/video4',
        questions: [
          {
            id: '4-1',
            question: 'Tell me about a time when you faced a challenge and how you overcame it.',
            tips: [
              'Use the STAR method: Situation, Task, Action, Result',
              'Be specific with your example',
              'Focus on your personal contribution'
            ]
          },
          {
            id: '4-2',
            question: 'Describe a situation where you had to work with a difficult team member.',
            tips: [
              'Focus on the resolution, not the conflict',
              'Highlight communication skills',
              'Emphasize positive outcomes'
            ]
          }
        ]
      },
      {
        id: '5',
        title: 'Common HR Interview Questions',
        description: 'Practice answering frequently asked HR and cultural fit questions.',
        duration: 25,
        company: 'Multiple',
        role: 'Various',
        videoUrl: 'https://example.com/video5',
        questions: [
          {
            id: '5-1',
            question: 'Why do you want to work for our company?',
            tips: [
              'Research the company beforehand',
              'Connect company values to your own',
              'Be specific about what attracts you'
            ]
          }
        ]
      }
    ],
    system: [
      {
        id: '6',
        title: 'System Design Fundamentals',
        description: 'Learn key concepts for system design interviews at tech companies.',
        duration: 60,
        company: 'Multiple',
        role: 'Senior Developer',
        videoUrl: 'https://example.com/video6',
        questions: [
          {
            id: '6-1',
            question: 'Design a distributed caching system.',
            tips: [
              'Consider consistency vs. availability',
              'Discuss cache invalidation strategies',
              'Think about failure scenarios'
            ]
          }
        ]
      },
      {
        id: '7',
        title: 'Designing Scalable Systems',
        description: 'Practice designing systems that can scale to millions of users.',
        duration: 75,
        company: 'Multiple',
        role: 'Senior Engineer',
        videoUrl: 'https://example.com/video7',
        questions: [
          {
            id: '7-1',
            question: 'Design a video streaming service like YouTube.',
            tips: [
              'Consider CDN architecture',
              'Discuss transcoding pipeline',
              'Think about metadata storage'
            ]
          }
        ]
      }
    ]
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.4 }
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Demo Interviews</h1>
            <p className="text-gray-600 mt-1">
              Practice with realistic interview simulations from top companies
            </p>
          </div>
          <Button asChild>
            <Link to="/placement-prep">
              Back to Placement Prep
            </Link>
          </Button>
        </div>
        
        <Tabs defaultValue="technical" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-8">
            <TabsTrigger value="technical">Technical Interviews</TabsTrigger>
            <TabsTrigger value="hr">HR Interviews</TabsTrigger>
            <TabsTrigger value="system">System Design</TabsTrigger>
          </TabsList>
          
          {Object.entries(interviews).map(([category, interviewList]) => (
            <TabsContent key={category} value={category}>
              <motion.div 
                className="grid grid-cols-1 md:grid-cols-2 gap-6"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {interviewList.map((interview) => (
                  <motion.div key={interview.id} variants={itemVariants}>
                    <Card className="h-full hover:shadow-md transition-all">
                      <CardHeader className="pb-3">
                        {interview.company && (
                          <Badge className="w-fit mb-1" variant="outline">
                            {interview.company}
                          </Badge>
                        )}
                        <CardTitle>{interview.title}</CardTitle>
                        <CardDescription>{interview.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-4">
                        <div className="flex flex-wrap gap-4 text-sm mb-4">
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 text-gray-500 mr-1" />
                            <span>{interview.duration} mins</span>
                          </div>
                          {interview.role && (
                            <div className="flex items-center">
                              <User className="h-4 w-4 text-gray-500 mr-1" />
                              <span>{interview.role}</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="border-t border-gray-100 pt-4">
                          <h4 className="text-sm font-medium mb-2">Sample Questions:</h4>
                          <ul className="space-y-3">
                            {interview.questions.slice(0, 2).map((question) => (
                              <li key={question.id} className="text-sm text-gray-700">
                                {question.question}
                              </li>
                            ))}
                            {interview.questions.length > 2 && (
                              <li className="text-xs text-gray-500">
                                + {interview.questions.length - 2} more questions
                              </li>
                            )}
                          </ul>
                        </div>
                      </CardContent>
                      <CardFooter>
                      <Link to="/intervie-page">
                        <Button className="w-full">
                          <Play className="h-4 w-4 mr-2" /> 
                          

                          
                            Start Interview
                          


                        </Button>
                        </Link>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            </TabsContent>
          ))}
          
          {!interviews[activeTab] || interviews[activeTab].length === 0 && (
            <div className="text-center py-16">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-4">
                <Video className="h-8 w-8 text-blue-600" />
              </div>
              <h2 className="text-xl font-bold">No interviews available</h2>
              <p className="text-gray-500 mt-2">Check back later for new interview scenarios</p>
            </div>
          )}
        </Tabs>
      </div>
    </DashboardLayout>
  );
};

export default DemoInterviews;
