
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Code, 
  Brain, 
  MessageSquare, 
  Calculator, 
  ChevronRight,
  Trophy,
  Clock,
  Flame
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Test, TestCategory } from '@/types';

// Define a local interface for the test data being used in this component
interface DisplayTest {
  id: string;
  title: string;
  description: string;
  timeLimit: number;
  questionsCount: number;
  difficulty: string;
  completed: boolean;
  score?: number;
  isMasterTest?: boolean;
}

const Tests = () => {
  const [activeTab, setActiveTab] = useState<TestCategory>('dsa');
  
  const categories = [
    {
      id: 'dsa',
      name: 'Data Structures & Algorithms',
      icon: <Code className="h-5 w-5" />,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      progress: 40,
    },
    {
      id: 'logical',
      name: 'Logical Reasoning',
      icon: <Brain className="h-5 w-5" />,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      progress: 65,
    },
    {
      id: 'verbal',
      name: 'Verbal Ability',
      icon: <MessageSquare className="h-5 w-5" />,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      progress: 30,
    },
    {
      id: 'qa',
      name: 'Quantitative Aptitude',
      icon: <Calculator className="h-5 w-5" />,
      color: 'text-amber-600',
      bgColor: 'bg-amber-50',
      progress: 50,
    },
  ];
  
  const getTestsForCategory = (category: TestCategory): DisplayTest[] => {
    // Here we define 5 regular tests and 1 master test for each category
    const tests = Array.from({ length: 5 }, (_, i) => ({
      id: `${category}-${i + 1}`,
      title: `${category.toUpperCase()} Test ${i + 1}`,
      description: `Practice ${getCategoryName(category)} concepts with our curated questions.`,
      timeLimit: category === 'dsa' ? 3600 : 1800, // DSA tests are longer
      questionsCount: category === 'dsa' ? 10 : 20,
      difficulty: i < 2 ? 'easy' : i < 4 ? 'medium' : 'hard',
      completed: i < 2,
      score: i < 2 ? Math.floor(Math.random() * 31) + 70 : undefined, // Random score between 70-100 for completed tests
    }));
    
    // Add the master test (6th test with shuffled questions)
    tests.push({
      id: `${category}-master`,
      title: `${category.toUpperCase()} Master Test`,
      description: `Comprehensive test covering all ${getCategoryName(category)} topics.`,
      timeLimit: category === 'dsa' ? 5400 : 2700,
      questionsCount: category === 'dsa' ? 15 : 30,
      difficulty: 'mixed',
      completed: false,
      isMasterTest: true,
    });
    
    return tests;
  };
  
  const getCategoryName = (category: TestCategory): string => {
    switch (category) {
      case 'dsa': return 'Data Structures & Algorithms';
      case 'logical': return 'Logical Reasoning';
      case 'verbal': return 'Verbal Ability';
      case 'qa': return 'Quantitative Aptitude';
    }
  };
  
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-50';
      case 'medium': return 'text-amber-600 bg-amber-50';
      case 'hard': return 'text-red-600 bg-red-50';
      case 'mixed': return 'text-purple-600 bg-purple-50';
    }
  };
  
  const tests = getTestsForCategory(activeTab);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.4 }
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Practice Tests</h1>
            <p className="text-gray-600 mt-1">
              Master key concepts with our comprehensive test series
            </p>
          </div>
          <Button asChild>
            <Link to="/placement-prep">
              Back to Placement Prep
            </Link>
          </Button>
        </div>

        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <h2 className="text-lg font-medium mb-4">Your Progress</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {categories.map(category => (
              <div 
                key={category.id} 
                className="bg-white rounded-lg border p-4 hover:shadow-md transition-shadow"
                onClick={() => setActiveTab(category.id as TestCategory)}
              >
                <div className="flex items-center mb-3">
                  <div className={`p-2 rounded-md ${category.bgColor}`}>
                    {category.icon}
                  </div>
                  <h3 className={`ml-2 font-medium ${category.color}`}>{category.name}</h3>
                </div>
                <Progress value={category.progress} className="h-2 mb-2" />
                <div className="flex justify-between text-sm text-gray-500">
                  <span>Progress</span>
                  <span>{category.progress}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as TestCategory)} className="w-full">
          <TabsList className="grid grid-cols-4 mb-8">
            {categories.map(category => (
              <TabsTrigger key={category.id} value={category.id} className="flex items-center">
                <span className={`mr-2 ${category.color}`}>{category.icon}</span>
                <span className="hidden md:inline">{category.name}</span>
                <span className="md:hidden">{category.id.toUpperCase()}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map(category => (
            <TabsContent key={category.id} value={category.id}>
              <motion.div 
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {getTestsForCategory(category.id as TestCategory).map((test) => (
                  <motion.div key={test.id} variants={itemVariants}>
                    <Card className={`h-full transition-all hover:shadow-md ${test.isMasterTest ? 'border-purple-200 bg-purple-50/30' : ''}`}>
                      <CardHeader>
                        {test.isMasterTest && (
                          <Badge className="w-fit mb-2 bg-purple-100 text-purple-800 hover:bg-purple-200 border-purple-200">
                            <Trophy className="h-3 w-3 mr-1" /> Master Test
                          </Badge>
                        )}
                        <CardTitle className="flex items-center">
                          {test.title}
                        </CardTitle>
                        <CardDescription>{test.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center space-x-4 text-sm">
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 text-gray-500 mr-1" />
                            <span>{Math.floor(test.timeLimit / 60)} mins</span>
                          </div>
                          <div className="flex items-center">
                            <MessageSquare className="h-4 w-4 text-gray-500 mr-1" />
                            <span>{test.questionsCount} questions</span>
                          </div>
                          <div>
                            <Badge className={`${getDifficultyColor(test.difficulty)}`}>
                              {test.difficulty}
                            </Badge>
                          </div>
                        </div>

                        {test.completed && (
                          <div className="mt-4 p-3 bg-green-50 border border-green-100 rounded-md">
                            <div className="flex items-center justify-between">
                              <div className="text-sm text-green-800 font-medium">Completed</div>
                              <div className="flex items-center">
                                <span className="text-sm font-bold mr-1">{test.score}%</span>
                                <Trophy className={`h-4 w-4 ${test.score && test.score > 80 ? 'text-amber-500' : 'text-gray-400'}`} />
                              </div>
                            </div>
                          </div>
                        )}
                      </CardContent>
                      <CardFooter>
                        <Button 
                          asChild 
                          variant={test.completed ? "outline" : "default"}
                          className="w-full"
                        >
                          <Link to={`/placement-prep/tests/${category.id}/${test.id}`}>
                            {test.completed ? 'Review Test' : 'Start Test'}
                            <ChevronRight className="h-4 w-4 ml-1" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </DashboardLayout>
  );
};

export default Tests;
