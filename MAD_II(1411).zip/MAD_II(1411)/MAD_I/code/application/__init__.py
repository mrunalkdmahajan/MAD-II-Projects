# from flask import Flask
# from app.extensions import db, mail, cache, celery
# from app.models import User, Sponsor, Influencer, Campaign, AdRequest, Role
# from app.routes import app_blueprint
# from flask_migrate import Migrate
# from celery_config import make_celery

# def create_app():
#     app = Flask(__name__)
#     app.config.from_object('config.Config')  # Ensure it loads the correct config class

#     # Initialize extensions
#     db.init_app(app)
#     mail.init_app(app)
#     cache.init_app(app)

#     # Initialize Celery using make_celery function
#     celery = make_celery(app)

#     # Register blueprints
#     app.register_blueprint(app_blueprint)

#     # Initialize Flask-Migrate
#     migrate = Migrate(app, db)

#     return app, celery  # Return both app and celery

# # # Initialize the app and celery
# #app, celery = create_app()

# # # Import routes after app initialization
# # from app import routes

