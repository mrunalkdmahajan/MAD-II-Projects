from flask_restful import Resource, Api, reqparse, fields, marshal
from flask_security import auth_required, roles_required, current_user
from flask import jsonify, session
from sqlalchemy import or_
from .models import Campaign, AdRequest, User, Influencer, Sponsor, db
from .instances import cache

# Initialize API
api = Api(prefix='/api')

# Request Parsers
campaign_parser = reqparse.RequestParser()
campaign_parser.add_argument('name', type=str, help='Campaign name is required', required=True)
campaign_parser.add_argument('description', type=str, help='Description is required', required=True)
campaign_parser.add_argument('budget', type=float, help='Budget is required', required=True)

ad_request_parser = reqparse.RequestParser()
ad_request_parser.add_argument('campaign_id', type=int, help='Campaign ID is required', required=True)
ad_request_parser.add_argument('messages', type=str, help='Messages are required', required=True)
ad_request_parser.add_argument('requirements', type=str, help='Requirements are required', required=True)
ad_request_parser.add_argument('payment_amount', type=float, help='Payment amount is required', required=True)

# Fields for marshalling
campaign_fields = {
    'id': fields.Integer,
    'name': fields.String,
    'description': fields.String,
    'budget': fields.Float,
    'created_at': fields.DateTime,
    'updated_at': fields.DateTime,
    'sponsor_id': fields.Integer
}

ad_request_fields = {
    'id': fields.Integer,
    'campaign_id': fields.Integer,
    'influencer_id': fields.Integer,
    'messages': fields.String,
    'requirements': fields.String,
    'payment_amount': fields.Float,
    'status': fields.String,
    'created_at': fields.DateTime,
    'updated_at': fields.DateTime
}

# API Resources
class CampaignAPI(Resource):
    @auth_required("token")
    @cache.cached(timeout=60)
    def get(self):
        """Get campaigns for the current sponsor."""
        sponsor_id = current_user.id
        campaigns = Campaign.query.filter_by(sponsor_id=sponsor_id).all()
        if campaigns:
            return marshal(campaigns, campaign_fields)
        return {"message": "No campaigns found"}, 404

    @auth_required("token")
    @roles_required("sponsor")
    def post(self):
        """Create a new campaign."""
        args = campaign_parser.parse_args()
        campaign = Campaign(
            name=args['name'],
            description=args['description'],
            budget=args['budget'],
            sponsor_id=current_user.id
        )
        db.session.add(campaign)
        db.session.commit()
        return {"message": "Campaign created successfully"}, 201


class AdRequestAPI(Resource):
    @auth_required("token")
    def get(self):
        """Get ad requests based on the user's role."""
        if "sponsor" in current_user.roles:
            ad_requests = AdRequest.query.filter_by(sponsor_id=current_user.id).all()
        elif "influencer" in current_user.roles:
            ad_requests = AdRequest.query.filter_by(influencer_id=current_user.id).all()
        else:
            return {"message": "Unauthorized access"}, 403

        if ad_requests:
            return marshal(ad_requests, ad_request_fields)
        return {"message": "No ad requests found"}, 404

    @auth_required("token")
    @roles_required("influencer")
    def post(self):
        """Create a new ad request."""
        args = ad_request_parser.parse_args()
        ad_request = AdRequest(
            campaign_id=args['campaign_id'],
            influencer_id=current_user.id,
            messages=args['messages'],
            requirements=args['requirements'],
            payment_amount=args['payment_amount'],
            status="Pending"
        )
        db.session.add(ad_request)
        db.session.commit()
        return {"message": "Ad request created successfully"}, 201


class MonthlyReport(Resource):
    def get(self, campaign_id):
        """Retrieve a monthly performance report for a campaign."""
        campaign = Campaign.query.get(campaign_id)
        if not campaign:
            return {'error': 'Campaign not found'}, 404

        completed_ads = AdRequest.query.filter_by(campaign_id=campaign_id, status='Completed').count()
        total_spent = 5000  # Replace with actual calculation logic
        remaining_balance = campaign.budget - total_spent

        return {
            'campaign': {
                'name': campaign.name,
                'start_date': campaign.start_date,
                'end_date': campaign.end_date,
                'budget': campaign.budget,
            },
            'performance': {
                'completed_ads': completed_ads,
                'sales_growth': 10,
                'engagement_stats': "500 views, 100 clicks",
                'total_spent': total_spent,
                'remaining_balance': remaining_balance
            }
        }, 200


class GenerateReport(Resource):
    def get(self):
        """Generate a summary report for all campaigns."""
        campaigns = Campaign.query.all()
        report_data = []
        for campaign in campaigns:
            completed_ads_count = AdRequest.query.filter_by(campaign_id=campaign.id, status='Completed').count()
            total_spent = 5000  # Example value
            remaining_balance = campaign.budget - total_spent

            report_data.append({
                'campaign_name': campaign.name,
                'start_date': campaign.start_date,
                'end_date': campaign.end_date,
                'visibility': campaign.visibility,
                'completed_ads_count': completed_ads_count,
                'total_spent': total_spent,
                'remaining_balance': remaining_balance
            })

        return {'report_data': report_data}, 200


class UserProfile(Resource):
    @auth_required
    def get(self):
        """Retrieve the profile for the current user."""
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        if not user:
            return {'error': 'User not found'}, 404

        if user.user_type == 'Influencer':
            influencer = Influencer.query.filter_by(user_id=user.id).first()
            ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id).all()
            return {
                'user': {
                    'name': influencer.name,
                    'email': user.email,
                    'last_visited': influencer.last_visited,
                },
                'ad_requests': [
                    {'id': ad.id, 'status': ad.status} for ad in ad_requests
                ]
            }, 200

        elif user.user_type == 'Sponsor':
            sponsor = Sponsor.query.filter_by(user_id=user.id).first()
            return {
                'user': {
                    'company_name': sponsor.company_name,
                    'email': user.email,
                    'last_visited': sponsor.last_visited,
                }
            }, 200


# Add API Resources
api.add_resource(CampaignAPI, '/campaigns')
api.add_resource(AdRequestAPI, '/ad_requests')
api.add_resource(MonthlyReport, '/monthly_report/<int:campaign_id>')
api.add_resource(GenerateReport, '/generate_report')
api.add_resource(UserProfile, '/profile')
