# # from celery import Celery, Task

# # def celery_init_app(app):
# #     class FlaskTask(Task):
# #         def __call__(self, *args: object, **kwargs: object) -> object:
# #             with app.app_context():
# #                 return self.run(*args, **kwargs)

# #     celery_app = Celery(app.name, task_cls=FlaskTask)
# #     celery_app.config_from_object("celeryconfig")
# #     return celery_app

# from celery import Celery, Task

# # Define FlaskTask class globally so Celery can pickle it
# class FlaskTask(Task):
#     def __call__(self, *args, **kwargs):
#         with self.app.app_context():
#             return self.run(*args, **kwargs)

# def celery_init_app(app):
#     celery_app = Celery(app.name, task_cls=FlaskTask)
#     celery_app.config_from_object("celeryconfig")  # Load Celery config from 'celeryconfig.py'
#     return celery_app

from celery import Celery, Task

# Define FlaskTask class globally so Celery can pickle it
class FlaskTask(Task):
    def __call__(self, *args, **kwargs):
        # Explicitly use the Flask app passed to Celery
        with self.app.flask_app.app_context():  
            return self.run(*args, **kwargs)

def celery_init_app(app):
    # Initialize Celery and configure it with the Flask app context
    celery_app = Celery(app.name, task_cls=FlaskTask)
    celery_app.config_from_object("celeryconfig")  # Load Celery config from 'celeryconfig.py'
    
    # Store the Flask app within the Celery app for context access in tasks
    celery_app.flask_app = app
    
    return celery_app
