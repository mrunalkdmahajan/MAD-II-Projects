from io import StringIO
from mailbox import Message
from pathlib import Path
import random
from celery import shared_task
from .models import User, db, Role, Sponsor, Influencer, Campaign, AdRequest
import flask_excel as excel
from .mail_service import send_message
from jinja2 import Template

import csv
import os
from datetime import datetime
# Folder where the CSV export will be stored
import uuid
#import os
import csv
from datetime import datetime
from application.models import Campaign, AdRequest  # Ensure these models are correctly imported

# from datetime import datetime
# from jinja2 import Template
# from celery import shared_task
# from application.models import Sponsor, Campaign, AdRequest
# from application.mail_service import send_message

@shared_task(ignore_result=False)
def generate_and_send_monthly_report():
    """
    Generates a monthly report for sponsors and sends it via email.
    """
    # Get the current month and year
    current_month = datetime.now().month
    current_year = datetime.now().year

    # Fetch all sponsors
    sponsors = Sponsor.query.all()

    for sponsor in sponsors:
        # Fetch campaigns associated with the sponsor
        campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()

        report_data = []
        for campaign in campaigns:
            # Get the completed ad requests for the current campaign
            completed_ads_count = AdRequest.query.filter_by(
                campaign_id=campaign.id, status='Completed'
            ).count()

            # Placeholder for sales growth (replace with actual logic)
            sales_growth = round(random.uniform(1, 20), 2)  # Example placeholder

            # Engagement stats
            views = random.randint(100, 1000)
            clicks = random.randint(10, 200)
            engagement_stats = f"{views} views, {clicks} clicks"

            # Budget overview
            total_spent = 5000  # Replace with real calculation
            remaining_balance = campaign.budget - total_spent

            # Collect campaign data
            report_data.append({
                "campaign_name": campaign.name,
                "start_date": campaign.start_date,
                "end_date": campaign.end_date,
                "completed_ads_count": completed_ads_count,
                "sales_growth": sales_growth,
                "engagement_stats": engagement_stats,
                "total_spent": total_spent,
                "remaining_balance": remaining_balance,
            })

        # Load the HTML template for the report
        with open('application/monthly_report.html', 'r') as template_file:
            template = Template(template_file.read())
            html_content = template.render(
                current_month=current_month,
                current_year=current_year,
                report_data=report_data,
                sponsor_id=sponsor.id
            )

        # Send the email
        subject = f"Monthly Report - {current_month}/{current_year}"
        send_message(sponsor.email, subject, html_content)

    return "Monthly reports sent to sponsors."




@shared_task(ignore_result=True)
def daily_reminder(to, subject):
    users = User.query.filter(User.user_type == 'Admin').all()
    for user in users:
        with open('application/test.html', 'r') as f:
            template = Template(f.read())
            send_message(user.u_email, subject,
                         template.render(email=user.u_email))
    return "OK"


@shared_task(ignore_result=False)
def say_hello():
    return "say hello"


@shared_task(ignore_result=False)
def check_influencer_reminder():
    # Get current date and time to determine when to send reminders
    current_time = datetime.now()

    # Fetch influencers who have pending ad requests
    influencers = Influencer.query.all()

    for influencer in influencers:
        # Check for pending ad requests (status is not 'Accepted' or 'Rejected')
        pending_requests = AdRequest.query.filter_by(influencer_id=influencer.id, status='Pending').count()

        # If there are pending requests, send the reminder email
        if pending_requests > 0:
            send_reminder_email(influencer)
    
    return "Reminder emails sent to influencers"

def send_reminder_email(influencer):
    subject = "Reminder: Pending Ad Requests"

    # Render the email template and send the reminder
    with open('application/reminder_template.html', 'r') as f:
        template = Template(f.read())
        send_message(influencer.email, subject, template.render(influencer=influencer))



# import csv
# from io import StringIO


# @shared_task(ignore_result=False)
# def export_campaigns_as_csv(sponsor_id):
#     """
#     Generate a CSV for the sponsor's campaigns and send an email notification.
#     """
#     # Fetch sponsor from the database
#     sponsor = Sponsor.query.get(sponsor_id)

#     if not sponsor:
#         return "Sponsor not found"

#     # Fetch all campaigns associated with the sponsor
#     campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()

#     # Create CSV content in memory
#     output = StringIO()
#     writer = csv.writer(output)

#     # Write header row
#     writer.writerow(['Campaign Name', 'Description', 'Start Date', 'End Date', 'Budget', 'Visibility', 'Goals'])

#     # Write each campaign data into the CSV
#     for campaign in campaigns:
#         writer.writerow([
#             campaign.name,
#             campaign.description,
#             campaign.start_date,
#             campaign.end_date,
#             campaign.budget,
#             campaign.visibility,  # Public/Private
#             campaign.goals
#         ])

#     # Reset cursor to the beginning of the StringIO object
#     output.seek(0)
#     csv_content = output.getvalue()

#     # Prepare email content using Jinja2 template
#     with open('application/csv_report_notification_template.html', 'r') as f:
#         template = Template(f.read())
#         html_content = template.render(
#             sponsor_name=sponsor.name,
#             current_date=datetime.now().strftime('%Y-%m-%d'),
#             total_campaigns=len(campaigns)
#         )

#     # Set the subject of the email
#     subject = f"Campaigns CSV Report - {datetime.now().strftime('%Y-%m-%d')}"

#     # Send the email with the notification
#     send_message(
#         sponsor.email, 
#         subject,
#         html_content
#     )

#     return f"CSV report notification sent to {sponsor.email}"
