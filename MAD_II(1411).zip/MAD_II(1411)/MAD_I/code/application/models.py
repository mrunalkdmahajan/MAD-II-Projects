# #from app import app
# from app.extensions import db
# from sqlalchemy.dialects.mysql import ENUM
# from flask_migrate import Migrate

# #from extensions import db

# db = SQLAlchemy(app)
# # Initialize Flask-Migrate
# migrate = Migrate(app, db)
# # from extensions import db
# from sqlalchemy.sql import func
# # from werkzeug.security import generate_password_hash

#from app.extensions import db
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import JSON

from sqlalchemy.sql import func
from werkzeug.security import generate_password_hash
from flask_migrate import Migrate
from flask_security import UserMixin, RoleMixin
import uuid


db = SQLAlchemy()

# class User(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(32), unique=True, nullable=False)
#     passhash = db.Column(db.String(256), nullable=False)
#     name = db.Column(db.String(64), nullable=True)
#     user_type = db.Column(db.String(32), nullable=False)  # 'Admin', 'Sponsor', 'Influencer'
#     is_admin = db.Column(db.Boolean, nullable = False, default = False)
#     is_flagged = db.Column(db.Boolean, nullable = False, default = False)
#     created_at = db.Column(db.DateTime, server_default=func.now())
#     updated_at = db.Column(db.DateTime, onupdate=func.now())
    

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True, nullable=False)
    passhash = db.Column(db.String(256), nullable=False)
    name = db.Column(db.String(64), nullable=True)
    u_email = db.Column(db.String(120), unique=True, nullable=True)
    user_type = db.Column(db.String(32), nullable=False)  # 'Admin', 'Sponsor', 'Influencer'
    is_admin = db.Column(db.Boolean, nullable=False, default=False)
    is_flagged = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, onupdate=func.now())
    fs_uniquifier = db.Column(db.String(255), unique=True, nullable=False)
    active = db.Column(db.Boolean())
    
    roles = db.relationship('Role', secondary='roles_users',
                            backref=db.backref('users', lazy='dynamic'))  # Relationship with Role
    # Relationships for specific roles
    sponsor = db.relationship('Sponsor', back_populates='user', uselist=False)
    influencer = db.relationship('Influencer', back_populates='user', uselist=False)


    def __init__(self, **kwargs):
        super(User, self).__init__(**kwargs)
        if not self.fs_uniquifier:
            self.fs_uniquifier = str(uuid.uuid4())


class Role(db.Model, RoleMixin):
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(80), unique=True)
    description = db.Column(db.String(255))

class RolesUsers(db.Model):
    __tablename__ = 'roles_users'
    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey('user.id'))
    role_id = db.Column(db.Integer(), db.ForeignKey('role.id'))

class Sponsor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    company_name = db.Column(db.String(64), nullable=True)
    email = db.Column(db.String(64), unique=True, nullable=False)
    #category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable = False)
    industry = db.Column(db.String(64), nullable=True)
    budget = db.Column(db.Float, nullable=True)
    last_visited = db.Column(db.DateTime, nullable=True)
    
    user = db.relationship('User', back_populates='sponsor', uselist=False)
    # Sponsor can create multiple campaigns
    campaigns = db.relationship('Campaign', backref='sponsor', lazy=True)
    ad_requests = db.relationship('AdRequest', backref='sponsor', lazy=True)


class Influencer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(64), nullable=True)
    email = db.Column(db.String(64), unique=True, nullable=False)
    last_visited = db.Column(db.DateTime, nullable=True)
    # category = db.Column(db.String(64), nullable=True)
    niche = db.Column(db.String(64), nullable=True)
    #category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable = False)
    reach = db.Column(db.Integer, nullable=True) # follower count
    youtube = db.Column(db.String(32), nullable=True)
    twitter = db.Column(db.String(32), nullable=True)
    instagram = db.Column(db.String(32), nullable=True) 

    # Engagement Rate=( Total Engagements(likes, share, saves, views) / Total Followers)×100

    user = db.relationship('User', back_populates='influencer', uselist=False)
    # Influencer can have multiple ad requests
    ad_requests = db.relationship('AdRequest', backref='influencer', lazy=True)



class Campaign(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.String(256), nullable=True)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    budget = db.Column(db.Float, nullable=False)
    visibility = db.Column(db.String(32), nullable=False)  # 'public' or 'private'
    goals = db.Column(db.String(256), nullable=True)
    niche = db.Column(db.String(64), nullable=True)
    sponsor_id = db.Column(db.Integer, db.ForeignKey('sponsor.id'), nullable=False)
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, onupdate=func.now())
    is_flagged = db.Column(db.Boolean, nullable = False, default = False)

    # Campaign can have multiple ad requests
    ad_requests = db.relationship('AdRequest', backref='campaign', lazy=True, cascade="all, delete-orphan")
    

class AdRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaign.id'), nullable=False)
    influencer_id = db.Column(db.Integer, db.ForeignKey('influencer.id'), nullable=False)
    
    messages = db.Column(db.String(256), nullable=True)
    requirements = db.Column(db.String(256), nullable=True)
    payment_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(32), nullable=False)  # 'Pending', 'Accepted', 'Rejected'
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, onupdate=func.now())
    creater = db.Column(db.String(32), nullable=False)

    sponsor_id = db.Column(db.Integer, db.ForeignKey('sponsor.id'), nullable=False)

