import os
from flask import render_template, request, redirect, url_for, flash, session
# #from app import app
# #from app import Cache
# #from app.models import db, User, Sponsor, Influencer, Campaign, AdRequest
from sqlalchemy import func
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
# from datetime import datetime, timedelta
# from flask_migrate import Migrate
# # from utils import update_campaign_status, calculate_progress_percentage
# from flask import jsonify, Flask, request, send_file
# from flask_mail import Message
# from io import BytesIO, TextIOWrapper, StringIO
# import csv
# from app import celery, mail
# from flask import Blueprint, Response, request
# from app.models import Campaign
# from app.tasks import export_campaigns_task

# # Import extensions from extensions.py
# from app.extensions import db, celery, mail  # Use extensions here
# from app.models import User, Sponsor, Influencer, Campaign, AdRequest
# from app.tasks import export_campaigns_task
# from app import celery 

#from extensions import mail, db

# from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
# from flask_mail import Message
# from models import User, Sponsor, Influencer, Campaign, AdRequest
# #from extensions import mail, db
# from werkzeug.security import generate_password_hash, check_password_hash
# from functools import wraps
# from datetime import datetime, timedelta

# # # Create a blueprint
# bp = Blueprint('main', __name__)

# def send_reminder_email():
#     with mail.app.app_context():
#         influencers = Influencer.query.all()
#         for influencer in influencers:
#             pending_requests = AdRequest.query.filter_by(influencer_id=influencer.id, status='Pending').all()
#             if pending_requests or (influencer.last_visited and influencer.last_visited.date() < datetime.now().date()):
#                 # Compose the email
#                 msg = Message(
#                     "Reminder: Check your pending ad requests",
#                     recipients=[influencer.email]
#                 )
#                 msg.body = f"""
#                 Hi {influencer.name},

#                 You have pending ad requests or haven't visited our platform recently. 
#                 Please log in to review your requests or check out public ad requests.

#                 Best regards,
#                 Your Team
#                 """
#                 mail.send(msg)

from flask import Blueprint, Response, request
from application.models import Campaign
#from application.tasks import export_campaigns_task
from application.tasks import say_hello
from application.instances import cache

#app_blueprint = Blueprint('app', __name__)

from flask import current_app as app, jsonify, request, render_template, send_file
from flask_security import auth_required, roles_required
from werkzeug.security import check_password_hash
from flask_restful import marshal, fields
import flask_excel as excel
from celery.result import AsyncResult
#from .tasks import create_resource_csv
from .models import RolesUsers, User, db, Role, Sponsor, Influencer, Campaign, AdRequest
from .sec import datastore
from flask import jsonify, send_file
from celery.result import AsyncResult
# from application.tasks import generate_monthly_report

#from flask import render_template, redirect, url_for, request
#from application import app
#from application.models import Sponsor
#from application.tasks import export_campaigns_to_csv

# from flask import render_template, request, redirect, url_for
# from flask_login import current_user

# @app.route('/sponsor/<int:sponsor_id>/dashboard', methods=['GET', 'POST'])
# def sponsor_dashboard(sponsor_id):
#     sponsor = Sponsor.query.get_or_404(sponsor_id)
    
#     if request.method == 'POST':
#         # Trigger the export task when the sponsor clicks the "Export Campaigns" button
#         trigger_export_for_sponsor.apply_async(args=[sponsor_id])  # This triggers the task asynchronously
#         return redirect(url_for('dashboard_export_in_progress', sponsor_id=sponsor_id))

#     return render_template('sponsor_dashboard.html', sponsor=sponsor)

# @app.route('/sponsor/<int:sponsor_id>/export-in-progress')
# def dashboard_export_in_progress(sponsor_id):
#     # This page shows that the export is in progress
#     sponsor = Sponsor.query.get_or_404(sponsor_id)
#     return render_template('export_in_progress.html', sponsor=sponsor)

# @app.route('/sponsor/<int:sponsor_id>/export-complete/<task_id>')
# def export_complete(sponsor_id, task_id):
#     # Once the task is complete, provide a link to download the CSV
#     file_path = os.path.join(EXPORT_FOLDER, f"{task_id}.csv")
    
#     # Check if the file exists
#     if os.path.exists(file_path):
#         return render_template('sponsor/export_complete.html', sponsor=sponsor_id, file_path=file_path)
#     else:
#         return "Export failed or file not found.", 404

# # #from flask import Flask, jsonify, send_file
# from celery.result import AsyncResult


# @app.route('/export_campaigns/<int:sponsor_id>', methods=['GET'])
# def export_campaigns(sponsor_id):
#     # Trigger the Celery task to export the campaigns asynchronously
#     task = export_campaigns_to_csv.apply_async(args=[sponsor_id])
#     return jsonify({"task-id": task.id})  # Return the task ID to track progress

# @app.route('/get_report/<task_id>', methods=['GET'])
# def get_report(task_id):
#     # Check the status of the task by its ID
#     res = AsyncResult(task_id)
#     if res.ready():  # If task is complete
#         filename = res.result  # The result will be the file path
#         return send_file(filename, as_attachment=True)  # Send the file as an attachment
#     else:
#         return jsonify({"message": "Task Pending"}), 404  # If task is still processing


from flask import Blueprint, jsonify
from flask_login import login_required, current_user
#from .tasks import export_campaigns_as_csv

from functools import wraps
from flask import session, redirect, url_for, flash
from flask_login import current_user

# Define the custom authentication decorator
# def auth_required(func):
#     @wraps(func)
#     def inner(*args, **kwargs):
#         if current_user.is_authenticated:  # Check if the user is logged in via Flask-Login
#             return func(*args, **kwargs)
#         else:
#             flash('You must be logged in to access this page.', 'danger')
#             return redirect(url_for('login'))  # Redirect to login page if not logged in
#     return inner

# @app.route('/export-campaigns', methods=['POST'])
# @auth_required
# def export_campaigns():
#     if current_user.role != 'Sponsor':  # Check if the current user is a Sponsor
#         return jsonify({"error": "Unauthorized"}), 403

#     # Trigger the Celery task
#     task = export_campaigns_as_csv.delay(current_user.id)
#     return jsonify({
#         "message": "Export job triggered successfully.",
#         "task_id": task.id
#     }), 202



@app.route('/say_hello', methods=['GET'])
def say_hello_view():
    print("hello")
    t=say_hello.delay()
    return jsonify({"task-id":t.id})

# @app.route('/generate_monthly_report')
# def generate_monthly_report_view():
#     # Trigger the report generation task
#     task = generate_monthly_report.delay()
#     return jsonify({"task-id": task.id})  # Return the task ID to track progress

@app.route('/get_report/<task_id>')
def get_report(task_id):
    # Check the status of the task by its ID
    res = AsyncResult(task_id)
    if res.ready():  # If task is complete
        filename = res.result  # The result will be the file path
        return send_file(filename, as_attachment=True)  # Send the file as an attachment
    else:
        return jsonify({"message": "Task Pending"}), 404  # If task is still processing
    
# @app.route('/trigger-monthly-report')
# def trigger_monthly_report():
#     generate_monthly_report.apply_async()
#     return jsonify({"message": "Monthly report generation task triggered!"})


# @app.route('/export_campaigns', methods=['GET'])
# def export_campaigns():
#     sponsor_id = 1  # Simulate logged-in sponsor

#     campaigns = Campaign.query.filter_by(sponsor_id=sponsor_id).all()
#     output = StringIO()
#     writer = csv.writer(output)
#     writer.writerow(['Description', 'Start Date', 'End Date', 'Budget', 'Visibility', 'Goals'])

#     for campaign in campaigns:
#         writer.writerow([
#             campaign.description,
#             campaign.start_date,
#             campaign.end_date,
#             campaign.budget,
#             campaign.visibility,
#             campaign.goals
#         ])

#     output.seek(0)
#     response = Response(output, mimetype='text/csv')
#     response.headers['Content-Disposition'] = 'attachment; filename=campaigns.csv'
#     return response

# @app.route('/export_campaigns_async', methods=['POST'])
# def export_campaigns_async():
#     sponsor_id = request.json.get('sponsor_id')
#     email = request.json.get('email')
#     task = export_campaigns_task.apply_async(args=[sponsor_id, email])
#     return {'task_id': task.id}, 202



# @app.route('/monthly_report')
# def monthly_report():
#     # Retrieve campaign details (for simplicity, assuming the first campaign)
#     campaign = Campaign.query.first()  # Replace with actual logic to get the specific campaign
    
#     # Get the completed ad requests count
#     completed_ads_count = AdRequest.query.filter_by(campaign_id=campaign.id, status='Completed').count()
    
#     print(campaign.name, campaign.start_date, campaign.end_date)

#     print("Completed Ads:", completed_ads_count)
#     # Placeholder for growth metrics (replace with actual calculation)
#     sales_growth = 10  # Example, replace with actual calculation
#     engagement_stats = "500 views, 100 clicks"  # Example, replace with actual data

#     # Budget overview
#     total_spent = 5000  # Example value, replace with actual calculation
#     remaining_balance = campaign.budget - total_spent

#     return render_template('monthly_report.html',
#                            campaign=campaign,
#                            completed_ads_count=completed_ads_count,
#                            sales_growth=sales_growth,
#                            engagement_stats=engagement_stats,
#                            total_spent=total_spent,
#                            remaining_balance=remaining_balance)

# @app.route('/generate_report')
# def generate_report():
#     # Fetch all campaigns for a specific sponsor or all sponsors
#     campaigns = Campaign.query.all()  # Replace with the logic to fetch campaigns of a specific sponsor
    
#     # Placeholder for the report data
#     report_data = []

#     for campaign in campaigns:
#         # Get completed ad requests count for each campaign
#         completed_ads_count = AdRequest.query.filter_by(campaign_id=campaign.id, status='Completed').count()
        
#         # Placeholder for growth metrics (replace with actual calculations)
#         sales_growth = 10  # Example value
#         engagement_stats = "500 views, 100 clicks"  # Example value
        
#         # Budget overview
#         total_spent = 5000  # Example value (replace with actual calculation)
#         remaining_balance = campaign.budget - total_spent
        
#         # Add the campaign's data to the report data list
#         report_data.append({
#             'campaign_name': campaign.name,
#             'start_date': campaign.start_date,
#             'end_date': campaign.end_date,
#             'visibility': campaign.visibility,
#             'status': AdRequest.status,
#             'completed_ads_count': completed_ads_count,
#             'sales_growth': sales_growth,
#             'engagement_stats': engagement_stats,
#             'initial_budget': campaign.budget,
#             'total_spent': total_spent,
#             'remaining_balance': remaining_balance
#         })

#     # Render the report template with the generated data
#     return render_template('generate_report.html', report_data=report_data)


def auth_required(func):
    @wraps(func)
    def inner(*args, **kwargs):
        if 'user_id' in session:
            return func(*args, **kwargs)
        else:
            flash('Please Login to continue.')
            flash('You cannot access this page without login.')
            return redirect(url_for('login'))
        
    return inner

def admin_required(func):
    @wraps(func)
    def inner(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please Login to continue.')
            flash('You cannot access this page without login.')
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user.is_admin:
            flash('You are not authorizeeed to access this page.')
            return redirect(url_for('index'))
        return func(*args, **kwargs)
        
    return inner

from datetime import datetime

from datetime import datetime

from datetime import datetime

# @app.route('/index')
# def index():
#     user = User.query.get(session['user_id'])  # Get the user based on session user_id
#     now = datetime.now().date() 

#     if user:
#         user_type = user.user_type
#     else:
#         user_type = None

#     if user.is_admin:
#         return render_template('admin/admin.html', user=user, user_type=user_type)
    
#     if user.user_type == 'Influencer':
#         # Debug: Print user_id to verify
#         print(f"User ID: {user.id}")
        
#         influencer = Influencer.query.filter_by(user_id=user.id).first()
        
#         # Debug: Check if influencer is found
#         if influencer:
#             print(f"Influencer Found: {influencer.name}")
#             influencer.last_visited = datetime.now()
#             db.session.commit()
#         else:
#             print("Influencer details not found.")
#             flash('Influencer details not found.')
#             return redirect(url_for('login'))

#         ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id).all()
#         return render_template('influencer/profile_influencer.html', influencer=influencer, ad_requests=ad_requests, user=user, user_type=user_type, now=now)
    
#     if user.user_type == 'Sponsor':
#         sponsor = Sponsor.query.filter_by(user_id=user.id).first()
        
#         # Debug: Check if sponsor is found
#         if sponsor and user.active == True:
#             print(f"Sponsor Found: {sponsor.company_name}")
#             sponsor.last_visited = datetime.now()
#             db.session.commit()
#         else:
#             print("Sponsor details not found.")
#             flash('Sponsor details not found.')
#             return redirect(url_for('login'))
      
#         return render_template('sponsor/profile_sponsor.html', user=user, sponsor=sponsor, user_type=user_type, now=now)

# @app.route('/', methods=['GET'])
# def login():
#     return render_template('login.html')

# @app.route('/', methods=['POST'])
# def login_post():
#     # Get JSON data from the request body
#     data = request.get_json()
#     username = data.get('username')
#     password = data.get('password')

#     if not username or not password:
#         return jsonify({'message': 'Please fill out all the necessary fields.'}), 400

#     user = User.query.filter_by(username=username).first()

#     if not user:
#         return jsonify({'message': 'Username does not exist.'}), 400

#     if not check_password_hash(user.passhash, password):
#         return jsonify({'message': 'Incorrect Password. Please enter the correct password.'}), 400

#     session['user_id'] = user.id
#     return jsonify({'redirect_url': url_for('index')})  # Return the redirect URL as JSON

# @app.route('/export_campaigns/<int:sponsor_id>', methods=['GET'])
# def export_campaigns(sponsor_id):
#     # Trigger the CSV export task asynchronously
#     export_campaigns_as_csv.apply_async(args=[sponsor_id])

#     # Optionally, you can show a message indicating the export is in progress
#     return redirect(url_for('/'))  # Redirect to the sponsor dashboard (or wherever)

# Index Route

@app.route('/')
def login():
    return render_template('login.html')


@app.route('/', methods = ['POST'])
def login_post():
    username = request.form.get('username')
    password = request.form.get('password')

    if not username or not password:
        flash('Please fill out all the necessary fields.')
        return redirect(url_for('login'))
    
    user = User.query.filter_by(username = username).first()

    if not user:
        flash('Username does not exist.')
        return redirect(url_for('login'))
    
    if not check_password_hash(user.passhash, password):
        flash('Incorrect Password. Please enter the correct password.')
        return redirect(url_for('login'))
    
    session['user_id'] = user.id
    flash('Login Successful')
    return redirect(url_for('index'))



@app.route('/index')
def index():
    user = User.query.get(session['user_id'])  # Get the user based on session user_id
    now = datetime.now().date() 

    if user:
        user_type = user.user_type
    else:
        user_type = None

    if user.is_admin:
        return render_template('admin/admin.html', user=user, user_type=user_type)
    
    if user.user_type == 'Influencer':
        # Debug: Print user_id to verify
        print(f"User ID: {user.id}")
        
        influencer = Influencer.query.filter_by(user_id=user.id).first()
        
        # Debug: Check if influencer is found
        if influencer:
            print(f"Influencer Found: {influencer.name}")
            influencer.last_visited = datetime.now()
            db.session.commit()
        else:
            print("Influencer details not found.")
            flash('Influencer details not found.')
            return redirect(url_for('login'))

        ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id).all()
        return render_template('influencer/profile_influencer.html', influencer=influencer, ad_requests=ad_requests, user=user, user_type=user_type, now=now)
    
    if user.user_type == 'Sponsor':
        sponsor = Sponsor.query.filter_by(user_id=user.id).first()
        
        # Debug: Check if sponsor is found
        if sponsor and user.active == True:
            print(f"Sponsor Found: {sponsor.company_name}")
            sponsor.last_visited = datetime.now()
            db.session.commit()
        else:
            print("Sponsor details not found.")
            flash('Sponsor details not found.')
            return redirect(url_for('login'))
      
        return render_template('sponsor/profile_sponsor.html', user=user, sponsor=sponsor, user_type=user_type, now=now)


@app.route('/logout')
@auth_required
def logout():
    session.pop('user_id')
    flash('PLease login to continue.')
    return redirect(url_for('login'))

# @app.route('/')
# def login():
#     return render_template('login.html')


# @app.route('/', methods = ['POST'])
# def login_post():
#     username = request.form.get('username')
#     password = request.form.get('password')

#     if not username or not password:
#         flash('Please fill out all the necessary fields.')
#         return redirect(url_for('login'))
    
#     user = User.query.filter_by(username = username).first()

#     if not user:
#         flash('Username does not exist.')
#         return redirect(url_for('login'))
    
#     if not check_password_hash(user.passhash, password):
#         flash('Incorrect Password. Please enter the correct password.')
#         return redirect(url_for('login'))
    
#     session['user_id'] = user.id
#     flash('Login Successful')
#     return redirect(url_for('index'))

# # from flask import Flask, request, jsonify, flash, redirect, url_for, session
# # from werkzeug.security import check_password_hash
# # from .models import User  # Make sure you import your User model here

# # @app.route('/', methods=['GET'])
# # def login():
# #     return render_template('login.html')

# # @app.route('/', methods=['POST'])
# # def login_post():
# #     username = request.form.get('username')
# #     password = request.form.get('password')

# #     if not username or not password:
# #         flash('Please fill out all the necessary fields.')
# #         return redirect(url_for('login'))

# #     user = User.query.filter_by(username=username).first()

# #     if not user:
# #         flash('Username does not exist.')
# #         return redirect(url_for('login'))

# #     if not check_password_hash(user.passhash, password):
# #         flash('Incorrect Password. Please enter the correct password.')
# #         return redirect(url_for('login'))

# #     session['user_id'] = user.id
# #     flash('Login Successful')

# #     # Return the redirect URL in JSON response
#     return jsonify({
#         'redirect_url': url_for('index')  # Replace 'index' with the appropriate route name
#     })



@app.route('/register_influencer')
def register_influencer():
    return render_template('influencer/register_influencer.html')

@app.route('/register_influencer', methods = ['POST'])
def register_influence_post():
    username = request.form.get('username')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    name = request.form.get('name')
    email = request.form.get('email')
    niche = request.form.get('niche')
    reach = request.form.get('reach')
    youtube = request.form.get('youtube')
    twitter = request.form.get('twitter')
    instagram = request.form.get('instagram')

    if not username or not password or not confirm_password or not email or not niche or not reach:
        flash('Please fill out all the necessary fields.')
        return redirect(url_for('register_influencer'))
    
    if password != confirm_password:
        flash('Password does not match.')
        return redirect(url_for('register_influencer'))
    
    user = User.query.filter_by(username = username).first()
    
    if user:
        flash('Username already exists.')
        return redirect(url_for('register_influencer'))

    password_hash = generate_password_hash(password)

    new_user = User(username=username, passhash=password_hash, name=name, user_type='Influencer', active=1)
    db.session.add(new_user)
    db.session.flush()
    influencer_role = RolesUsers(user_id=new_user.id, role_id=3)
    db.session.add(influencer_role)
    db.session.commit()

    # Now that the user is created, we can get their user_id
    user_id = new_user.id

    # new_influencer = Influencer(user_id=user_id, name=name, email=email, niche=niche, reach=reach, youtube = youtube, twitter = twitter, instagram = instagram)
    # db.session.add(new_influencer)
    # db.session.commit()
    new_influencer = Influencer(
        user_id=user_id, 
        name=name,  
        niche=niche, 
        email=email,
        reach=reach, 
        youtube=youtube, 
        twitter=twitter, 
        instagram=instagram
    )
    db.session.add(new_influencer)
    try:
        db.session.commit()
        flash('Influencer created successfully.')
        return redirect(url_for('login'))
    except Exception as e:
        db.session.rollback()
        flash(f'Error creating influencer: {str(e)}')
        print(f"Error: {e}")
        return redirect(url_for('register_influencer'))




@app.route('/register_sponsor')
def register_sponsor():
    return render_template('sponsor/register_sponsor.html')

@app.route('/register_sponsor', methods = ['POST'])
def register_post():
    username = request.form.get('username')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    company_name = request.form.get('company_name')
    email = request.form.get('email')
    industry = request.form.get('industry')

    if not username or not password or not confirm_password:
        flash('Please fill out all the necessary fields.')
        return redirect(url_for('register_sponsor'))
    
    if password != confirm_password:
        flash('Password does not match.')
        return redirect(url_for('register_sponsor'))
    
    user = User.query.filter_by(username = username).first()
    
    if user:
        flash('Username already exists.')
        return redirect(url_for('register_sponsor'))

    password_hash = generate_password_hash(password)

    new_user = User(username=username, passhash=password_hash, user_type='Sponsor', active=0)
    db.session.add(new_user)
    db.session.flush()  # Get the user ID before committing

    # Assign Sponsor role to user using RolesUsers
    sponsor_role = RolesUsers(user_id=new_user.id, role_id=2)
    db.session.add(sponsor_role)
    db.session.commit()

    # Now that the user is created, we can get their user_id
    user_id = new_user.id

    new_sponsor = Sponsor(user_id=user_id,  company_name = company_name, industry = industry, email=email,)
    db.session.add(new_sponsor)
    db.session.commit()
    flash('Sponsor created successfully.')
    return redirect(url_for('login'))

#  ----admin pages

@app.route('/admin/industry-trends')
@admin_required
def industry_trends():
    # For Influencers' industry trends (using niche)
    influencer_data = (
        db.session.query(
            Influencer.niche.label('industry'),
            db.func.avg(Campaign.budget).label('avg_budget_allocation')
        )
        .join(AdRequest, AdRequest.influencer_id == Influencer.id)
        .join(Campaign, Campaign.id == AdRequest.campaign_id)
        .group_by(Influencer.niche)
        .all()
    )

    # For Sponsors' industry trends (using industry field in Sponsor)
    sponsor_data = (
        db.session.query(
            Sponsor.industry.label('industry'),
            db.func.avg(Campaign.budget).label('avg_budget_allocation')
        )
        .join(Campaign, Campaign.sponsor_id == Sponsor.id)
        .group_by(Sponsor.industry)
        .all()
    )

    # Combine both sets of data for visualization
    industries = []
    budget_allocations = []

    for row in influencer_data + sponsor_data:
        industries.append(row.industry)
        budget_allocations.append(row.avg_budget_allocation)

    data = {
        'industries': industries,
        'budget_allocations': budget_allocations
    }

    return jsonify(data)


@app.route('/sponsor_campaign_chart_data')
def sponsor_campaign_chart_data():
    # Aggregate budgets by sponsor
    sponsors = Sponsor.query.all()
    data = {
        "labels": [sponsor.company_name for sponsor in sponsors],
        "datasets": [
            {
                "label": "Campaign Budgets",
                "data": [sum(campaign.budget for campaign in sponsor.campaigns) for sponsor in sponsors],
                "backgroundColor": ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0"],
            }
        ]
    }
    return jsonify(data)

@app.route('/admin/campaign_status_data')
def campaign_status_data():
    # Count campaigns by status
    statuses = ['Active', 'Completed', 'Flagged']
    status_counts = {
        status: Campaign.query.filter_by(is_flagged=(status == 'Flagged')).count() if status == 'Flagged' 
        else Campaign.query.filter(Campaign.end_date >= func.current_date() if status == 'Active' else Campaign.end_date < func.current_date()).count()
        for status in statuses
    }

    # Format the data for Chart.js
    data = {
        "labels": statuses,
        "datasets": [
            {
                "data": list(status_counts.values()),
                "backgroundColor": ["#FF6384", "#36A2EB", "#FFCE56"],  # Colors for each status
                "hoverBackgroundColor": ["#FF6384", "#36A2EB", "#FFCE56"]
            }
        ]
    }
    return jsonify(data)


@app.route('/admin/data')
@admin_required
def admin_data():
    # Count sponsors and influencers
    sponsor_count = Sponsor.query.count()
    influencer_count = Influencer.query.count()

    # Prepare the data for the bar chart
    data = {
        'labels': ['Sponsors', 'Influencers'],
        'values': [sponsor_count, influencer_count]
    }
    return jsonify(data)  # Use jsonify to return JSON

@app.route('/admin/user-growth-data')
@admin_required
def user_growth_data():
    # Fetch the count of new sponsors and influencers grouped by month
    sponsor_growth = (
        db.session.query(
            db.func.strftime('%Y-%m', User.created_at).label('month'),
            db.func.count(User.id).label('count')
        )
        .filter(User.user_type == 'Sponsor')  # Filter for sponsors
        .group_by('month')
        .order_by('month')
        .all()
    )

    influencer_growth = (
        db.session.query(
            db.func.strftime('%Y-%m', User.created_at).label('month'),
            db.func.count(User.id).label('count')
        )
        .filter(User.user_type == 'Influencer')  # Filter for influencers
        .group_by('month')
        .order_by('month')
        .all()
    )

    # Extract months and counts
    months = [row[0] for row in sponsor_growth]
    sponsors = [row[1] for row in sponsor_growth]
    influencers = [row[1] for row in influencer_growth]

    # Ensure both datasets have the same timeline by filling gaps with 0
    all_months = sorted(set(months))
    sponsor_data = {row[0]: row[1] for row in sponsor_growth}
    influencer_data = {row[0]: row[1] for row in influencer_growth}
    sponsors = [sponsor_data.get(month, 0) for month in all_months]
    influencers = [influencer_data.get(month, 0) for month in all_months]

    data = {
        'months': all_months,
        'sponsors': sponsors,
        'influencers': influencers
    }
    return jsonify(data)




@app.route('/admin')
@admin_required
# @auth_required("token")
# @roles_required("Admin")
@cache.cached(timeout=60)
def admin():
    user = User.query.get(session['user_id'])
    print(user) 
    flagged_campaigns = Campaign.query.filter_by(is_flagged=True).all()
    campaigns = Campaign.query.all()
    # Fetch inactive sponsors
    # Fetch inactive sponsors
    inactive_sponsors = (
        db.session.query(User, Sponsor)
        .join(Sponsor, Sponsor.user_id == User.id)
        .filter(User.active == 0, User.user_type == 'Sponsor')
        .all()
    )
    #flagged_campaigns = Flagged_Campaign.query.all()
    return render_template('admin/admin.html', campaigns=campaigns, flagged_campaigns=flagged_campaigns, user=user, user_type=user.user_type, inactive_sponsors=inactive_sponsors)

@app.route('/admin/sponsor/<int:sponsor_id>/activate', methods=['POST'])
@admin_required
def activate_sponsor(sponsor_id):
    sponsor = Sponsor.query.get_or_404(sponsor_id)
    
    # Activate the sponsor and update the associated user if needed
    #sponsor.active = True
    sponsor.user.active = 1  # Activating the related user if needed
    db.session.commit()
    
    flash('Sponsor activated successfully.', 'success')
    return redirect(url_for('admin'))



@app.route('/admin/sponsor/<int:sponsor_id>/delete', methods=['POST'])
@admin_required
def delete_sponsor(sponsor_id):
    sponsor = Sponsor.query.get_or_404(sponsor_id)
    db.session.delete(sponsor)
    db.session.commit()
    flash('Sponsor deleted successfully.', 'success')
    return redirect(url_for('stats_admin'))

@app.route('/admin/sponsor/<int:sponsor_id>', methods=['GET'])
@admin_required
def admin_view_sponsor(sponsor_id):
    sponsor = Sponsor.query.get_or_404(sponsor_id)
    return render_template(
        'admin/view_sponsor.html',
        sponsor=sponsor
    )


@app.route('/admin/stats_admin')
# @auth_required("token")
# @roles_required("Admin")
@cache.cached(timeout=60)
def stats_admin():
    user = User.query.get(session['user_id'])
    return render_template('admin/admin_stats.html', user_type=user.user_type, user = user)

@app.route('/admin/<int:id>/campaign/<int:campaign_id>/view')
@auth_required
def admin_view_campaign(id, campaign_id):
    user = User.query.get(session['user_id'])
    #campaign = Campaign.query.filter_by(campaign_id=id).first()
    campaign = Campaign.query.get_or_404(campaign_id)
    return render_template('admin/admin_view_campaign.html', campaign=campaign, id=session['user_id'], user_type=user.user_type)

@app.route('/admin/<int:id>/influencer/<int:influencer_id>/view')
@auth_required
def admin_view_influencer(id, influencer_id):
    user = User.query.get(session['user_id'])
    influencer = Influencer.query.get_or_404(influencer_id)
    return render_template('admin/admin_view_influencer.html', influencer=influencer, id=session['user_id'], user_type=user.user_type)

@app.route('/admin/<int:id>/find_campaign/<int:campaign_id>/view')
@auth_required
def admin_view_campaigns(id, campaign_id):
    user = User.query.get(session['user_id'])
    #campaign = Campaign.query.filter_by(campaign_id=id).first()
    campaign = Campaign.query.get_or_404(campaign_id)
    return render_template('admin/admin_view_campaigns.html', campaign=campaign, id=session['user_id'], user_type=user.user_type)

@app.route('/admin/<int:id>/find_influencer/<int:influencer_id>/view')
@auth_required
def admin_view_influencers(id, influencer_id):
    user = User.query.get(session['user_id'])
    influencer = Influencer.query.get_or_404(influencer_id)
    return render_template('admin/admin_view_influencers.html', influencer=influencer, id=session['user_id'], user_type=user.user_type)


@app.route('/admin/<int:id>/find_all', methods=['GET'])
@auth_required  # Ensure authentication is required to access this route
@cache.cached(timeout=50)
def find_all(id):
    user = User.query.get(session['user_id'])

    if not user:
        flash('User not found.')
        return redirect(url_for('login'))

    cname = request.args.get('cname', '')
    iname = request.args.get('iname', '')
    niche = request.args.get('niche', '')
    
    # Query influencers with filters applied
    influencers_query = db.session.query(Influencer)
    campaigns_query = db.session.query(Campaign)

    if cname:
        campaigns_query = campaigns_query.filter(Campaign.name.ilike(f"%{cname}%"))
    if iname:
        influencers_query = influencers_query.filter(Influencer.name.ilike(f"%{iname}%"))
    if niche:
        influencers_query = influencers_query.filter(Influencer.niche.ilike(f"%{niche}%"))

    influencers = influencers_query.all()
    campaigns = campaigns_query.all()

    # Query public campaigns
    #campaigns = Campaign.query.all()
  
    return render_template('admin/find_all.html', influencers=influencers, campaigns = campaigns, cname=cname, iname=iname, niche=niche, user_type=user.user_type, user=user)

@app.route('/admin/<int:id>/flagged/<int:campaign_id>')
@auth_required
def flagged_items(id):
    flagged_campaigns = Campaign.query.filter_by(is_flagged=True).all()
    flagged_users = User.query.filter_by(is_flagged=True).all()
    return render_template('admin/admin.html', flagged_campaigns=flagged_campaigns, flagged_users=flagged_users)

@app.route('/admin/flag_campaign/<int:campaign_id>', methods=['POST'])
@admin_required
def flag_campaign(campaign_id):
    campaign = Campaign.query.get(campaign_id)
    campaign.is_flagged = True
    db.session.commit()
    flash('Campaign has been flagged.')
    return redirect(url_for('admin', id=session['user_id']))


@app.route('/admin/campaign/<int:campaign_id>/unflag', methods=['POST'])
@auth_required
def unflag_campaign(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)
    campaign.is_flagged = False
    db.session.commit()
    flash('Campaign unflagged successfully')
    return redirect(url_for('admin', id=session['user_id']))

@app.route('/admin/user/<int:user_id>/flag', methods=['POST'])
@auth_required
def flag_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_flagged = True
    db.session.commit()
    flash('User flagged successfully')
    return redirect(url_for('admin', id=session['user_id']))

@app.route('/admin/user/<int:user_id>/unflag', methods=['POST'])
@auth_required
def unflag_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_flagged = False
    db.session.commit()
    flash('User unflagged successfully')
    return redirect(url_for('admin', id=session['user_id']))


@app.route('/admin/<int:id>/profile')
@auth_required
@cache.cached(timeout=50)
def profile_admin(id):
    user = User.query.get(session['user_id'])
    now = datetime.now().date()
    if not user:
        flash('Admin not found.')
        return redirect(url_for('login'))
 
    # Fetch ad requests for the influencer

    return render_template('admin/profile_admin.html', user = user, user_type=user.user_type, now = now)

@app.route('/admin/<int:admin_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_admin(admin_id):
    user = User.query.get(admin_id)
    if not user:
        flash('User not found.')
        return redirect(url_for('profile_admin', id=admin_id))
    if request.method == 'POST':
        user.name = request.form['name']        
        db.session.commit()
        flash('Profile updated successfully!')
        return redirect(url_for('profile_admin', id=admin_id))
    return render_template('admin/edit_profile.html', user=user)


#   ----influencer pages

@app.route('/influencer/<int:id>/profile')
@auth_required
@cache.cached(timeout=60)
def profile_influencer(id):
    print(f"Received id: {id}")
    influencer = Influencer.query.filter_by(id = id).first()
    if not influencer:
        flash('Influencer not found.')
        return redirect(url_for('login'))
        
    user = User.query.get(session['user_id'])
    if not user:
        flash('User not found.')
        return redirect(url_for('login'))
        
    ad_requests = AdRequest.query.filter(AdRequest.influencer_id == influencer.id,AdRequest.creator == "sponsor").all()

    now = datetime.now().date()
 
    return render_template('influencer/profile_influencer.html', influencer=influencer, ad_requests=ad_requests, user=user, user_type=user.user_type, now=now)

@app.route('/influencer/<int:influencer_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_influencer(influencer_id):
    influencer = Influencer.query.filter_by(id = influencer_id).first()
    if not influencer:
        flash('Influencer not found.')
        return redirect(url_for('profile_influencer', id=influencer_id))
    if request.method == 'POST':
        influencer.name = request.form['name']
        influencer.email = request.form['email']
        influencer.niche = request.form['niche']
        influencer.reach = request.form['reach']
        influencer.youtube = request.form.get('youtube')
        influencer.twitter = request.form.get('twitter')
        influencer.instagram = request.form.get('instagram')
        db.session.commit()
        flash('Profile updated successfully!')
        return redirect(url_for('profile_influencer', id=influencer.user_id))
    return render_template('influencer/edit_profile.html', influencer=influencer)


@app.route('/campaign/<int:id>/view')
@auth_required
@cache.cached(timeout=60)
def influencer_p_view_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    return render_template('influencer/influencer_p_view_campaign.html', campaign=campaign, id=session['user_id'])

@app.route('/ad_request/<int:id>/view')
@auth_required
def influencer_p_view_request(id):
    ad_request = AdRequest.query.get_or_404(id)
    return render_template('influencer/influencer_view_request.html', ad_request=ad_request, id=session['user_id'])

@app.route('/influencer/ad_request/<int:ad_request_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_ad_request_influencer(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)

    if request.method == 'POST':
        ad_request.requirements = request.form.get('requirements')
        ad_request.payment_amount = request.form.get('payment_amount')
        ad_request.status = 'Edited'  # Reset status to 'Pending' for sponsor review
        ad_request.creater = "influencer"
        db.session.commit()
        flash('Ad request updated and resent successfully.')
        return redirect(url_for('influencer_p_view_request', id=ad_request.id))

    return render_template('influencer/edit_ad_request_influencer.html', ad_request=ad_request)


@app.route('/ad_request/<int:ad_request_id>/accept', methods=['GET'])
@auth_required
def accept_request(ad_request_id):
    ad_request = AdRequest.query.get(ad_request_id)
    if not ad_request:
        flash('No request found.')
        return redirect(url_for('profile_influencer', id=session['user_id']))
    ad_request.status = 'Accepted'
    db.session.commit()
    flash('Ad request accepted successfully.')
    return redirect(url_for('profile_influencer', id=session['user_id']))


@app.route('/ad_request/<int:ad_request_id>/reject', methods=['GET'])
@auth_required
def reject_request(ad_request_id):
    ad_request = AdRequest.query.get(ad_request_id)
    if not ad_request:
        flash('No request found.')
        return redirect(url_for('profile_influencer', id=session['user_id']))
    ad_request.status = 'Rejected'
    db.session.commit()
    flash('Ad request rejected.')
    return redirect(url_for('profile_influencer', id=session['user_id']))

@app.route('/influencer/<int:id>/find_campaign', methods=['GET'])
@auth_required  # Ensure authentication is required to access this route
@cache.cached(timeout=60)
def find_campaign(id):
    influencer = Influencer.query.filter_by(user_id=id).first()
    user = User.query.get(session['user_id'])

    if not influencer or not user:
        flash('Influencer not found.')
        return redirect(url_for('login'))

    name = request.args.get('name', '')
    budget = request.args.get('budget', type=float)
    start_date = request.args.get('start_date')

    # Query campaigns with filters applied
    campaigns_query = db.session.query(Campaign)

    if name:
        campaigns_query = campaigns_query.filter(Campaign.name.ilike(f"%{name}%"))
    if budget is not None:
        campaigns_query = campaigns_query.filter(Campaign.budget <= budget)
    if start_date:
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            campaigns_query = campaigns_query.filter(Campaign.start_date >= start_date)
        except ValueError:
            flash('Invalid date format. Please use YYYY-MM-DD.')
            start_date = None

    campaigns = campaigns_query.all()

    return render_template('influencer/find_campaign.html',influencer = influencer, campaigns=campaigns, name=name, budget=budget, start_date=start_date, user_type=user.user_type)

@app.route('/campaign/<int:id>/view')
@auth_required
@cache.cached(timeout=60)
def influencer_view_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    return render_template('influencer/view_campaign.html', campaign=campaign, id=session['user_id'])

@app.route('/influencer/<int:influencer_id>/campaign/<int:campaign_id>/request', methods=['GET', 'POST'])
@auth_required
def request_from_campaign(influencer_id, campaign_id):
    print(f"Influencer ID: {influencer_id}")
    print(f"Campaign ID: {campaign_id}")

    influencer = Influencer.query.get_or_404(influencer_id)
    if not influencer:
        flash('Influencer not found.')
        return redirect(url_for('profile_influencer', id=influencer_id))
    
    campaign = Campaign.query.get_or_404(campaign_id)
    sponsor = campaign.sponsor  # Fetch the sponsor directly from the campaign

    if request.method == 'POST':
        messages = request.form.get('messages')
        requirements = request.form.get('requirements')
        payment_amount = request.form.get('payment_amount')

        try:
            payment_amount = float(payment_amount)
        except ValueError:
            flash('Invalid payment amount.')
            return redirect(url_for('request_from_campaign', influencer_id=influencer_id, campaign_id=campaign_id))

        ad_request = AdRequest(
            campaign_id=campaign.id,
            influencer_id=influencer.id,
            messages=messages,
            requirements=requirements,
            payment_amount=payment_amount,
            status='Pending',
            creater="influencer"
        )
        db.session.add(ad_request)
        db.session.commit()
        flash('Ad request successfully created.')
        print(f"s")
        return redirect(url_for('profile_influencer', id=influencer_id))

    return render_template('influencer/ad_request.html', influencer=influencer, campaign=campaign)

@app.route('/stats_influencer')
def stats_influencer():
    return render_template('empty.html')

#  -----sponsor pages

@app.route('/profile/sponsor/<int:id>', methods=['GET'])
@auth_required
@cache.cached(timeout=60)
def profile_sponsor(id):
    user = User.query.get(id)
    if user:
        user_type = user.user_type
    if not user:
        flash('User not found.')
        return redirect(url_for('login'))

    sponsor = Sponsor.query.filter_by(user_id=user.id).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('login'))

    now = datetime.now().date()
    campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()

    if not user:
        flash('User not found.')
        return redirect(url_for('login'))

    # Fetch active campaigns for the sponsor
    active_campaigns = Campaign.query.filter(Campaign.sponsor_id == sponsor.id, Campaign.end_date >= now).all()
    
    # Fetch completed campaigns for the sponsor
    completed_campaigns = Campaign.query.filter(Campaign.sponsor_id == sponsor.id, Campaign.end_date < now).all()

    # Fetch ad requests for the sponsor's campaigns
    ad_requests = AdRequest.query.join(Campaign).filter(Campaign.sponsor_id == sponsor.id, AdRequest.creater == "influencer").all()
    

    
    return render_template(
        'sponsor/profile_sponsor.html', 
        sponsor=sponsor, 
        active_campaigns=active_campaigns, 
        completed_campaigns=completed_campaigns, 
        ad_requests=ad_requests,
        user=user,
        user_type=user_type, 
        now=now
    )

# @app.route('/campaign/<int:id>/view')
# @auth_required
# def view_p_campaign(id):
#     campaign = Campaign.query.get_or_404(id)
#     return render_template('sponsor/view_p_campaign.html', campaign=campaign, id=session['user_id'])

@app.route('/sponsor/<int:sponsor_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_sponsor(sponsor_id):
    sponsor = Sponsor.query.filter_by(id = sponsor_id).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('profile_sponsor', id=sponsor_id))
    if request.method == 'POST':
        sponsor.company_name = request.form['company_name']
        sponsor.email = request.form['email']
        sponsor.industry = request.form['industry']
        sponsor.budget = request.form['budget']
        db.session.commit()
        flash('Profile updated successfully!')
        return redirect(url_for('profile_sponsor', id=sponsor.user_id))
    return render_template('sponsor/edit_profile.html', sponsor=sponsor)

@app.route('/ad_request/<int:ad_request_id>/accept', methods=['POST'])
@auth_required
def s_accept_request(ad_request_id):
    ad_request = AdRequest.query.get(ad_request_id)
    if not ad_request:
        flash('No request found.')
        return redirect(url_for('profile_sponsor', id=session['user_id']))
    ad_request.status = 'Accepted'
    db.session.commit()
    flash('Ad request accepted successfully.')
    return redirect(url_for('profile_sponsor', id=session['user_id']))


@app.route('/ad_request/<int:ad_request_id>/reject', methods=['POST'])
@auth_required
def s_reject_request(ad_request_id):
    ad_request = AdRequest.query.get(ad_request_id)
    if not ad_request:
        flash('No request found.')
        return redirect(url_for('profile_sponsor', id=session['user_id']))
    ad_request.status = 'Rejected'
    db.session.commit()
    flash('Ad request rejected.')
    return redirect(url_for('profile_sponsor', id=session['user_id']))

@app.route('/sponsor/ad_request/<int:ad_request_id>/edit', methods=['GET', 'POST'])
@auth_required
def edit_ad_request_sponsor(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)

    if request.method == 'POST':
        ad_request.requirements = request.form.get('requirements')
        ad_request.payment_amount = request.form.get('payment_amount')
        ad_request.status = 'Edited'  # Reset status to 'Pending' for sponsor review
        ad_request.creater = "sponsor"
        db.session.commit()
        flash('Ad request updated and resent successfully.')
        return redirect(url_for('sponsor_view_request', ad_request_id=ad_request.id))

    return render_template('sponsor/edit_ad_request_sponsor.html', ad_request=ad_request)


@app.route('/sponsor/<int:id>/campaigns')
@auth_required
@cache.cached(timeout=60)
def campaigns_sponsor(id):
    sponsor = Sponsor.query.filter_by(user_id=id).first()
    user = User.query.get(session['user_id'])
    print(f"Sponsors ID: {sponsor.id}")
    if not sponsor or not user:
        flash('Sponsor not found.')
        return redirect(url_for('login'))
    print(f"Sponsor ID: {sponsor.id}")
    campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()
    print(f"Campaigns found: {campaigns}")
    return render_template('sponsor/campaigns.html', sponsor=sponsor, campaigns=campaigns, user_type = user.user_type)

@app.route('/s/add_campaign/<int:id>', methods=['GET', 'POST'])
@auth_required
@cache.cached(timeout=60)
def add_campaign(id):
    sponsor = Sponsor.query.filter_by(user_id=id).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        start_date_str = request.form['start_date']
        end_date_str = request.form['end_date']
        budget = request.form['budget']
        visibility = request.form['visibility']
        goals_list = request.form.getlist('goals[]')
        niche = request.form['niche']

        # Convert date strings to date objects
        try:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
        except ValueError:
            flash('Invalid date format. Please use YYYY-MM-DD.')
            return redirect(url_for('add_campaign', id=id))

        # Join goals into a single string separated by newlines
        goals = "\n".join([goal for goal in goals_list if goal.strip() != ""])

        new_campaign = Campaign(
            name=name,
            description=description,
            start_date=start_date,
            end_date=end_date,
            budget=float(budget),
            visibility=visibility,
            goals=goals,
            niche=niche,
            sponsor_id=sponsor.id,
            created_at=datetime.now()
        )

        db.session.add(new_campaign)
        db.session.commit()
        
        flash('Campaign added successfully!')
        return redirect(url_for('campaigns_sponsor', id=id))        

    return render_template('sponsor/add_campaign.html', sponsor = sponsor)

@app.route('/sponsor/<int:id>/find_influencer', methods=['GET'])
@auth_required
@cache.cached(timeout=60)
def find_influencer(id):
    # Assuming id is the sponsor's id
    sponsor = Sponsor.query.filter_by(user_id=id).first()
    user = User.query.get(session['user_id'])

    if not sponsor or not user:
        flash('Sponsor not found.')
        return redirect(url_for('login'))

    cname = request.args.get('cname', '')
    iname = request.args.get('iname', '')
    niche = request.args.get('niche', '')
    reach = request.args.get('reach', type=int)

    # Query influencers with filters applied
    influencers_query = db.session.query(Influencer)

    if iname:
        influencers_query = influencers_query.filter(Influencer.name.ilike(f"%{iname}%"))
    if niche:
        influencers_query = influencers_query.filter(Influencer.niche.ilike(f"%{niche}%"))
    if reach is not None:
        influencers_query = influencers_query.filter(Influencer.reach >= reach)

    influencers = influencers_query.all()

    # Query campaigns with filters applied
    campaigns_query = db.session.query(Campaign).filter_by(visibility='public')

    if cname:
        campaigns_query = campaigns_query.filter(Campaign.name.ilike(f"%{cname}%"))

    public_campaigns = campaigns_query.all()

    return render_template('sponsor/find_influencer.html', sponsor=sponsor, influencers=influencers, public_campaigns=public_campaigns, cname=cname, iname=iname, niche=niche, reach=reach, user_type=user.user_type)

@app.route('/select_campaign/<int:influencer_id>', methods=['GET'])
@auth_required
def select_campaign(influencer_id):
    influencer = Influencer.query.get_or_404(influencer_id)
    public_campaigns = Campaign.query.filter_by(visibility='public').all()
    return render_template('sponsor/select_campaign.html', influencer=influencer, public_campaigns=public_campaigns)


@app.route('/contact_influencer', methods=['POST'])
def contact_influencer():
    influencer_id = request.form.get('influencer_id')
    influencer = db.session.query(Influencer).get(influencer_id)
    # Implement the logic to contact the influencer, such as sending an email
    return redirect(url_for('find_influencer'))

# Update the route to accept both influencer_id and campaign_id
@app.route('/sponsor/influencer/<int:influencer_id>/campaign/<int:campaign_id>/request', methods=['GET', 'POST'])
@auth_required
def request_influencer(influencer_id, campaign_id):
    influencer = Influencer.query.get_or_404(influencer_id)
    #influencer = Influencer.query.filter_by(user_id=influencer_id).first()
    campaign = Campaign.query.get_or_404(campaign_id)
    sponsor_id = campaign.sponsor.id
    

    if request.method == 'POST':
        messages = request.form.get('messages')
        requirements = request.form.get('requirements')
        payment_amount = request.form.get('payment_amount')

        # Ensure payment_amount is a valid float
        try:
            payment_amount = float(payment_amount)
        except ValueError:
            flash('Invalid payment amount.')
            return redirect(url_for('request_influencer', influencer_id=influencer_id, campaign_id=campaign_id))

        ad_request = AdRequest(
            campaign_id=campaign.id,
            influencer_id=influencer.id,
            messages=messages,
            requirements=requirements,
            payment_amount=payment_amount,
            status='Pending',
            sponsor_id=sponsor_id,
            creater = "sponsor"
        )
        db.session.add(ad_request)
        db.session.commit()
        flash('Ad request successfully created.')
        return redirect(url_for('find_influencer', id=session['user_id']))

    return render_template('sponsor/request_influencer.html', influencer=influencer, campaign=campaign)

@app.route('/influencer/<int:id>/view')
@auth_required
@cache.cached(timeout=60)
def view_influencer(id):
    influencer = Influencer.query.get_or_404(id)
    return render_template('sponsor/view_influencer.html', influencer=influencer)


@app.route('/sponsor/<int:sponsor_id>/campaign/<int:id>/view')
@auth_required
def view_campaign(sponsor_id, id):
    sponsor = Sponsor.query.filter_by(user_id=sponsor_id).first()
    campaign = Campaign.query.get_or_404(id)
    return render_template('sponsor/view_campaigns.html', sponsor = sponsor, campaign=campaign, id=session['user_id'])

@app.route('/campaign/<int:id>/add')
@auth_required
def add_campaigns(id):
    campaign = Campaign.query.get_or_404(id)
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('find_influencer', id=session['user_id']))
    sponsor.campaigns.append(campaign)
    db.session.commit()
    flash('Campaign successfully added.')
    return redirect(url_for('find_influencer', id=session['user_id']))

# @app.route('/campaign/<int:id>/view', methods=['GET'])
# @auth_required
# def view_c_campaign(id):
#     print(f"Campaign ID: {id}")
#     campaign = Campaign.query.get_or_404(id)
#     return render_template('sponsor/view_c_campaign.html', campaign=campaign, id=session['user_id'])
@app.route('/campaign/campaign/<int:id>/view', methods=['GET'])
@auth_required
def view_c_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    return render_template('sponsor/view_c_campaign.html', campaign = campaign)

@app.route('/campaign/campaign/<int:id>/delete', methods=['POST'])
@auth_required
def delete_c_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    #ad_request.campaign_id = None
    db.session.delete(campaign)
    db.session.commit()
    flash('Campaign deleted successfully!', 'success')
    return render_template('sponsor/campaigns.html', campaign = campaign)

@app.route('/campaign/profile/<int:id>/view', methods=['GET'])
@auth_required
def view_p_campaign(id):
    campaign = Campaign.query.get_or_404(id)
    return render_template('sponsor/view_p_campaign.html', campaign = campaign)



@app.route('/view_request/<int:ad_request_id>', methods=['GET'])
@auth_required
def sponsor_view_request(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)
    campaign = Campaign.query.get_or_404(ad_request.campaign_id)
    influencer = Influencer.query.get_or_404(ad_request.influencer_id)
    return render_template('sponsor/view_ad_requests.html', ad_request=ad_request, campaign = campaign, influencer = influencer)



@auth_required
@app.route('/sponsor/<int:id>/stats', methods=['GET'])
@cache.cached(timeout=60)
def stats_sponsor(id):
    user = User.query.get(id)
    if not user:
        flash('User not found.')
        return redirect(url_for('login'))

    sponsor = Sponsor.query.filter_by(user_id=user.id).first()
    if not sponsor:
        flash('Sponsor not found.')
        return redirect(url_for('login'))
    
    campaigns = Campaign.query.all()
    campaign_names = [campaign.name for campaign in campaigns]
    campaign_budgets = [campaign.budget for campaign in campaigns]
    return render_template('sponsor/stats.html', user=user, user_type=user.user_type, campaigns = campaigns, 
                           campaign_names = campaign_names, campaign_budgets = campaign_budgets)
