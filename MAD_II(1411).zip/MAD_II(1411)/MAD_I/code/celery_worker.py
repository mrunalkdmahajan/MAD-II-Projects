# # from celery_config import make_celery
# # from app import app

# # celery = make_celery(app)

# # @celery.task
# # def generate_monthly_report():
# #     print("Generating Monthly Report...")

# # from app import create_app, make_celery

# # app = create_app()
# # celery = make_celery(app)

# # if __name__ == '__main__':
# #     celery.start()

# from application import create_app, make_celery

# # Initialize the Flask app and Celery
# app, celery = create_app()

# # No need to call `celery.start()` here, just run the Celery worker with the command
# if __name__ == '__main__':
#     app.run(debug=True)



# # from celery import Celery
# # from app import app  # Import app to link Celery with Flask

# # def make_celery(app):
# #     celery = Celery(
# #         app.import_name,
# #         broker=app.config['CELERY_BROKER_URL'],
# #         backend=app.config['CELERY_RESULT_BACKEND'],
# #     )
# #     celery.conf.update(app.config)
# #     return celery

# # # Initialize Celery instance
# # celery = make_celery(app)

# # @celery.task
# # def generate_monthly_report():
# #     print("Generating Monthly Report...")

# # # Celery worker should start from here when running Celery commands
# # if __name__ == '__main__':
# #     celery.start()
