# from apscheduler.schedulers.background import BackgroundScheduler
# from celery_worker import generate_monthly_report
# import atexit

# scheduler = BackgroundScheduler()

# # Schedule the Celery task
# scheduler.add_job(
#     func=generate_monthly_report.delay,  # Celery's delay method
#     trigger='cron',
#     day=1,  # 1st of every month
#     hour=0,  # Midnight
#     minute=0
# )

# # Start the scheduler
# scheduler.start()

# # Gracefully shutdown the scheduler when the app stops
# atexit.register(lambda: scheduler.shutdown(wait=False))

from apscheduler.schedulers.background import BackgroundScheduler
import atexit

# Initialize scheduler
scheduler = BackgroundScheduler()

def schedule_task():
    # Import Celery task lazily to avoid circular import
    from celery_worker import generate_monthly_report

    # Schedule the Celery task
    scheduler.add_job(
        func=generate_monthly_report.delay,  # Celery's delay method
        trigger='cron',
        day=1,  # 1st of every month
        hour=0,  # Midnight
        minute=0
    )

# Start the scheduler
schedule_task()
scheduler.start()

# Gracefully shutdown the scheduler when the app stops
atexit.register(lambda: scheduler.shutdown(wait=False))
