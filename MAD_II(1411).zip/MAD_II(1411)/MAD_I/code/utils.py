from datetime import date
from models import Milestone  # Ensure you have imported the necessary model

def update_campaign_status(campaign):
    today = date.today()
    if today < campaign.start_date:
        campaign.status = "Not Started"
    elif campaign.start_date <= today <= campaign.end_date:
        campaign.status = "In Progress"
    else:
        campaign.status = "Completed"
    return campaign.status

def calculate_progress_percentage(campaign_id):
    milestones = Milestone.query.filter_by(campaign_id=campaign_id).all()
    total_milestones = len(milestones)
    completed_milestones = sum(1 for m in milestones if m.status == 'Completed')
    progress_percentage = (completed_milestones / total_milestones) * 100 if total_milestones > 0 else 0
    return progress_percentage
