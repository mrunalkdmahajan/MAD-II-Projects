broker_url = "redis://localhost:6379/1"
result_backend = "redis://localhost:6379/2"
timezone = "Asia/kolkata"
broker_connection_retry_on_startup=True
# CELERY_ACCEPT_CONTENT=['json']
# CELERY_TASK_SERIALIZER='json'

# Use 'solo' pool for Windows compatibility
task_default_queue = 'celery'
worker_pool = 'solo'