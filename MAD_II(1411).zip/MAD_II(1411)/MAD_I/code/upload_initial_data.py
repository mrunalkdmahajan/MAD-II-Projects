from werkzeug.security import generate_password_hash
from datetime import datetime
from application.models import db, User, Sponsor, Influencer, Campaign, AdRequest, Role, RolesUsers
from main import app
from application.sec import datastore
from flask_security import hash_password


with app.app_context():
    # Create all tables
    db.create_all()

    # Create initial Roles if they don't exist
    if not Role.query.filter_by(name="Admin").first():
        admin_role = Role(name="Admin", description="Administrator with full permissions")
        db.session.add(admin_role)

    if not Role.query.filter_by(name="Sponsor").first():
        sponsor_role = Role(name="Sponsor", description="Sponsor with permissions to manage campaigns")
        db.session.add(sponsor_role)

    if not Role.query.filter_by(name="Influencer").first():
        influencer_role = Role(name="Influencer", description="Influencer with permissions to view and request campaigns")
        db.session.add(influencer_role)

    # Commit roles to the database
    db.session.commit()

    # Create initial Users if they don't exist
    if not User.query.filter_by(username="admin").first():
        admin = User(
            username="admin",
            passhash=generate_password_hash("admin"),
            name="Admin User",
            user_type="Admin",
            is_admin=True,
            is_flagged=False,
            u_email="mrunalkdmahajan@gmail.com",
            active=True,
            fs_uniquifier="admin_unique"
        )
        db.session.add(admin)
        db.session.flush() 

        # Assign Admin role to user using RolesUsers
        admin_role = RolesUsers(user_id=admin.id, role_id=admin_role.id)
        db.session.add(admin_role)

    if not User.query.filter_by(username="sponsor1").first():
        sponsor = User(
            username="sponsor1",
            passhash=generate_password_hash("sponsor1"),
            name="Sponsor One",
            user_type="Sponsor",
            is_admin=False,
            is_flagged=False,
            active=True,
            fs_uniquifier="sponsor1_unique"
        )
        db.session.add(sponsor)
        db.session.flush()  # Get the user ID before committing

        # Assign Sponsor role to user using RolesUsers
        sponsor_role = RolesUsers(user_id=sponsor.id, role_id=sponsor_role.id)
        db.session.add(sponsor_role)

        sponsor = Sponsor(
            user_id=sponsor.id,
            company_name="Company A",
            email="kirtimhjn@gmail.com",
            industry="Tech",
            budget=50000.0
        )
        db.session.add(sponsor)

    if not User.query.filter_by(username="influencer1").first():
        influencer = User(
            username="influencer1",
            passhash=generate_password_hash("influencer1"),
            name="Influencer One",
            user_type="Influencer",
            is_admin=False,
            is_flagged=False,
            active=True
            
        )
        db.session.add(influencer)
        db.session.flush()  # Get the user ID before committing

        # Assign Influencer role to user using RolesUsers
        influencer_role = RolesUsers(user_id=influencer.id, role_id=influencer_role.id)
        db.session.add(influencer_role)

        influencer = Influencer(
            user_id=influencer.id,
            name="Influencer One",
            email="2022.mrunal.mahajan@ves.ac.in",
            niche="Travel",
            reach=10000,
            youtube="youtube.com/influencer1",
            instagram="instagram.com/influencer1"
        )
        db.session.add(influencer)

    # Create initial Campaign if it doesn't exist
    if not Campaign.query.filter_by(name="Campaign One").first():
        campaign = Campaign(
            name="Campaign One",
            description="First public campaign",
            start_date=datetime(2024, 1, 1),
            end_date=datetime(2024, 12, 31),
            budget=10000.0,
            visibility="public",
            goals="Increase brand awareness",
            niche="Lifestyle",
            sponsor_id=sponsor.id
        )
        db.session.add(campaign)

    # Create initial AdRequest if it doesn't exist
    if not AdRequest.query.filter_by(messages="Initial Request").first():
        ad_request = AdRequest(
            campaign_id=1,  # Assuming campaign_id is 1
            influencer_id=1,  # Assuming influencer_id is 1
            sponsor_id=1,
            messages="Initial Request",
            requirements="Deliver 2 posts and 1 video",
            payment_amount=1000.0,
            status="Pending",
            creater="sponsor"
        )
        db.session.add(ad_request)
    
    db.session.commit()

# from werkzeug.security import generate_password_hash
# from datetime import datetime
# from application.models import db, User, Sponsor, Influencer, Campaign, AdRequest
# from main import app
# from application.sec import datastore
# from flask_security import hash_password

# with app.app_context():
#     # Create all tables
#     db.create_all()

#     # Create initial Users if they don't exist
#     if not User.query.filter_by(username="admin").first():
#         admin = User(
#             username="admin",
#             passhash=generate_password_hash("admin"),
#             name="Admin User",
#             user_type="Admin",
#             is_admin=True,
#             is_flagged=False,
#             u_email="mrunalkdmahajan@gmail.com",
#             active=True,
#             fs_uniquifier="admin_unique"  # Add this line
#         )
#         db.session.add(admin)

#     if not User.query.filter_by(username="sponsor1").first():
#         sponsor = User(
#             username="sponsor1",
#             passhash=generate_password_hash("sponsor1"),
#             name="Sponsor One",
#             user_type="Sponsor",
#             is_admin=False,
#             is_flagged=False,
#             active=False,
#             fs_uniquifier="sponsor1_unique"  # Add this line
#         )
#         db.session.add(sponsor)
#         db.session.flush()  # Get the user ID before committing

#         sponsor = Sponsor(
#             user_id=sponsor.id,
#             company_name="Company A",
#             email="kirtimhjn@gmail.com",
#             industry="Tech",
#             budget=50000.0
#         )
#         db.session.add(sponsor)

#     if not User.query.filter_by(username="influencer1").first():
#         influencer = User(
#             username="influencer1",
#             passhash=generate_password_hash("influencer1"),
#             name="Influencer One",
#             user_type="Influencer",
#             is_admin=False,
#             is_flagged=False,
#             active=True,
#             fs_uniquifier="influencer1_unique"  # Add this line
#         )
#         db.session.add(influencer)
#         db.session.flush()  # Get the user ID before committing

#         influencer = Influencer(
#             user_id=influencer.id,
#             name="Influencer One",
#             email="2022.mrunal.mahajan@ves.ac.in",
#             niche="Travel",
#             reach=10000,
#             youtube="youtube.com/influencer1",
#             instagram="instagram.com/influencer1"
#         )
#         db.session.add(influencer)

#     # Create initial Campaign if it doesn't exist
#     if not Campaign.query.filter_by(name="Campaign One").first():
#         campaign = Campaign(
#             name="Campaign One",
#             description="First public campaign",
#             start_date=datetime(2024, 1, 1),
#             end_date=datetime(2024, 12, 31),
#             budget=20000.0,
#             visibility="public",
#             niche="travel",
#             sponsor_id=1,  # Assuming sponsor_id is 1
#             goals="Increase brand awareness"
#         )
#         db.session.add(campaign)

    