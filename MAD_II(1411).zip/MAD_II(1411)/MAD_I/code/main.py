# # from flask import Flask
# # from flask_security import SQLAlchemyUserDatastore, Security
# # from app.models import db, User, Role, Sponsor, Influencer, Campaign, AdRequest
# # from config import DevelopmentConfig
# # #from app.resources import api
# # from app.sec import datastore
# # from app.worker import celery_init_app
# # import flask_excel as excel
from celery.schedules import crontab
# # from app.tasks import daily_reminder
# # from app.instances import cache


# # def create_app():
# #     app = Flask(__name__)
# #     app.config.from_object(DevelopmentConfig)
# #     db.init_app(app)
# #     #api.init_app(app)
# #     excel.init_excel(app)
# #     app.security = Security(app, datastore)
# #     cache.init_app(app)
# #     with app.app_context():
# #         import app.routes

# #     return app


# # app = create_app()
# # #celery_app = celery_init_app(app)


# # # @celery_app.on_after_configure.connect
# # # def send_email(sender, **kwargs):
# # #     sender.add_periodic_task(
# # #         crontab(hour=19, minute=55, day_of_month=20),
# # #         daily_reminder.s('narendra@email.com', 'Daily Test'),
# # #     )


# # if __name__ == '__main__':
# #     app.run(debug=True)

# from flask import Flask
# from flask_security import SQLAlchemyUserDatastore, Security
# from application.models import db, User, Role, Sponsor, Influencer, Campaign, AdRequest
# from config import DevelopmentConfig
# #from app.resources import api
# from application.sec import datastore
# from application.worker import celery_init_app
# import flask_excel as excel
# from celery.schedules import crontab
# from application.tasks import daily_reminder, send_reminder_email
# from application.tasks import check_influencer_reminder, generate_and_send_monthly_report
# from application.instances import cache
# import datetime


# def create_app():
#     app = Flask(__name__)  # You can name this whatever you want, like 'app'
#     app.config.from_object(DevelopmentConfig)
#     db.init_app(app)
#     #api.init_app(app)
#     excel.init_excel(app)
#     app.security = Security(app, datastore)
#     cache.init_app(app)
#     with app.app_context():
#         import application.routes

#     return app


# app = create_app()  # Use 'app' instead of 'app'

# celery_app = celery_init_app(app)

# @celery_app.on_after_configure.connect
# def send_email(sender, **kwargs):
#     sender.add_periodic_task(
#         crontab(hour=17, minute=19, day_of_week=5),
#         daily_reminder.s('mrunalkdmahajan@gmail.com', 'Daily Test'),
#     )

# # @celery_app.on_after_configure.connect
# # def setup_periodic_tasks(sender, **kwargs):
# #     # Add the periodic task to generate monthly report
# #     sender.add_periodic_task(
# #         crontab(day_of_month=29, hour=4, minute=20),  # Runs at midnight on the 1st of every month
# #         generate_monthly_report.s(),  # Celery task to run
# #         daily_reminder.s('mrunalkdmahajan@gmail.com', 'Monthly Report'),
# #     )

# @celery_app.on_after_configure.connect
# def schedule_daily_reminder(sender, **kwargs):
#     # Assuming the user selects 6:00 PM (18:00) as the reminder time
#     reminder_hour = 10  # 6 PM
#     reminder_minute = 52

#     # Schedule the check_influencer_reminder task to run daily at the selected time
#     sender.add_periodic_task(
#         crontab(hour=reminder_hour, minute=reminder_minute, day_of_week='*'),
#         check_influencer_reminder.s(),
#     )
    
# @celery_app.on_after_configure.connect
# def schedule_monthly_report(sender, **kwargs):
#     # Schedule the task to run on the 1st of every month at 6:00 AM
#     sender.add_periodic_task(
#         crontab(day_of_month=30, hour=10, minute=5),
#         generate_and_send_monthly_report.s()
#     )


# # Custom function to replace app.run()
# def app_run():
#     app.run(debug=True)

# if __name__ == '__main__':
#     app_run()  # Call the custom function to start the Flask app

from flask import Flask
from flask_security import Security
from application.models import db, User, Role, Sponsor, Influencer, Campaign, AdRequest
from config import DevelopmentConfig
from application.sec import datastore
from application.worker import celery_init_app
from application.tasks import daily_reminder, check_influencer_reminder, generate_and_send_monthly_report
from application.instances import cache
import flask_excel as excel


def create_app():
    app = Flask(__name__)
    app.config.from_object(DevelopmentConfig)
    db.init_app(app)
    excel.init_excel(app)
    app.security = Security(app, datastore)
    cache.init_app(app)

    with app.app_context():
        import application.routes

    return app


app = create_app()
celery_app = celery_init_app(app)


@celery_app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    # Daily influencer reminder
    sender.add_periodic_task(
        crontab(hour=11, minute=11),
        check_influencer_reminder.s(),
    )

    # Monthly report generation
    sender.add_periodic_task(
        crontab(day_of_month=30, hour=11, minute=11),
        generate_and_send_monthly_report.s(),
    )

    # Daily email test
    sender.add_periodic_task(
        crontab(hour=11, minute=11, day_of_week=6),
        daily_reminder.s('mrunalkdmahajan@gmail.com', 'Daily Test'),
    )




if __name__ == '__main__':
    app.run(debug=True)
