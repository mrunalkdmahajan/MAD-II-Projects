import pytest
from application import create_app
from application import db

@pytest.fixture
def app():
    app = create_app(config_class='app.config.TestConfig')  # Use TestConfig
    yield app
    with app.app_context():
        db.drop_all()  # Cleanup after tests

@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def session(app):
    with app.app_context():
        db.create_all()  # Set up the database tables for testing
        yield db.session
        db.session.remove()
