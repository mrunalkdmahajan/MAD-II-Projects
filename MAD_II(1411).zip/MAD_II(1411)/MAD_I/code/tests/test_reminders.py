import pytest
from datetime import datetime, timedelta
from application import create_app, db
from application.models import Influencer, AdRequest
from application.reminders import daily_reminder_job  # Assuming this is where your job function is

@pytest.fixture
def app():
    # Initialize the app with the testing configuration
    app = create_app('testing')
    with app.app_context():
        yield app

@pytest.fixture
def client(app):
    # Test client for making requests
    return app.test_client()

@pytest.fixture
def init_db(app):
    # Set up and tear down the database for tests
    db.create_all()
    yield db
    db.drop_all()

def test_influencer_with_pending_requests_no_recent_visit(init_db):
    # Create an influencer with a pending ad request and no recent visit
    influencer = Influencer(
        name="John Doe",
        email="john@example.com",
        last_visited=datetime.now() - timedelta(days=10)  # Last visited 10 days ago
    )
    db.session.add(influencer)
    db.session.commit()

    ad_request = AdRequest(
        influencer_id=influencer.id,
        status="Pending",
        created_at=datetime.now() - timedelta(days=2)  # Pending for 2 days
    )
    db.session.add(ad_request)
    db.session.commit()

    # Now run the reminder job
    daily_reminder_job()  # Assuming this sends a reminder if necessary

    # Check if the reminder was sent (mock or assert behavior accordingly)
    influencer_in_db = Influencer.query.filter_by(email="john@example.com").first()
    assert influencer_in_db is not None
    assert len(influencer_in_db.ad_requests) > 0  # Ensure there is a pending ad request
