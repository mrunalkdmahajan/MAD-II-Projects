export default function CollegeApplicationFrom() {
  return <div>CollegeApplicationFrom</div>;
}
