export default function RecommandedApplication() {
  return <div></div>;
}
