export default function JobApplication() {
  return <div>JobApplication</div>;
}
