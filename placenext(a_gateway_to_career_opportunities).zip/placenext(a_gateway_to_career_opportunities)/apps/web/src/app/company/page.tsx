export default function Company() {
  return <div></div>;
}
