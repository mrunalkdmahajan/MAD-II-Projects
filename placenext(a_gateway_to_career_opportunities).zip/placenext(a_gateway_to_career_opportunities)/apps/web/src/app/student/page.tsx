export default function Student() {
  return <div></div>;
}
