"use client";

import JobCreationForm from "@/components/own/Form/JobCreationForm";

export default function JobCreate() {
  return (
    <div>
      <h1>Create a Job</h1>

      <JobCreationForm />
    </div>
  );
}
