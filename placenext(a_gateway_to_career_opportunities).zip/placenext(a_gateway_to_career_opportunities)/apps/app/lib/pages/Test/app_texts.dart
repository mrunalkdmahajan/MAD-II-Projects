class AppTexts {
  static const appName = 'FL Chart App';
}
