require("dotenv").config();
const express = require("express");
const nodemailer = require("nodemailer");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Nodemailer Transporter Setup
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER, // Your email (e.g., "youremail@gmail.com")
        pass: process.env.EMAIL_PASS, // App password (not your actual password)
    },
});

// API Endpoint to Send Email
app.post("/send-email", async(req, res) => {
    const { to, subject, text, html } = req.body; // Add HTML support

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to,
        subject,
        text: text, // Plain text
        html: html || text, // HTML (if available)
    };

    try {

        console.log("📧 Sending email to:", to);
        await transporter.sendMail(mailOptions);
        console.log("✅ Email sent successfully!");
        res.status(200).json({ message: "Email sent successfully!" });
    } catch (error) {
        console.error("❌ Error sending email:", error);
        res.status(500).json({ error: "Failed to send email" });
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});